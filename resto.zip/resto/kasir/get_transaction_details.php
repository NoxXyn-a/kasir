<?php
// Include the configuration file
require_once "config.php";

// Initialize response
$response = [
    'success' => false,
    'transaction' => null,
    'error' => ''
];

// Check if transaction ID is provided
if (isset($_GET['transaction_id'])) {
    $transactionId = intval($_GET['transaction_id']);
    
    try {
        // Get transaction details
        $stmt = $conn->prepare("SELECT t.*, p.idpelanggan, p.iduser, u.namauser 
                               FROM transaksi t 
                               JOIN pesanan p ON t.idpesanan = p.idpesanan 
                               LEFT JOIN user u ON p.iduser = u.iduser 
                               WHERE t.idtransaksi = ?");
        $stmt->bind_param("i", $transactionId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            // Format date
            $row['date'] = date('d/m/Y H:i', strtotime($row['date']));
            
            // Get order items from detail_pesanan table
            $orderId = $row['idpesanan'];
            $stmt = $conn->prepare("SELECT dp.jumlah, m.namamenu, dp.harga 
                                   FROM detail_pesanan dp 
                                   JOIN menu m ON dp.idmenu = m.idmenu 
                                   WHERE dp.idpesanan = ?");
            $stmt->bind_param("i", $orderId);
            $stmt->execute();
            $itemsResult = $stmt->get_result();
            
            $items = [];
            $subtotal = 0;
            
            while ($item = $itemsResult->fetch_assoc()) {
                $itemSubtotal = $item['jumlah'] * $item['harga'];
                $subtotal += $itemSubtotal;
                $item['subtotal'] = $itemSubtotal;
                $items[] = $item;
            }
            
            $tax = $subtotal * 0.1; // 10% tax
            $total = $subtotal + $tax;
            
            $transaction = [
                'idtransaksi' => $row['idtransaksi'],
                'order_invoice' => $row['order_invoice'],
                'metode_pembayaran' => $row['metode_pembayaran'],
                'bayar' => $row['bayar'],
                'date' => $row['date'],
                'order' => [
                    'idpesanan' => $row['idpesanan'],
                    'idpelanggan' => $row['idpelanggan'],
                    'namauser' => $row['namauser'],
                ],
                'items' => $items,
                'subtotal' => $subtotal,
                'tax' => $tax,
                'total' => $total
            ];
            
            $response['success'] = true;
            $response['transaction'] = $transaction;
        } else {
            $response['error'] = 'Transaction not found';
        }
    } catch (Exception $e) {
        $response['error'] = 'Server error: ' . $e->getMessage();
    }
} else {
    $response['error'] = 'Transaction ID is required';
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
<?php
// Include the configuration file
require_once "config.php";

// Check if transaction ID is provided
if (!isset($_GET['transaction_id']) || empty($_GET['transaction_id'])) {
    echo "Transaction ID is required.";
    exit;
}

$transactionId = intval($_GET['transaction_id']);

// Get transaction information
$stmt = $conn->prepare("SELECT t.*, p.idpelanggan, p.iduser, u.namauser 
                        FROM transaksi t 
                        JOIN pesanan p ON t.idpesanan = p.idpesanan 
                        JOIN user u ON p.iduser = u.iduser
                        WHERE t.idtransaksi = ?");
$stmt->bind_param("i", $transactionId);
$stmt->execute();
$transaction = $stmt->get_result()->fetch_assoc();

if (!$transaction) {
    echo "Transaction not found.";
    exit;
}

// Get customer information
$stmt = $conn->prepare("SELECT pl.namapelanggan 
                       FROM pelanggan pl 
                       JOIN pesanan p ON pl.idpelanggan = p.idpelanggan 
                       WHERE p.idpesanan = ?");
$stmt->bind_param("i", $transaction['idpesanan']);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();

// CORRECTED: Get order items from detail_pesanan table instead of pesanan
$stmt = $conn->prepare("SELECT dp.jumlah, dp.idmenu, m.namamenu, dp.harga 
                       FROM detail_pesanan dp 
                       JOIN menu m ON dp.idmenu = m.idmenu 
                       WHERE dp.idpesanan = ?");
$stmt->bind_param("i", $transaction['idpesanan']);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Calculate totals
$subtotal = 0;
foreach ($items as $item) {
    $subtotal += $item['jumlah'] * $item['harga'];
}

$tax = $subtotal * 0.1; // 10% tax
$total = $subtotal + $tax;
$change = $transaction['bayar'] - $total;

// Function to format currency
function formatCurrency($amount) {
    return "Rp " . number_format($amount, 0, ',', '.');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt #<?php echo $transaction['order_invoice']; ?></title>
    <style>
        body {
            font-family: 'Courier New', monospace;
            margin: 0;
            padding: 0;
            width: 80mm;
            margin: 0 auto;
        }
        .receipt {
            padding: 10px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .info {
            margin-bottom: 15px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        .items {
            margin-bottom: 15px;
        }
        .item-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        .totals {
            margin-top: 10px;
            margin-bottom: 15px;
        }
        .total-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
        }
        .divider {
            border-top: 1px dashed #000;
            margin: 10px 0;
        }
        @media print {
            body {
                width: 80mm;
                margin: 0;
            }
            .no-print {
                display: none;
            }
        }
        
    </style>
</head>
<body>
    <div class="receipt">
        <div class="header">
            <h2> Ravine Resto</h2>
            <p>Jl. Restaurant Street No. 123</p>
            <p>Phone: +62 123 456 7890</p>
        </div>
        
        <div class="divider"></div>
        
        <div class="info">
            <div class="info-row">
                <span>Receipt:</span>
                <span><?php echo $transaction['order_invoice']; ?></span>
            </div>
            <div class="info-row">
                <span>Date:</span>
                <span><?php echo date('d/m/Y H:i', strtotime($transaction['date'])); ?></span>
            </div>
            <div class="info-row">
                <span>Server:</span>
                <span><?php echo $transaction['namauser']; ?></span>
            </div>
            <div class="info-row">
                <span>Customer ID:</span>
                <span>#<?php echo $transaction['idpelanggan']; ?></span>
            </div>
        </div>
        
        <div class="divider"></div>
        
        <div class="items">
            <?php foreach ($items as $item): ?>
            <div class="item-row">
                <span><?php echo $item['jumlah']; ?>x <?php echo $item['namamenu']; ?></span>
                <span><?php echo formatCurrency($item['jumlah'] * $item['harga']); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="divider"></div>
        
        <div class="totals">
            <div class="total-row">
                <span>Subtotal:</span>
                <span><?php echo formatCurrency($subtotal); ?></span>
            </div>
            <div class="total-row">
                <span>Tax (10%):</span>
                <span><?php echo formatCurrency($tax); ?></span>
            </div>
            <div class="total-row">
                <span><strong>TOTAL:</strong></span>
                <span><strong><?php echo formatCurrency($total); ?></strong></span>
            </div>
            
            <?php if ($transaction['metode_pembayaran'] == 'cash'): ?>
            <div class="total-row">
                <span>Amount Paid:</span>
                <span><?php echo formatCurrency($transaction['bayar']); ?></span>
            </div>
            <div class="total-row">
                <span>Change:</span>
                <span><?php echo formatCurrency($change); ?></span>
            </div>
            <?php else: ?>
            <div class="total-row">
                <span>Payment Method:</span>
                <span><?php echo ucfirst($transaction['metode_pembayaran']); ?></span>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="divider"></div>
        
        <div class="footer">
            <p>Thank you for your visit!</p>
            <p>Please come again</p>
        </div>
    </div>
    
    <div class="no-print" style="text-align: center; margin-top: 20px;">
        <button onclick="window.print()">Print Receipt</button>
        <button onclick="window.close()">Close</button>
    </div>
    
    <script>
        // Auto print on page load
        window.onload = function() {
            setTimeout(function() {
                window.print();
            }, 500);
        }
    </script>
</body>
</html>
<?php
// Include the configuration file
require_once "config.php";

// Check if user is logged in
session_start();

// Initialize success and error messages
$success_message = "";
$error_message = "";

// Check for flash messages from previous redirect
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']); // Clear the message after showing it
}

if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']); // Clear the message after showing it
}

// Function to get all transactions with filters
function getTransactions($conn, $dateFrom = null, $dateTo = null, $paymentMethod = null, $status = null) {
    $query = "SELECT t.idtransaksi, t.idpesanan, t.total, t.bayar, t.order_invoice, 
                     t.metode_pembayaran, t.date, t.status, p.idpelanggan 
              FROM transaksi t 
              JOIN pesanan p ON t.idpesanan = p.idpesanan";
    
    $conditions = [];
    $params = [];
    
    if ($dateFrom) {
        // Add time to make it start of day
        $dateFrom = $dateFrom . ' 00:00:00';
        $conditions[] = "t.date >= ?";
        $params[] = $dateFrom;
    }
    
    if ($dateTo) {
        // Add time to make it end of day
        $dateTo = $dateTo . ' 23:59:59';
        $conditions[] = "t.date <= ?";
        $params[] = $dateTo;
    }
    
    if ($paymentMethod && $paymentMethod != 'all') {
        $conditions[] = "t.metode_pembayaran = ?";
        $params[] = $paymentMethod;
    }
    
    if ($status && $status != 'all') {
        $conditions[] = "t.status = ?";
        $params[] = $status;
    }
    
    if (!empty($conditions)) {
        $query .= " WHERE " . implode(" AND ", $conditions);
    }
    
    $query .= " ORDER BY t.date DESC";
    
    $stmt = $conn->prepare($query);
    
    if (!empty($params)) {
        $types = str_repeat("s", count($params));
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $transactions = [];
    
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
    
    return $transactions;
}

// Function to get customer name by ID
function getCustomerName($conn, $idpelanggan) {
    $stmt = $conn->prepare("SELECT namapelanggan FROM pelanggan WHERE idpelanggan = ?");
    $stmt->bind_param("i", $idpelanggan);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return $row['namapelanggan'];
    }
    
    return "Unknown Customer"; // Fallback
}

// Function to get order details
function getOrderDetails($conn, $orderId) {
    // Get basic order information
    $stmt = $conn->prepare("SELECT p.idpesanan, p.idpelanggan, p.time, p.status, 
                           p.order_invoice, pl.namapelanggan, u.namauser 
                           FROM pesanan p 
                           LEFT JOIN pelanggan pl ON p.idpelanggan = pl.idpelanggan 
                           LEFT JOIN user u ON p.iduser = u.iduser 
                           WHERE p.idpesanan = ? 
                           LIMIT 1");
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $result = $stmt->get_result();
    $orderInfo = $result->fetch_assoc();
    
    if (!$orderInfo) {
        return null;
    }
    
    // Format order date/time
    $orderInfo['time'] = date('d/m/Y H:i', strtotime($orderInfo['time']));
    
    // Get order items from detail_pesanan table
    $stmt = $conn->prepare("SELECT dp.jumlah, dp.idmenu, dp.harga, m.namamenu
                           FROM detail_pesanan dp
                           JOIN menu m ON dp.idmenu = m.idmenu 
                           WHERE dp.idpesanan = ?");
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $items = [];
    $subtotal = 0;
    
    while ($row = $result->fetch_assoc()) {
        $itemSubtotal = $row['jumlah'] * $row['harga'];
        $subtotal += $itemSubtotal;
        
        $row['subtotal'] = $itemSubtotal;
        $items[] = $row;
    }
    
    $tax = $subtotal * 0.1; // 10% tax
    $total = $subtotal + $tax;
    
    return [
        'info' => $orderInfo,
        'items' => $items,
        'subtotal' => $subtotal,
        'tax' => $tax,
        'total' => $total
    ];
}

// Function to get available orders (not yet paid)
function getAvailableOrders($conn) {
    // This query fetches orders with 'ready' status OR orders with 'belum_dibayar' transactions
    $query = "SELECT p.idpesanan, p.idpelanggan, p.order_invoice, p.idmeja, pl.namapelanggan
              FROM pesanan p
              LEFT JOIN pelanggan pl ON p.idpelanggan = pl.idpelanggan
              LEFT JOIN transaksi t ON p.idpesanan = t.idpesanan
              WHERE (p.status = 'ready' OR t.status = 'belum_dibayar')
              AND p.status != 'completed'
              ORDER BY p.time DESC";
    
    $result = $conn->query($query);
    $orders = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Add a display name for the dropdown
            $customerName = !empty($row['namapelanggan']) ? $row['namapelanggan'] : "Table #" . $row['idmeja'];
            $row['display_name'] = "Order #" . $row['idpesanan'] . " - " . $customerName . " (" . $row['order_invoice'] . ")";
            $orders[] = $row;
        }
    }
    
    return $orders;
}
// Function to create a new transaction
function createTransaction($conn, $idpesanan, $total, $bayar, $metode_pembayaran) {
    // Check if a transaction already exists for this order
    $checkStmt = $conn->prepare("SELECT idtransaksi, total FROM transaksi WHERE idpesanan = ?");
    $checkStmt->bind_param("i", $idpesanan);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        // Transaction exists, update it instead
        $transactionData = $checkResult->fetch_assoc();
        $idtransaksi = $transactionData['idtransaksi'];
        
        // Get order invoice from pesanan table
        $invoiceStmt = $conn->prepare("SELECT order_invoice FROM pesanan WHERE idpesanan = ?");
        $invoiceStmt->bind_param("i", $idpesanan);
        $invoiceStmt->execute();
        $invoiceResult = $invoiceStmt->get_result();
        $orderData = $invoiceResult->fetch_assoc();
        $order_invoice = $orderData && $orderData['order_invoice'] ? 
                        $orderData['order_invoice'] : 
                        "TRX-" . date('Ymd') . "-" . mt_rand(100, 999);
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Update the transaction with new status 'sudah_dibayar'
            $updateStmt = $conn->prepare("UPDATE transaksi SET total = ?, bayar = ?, metode_pembayaran = ?, date = NOW(), status = 'sudah_dibayar' WHERE idtransaksi = ?");
            $updateStmt->bind_param("ddsi", $total, $bayar, $metode_pembayaran, $idtransaksi);
            
            if (!$updateStmt->execute()) {
                $conn->rollback();
                return [
                    'success' => false,
                    'error' => 'Failed to update transaction: ' . $updateStmt->error
                ];
            }
            
            // Update order status to completed
            $updateStmt = $conn->prepare("UPDATE pesanan SET status = 'completed' WHERE idpesanan = ?");
            $updateStmt->bind_param("i", $idpesanan);
            $updateStmt->execute();
            
            // Update table status back to available
            $updateTableStmt = $conn->prepare("UPDATE meja m 
                                             JOIN pesanan p ON m.idmeja = p.idmeja 
                                             SET m.status = 'tersedia' 
                                             WHERE p.idpesanan = ?");
            $updateTableStmt->bind_param("i", $idpesanan);
            $updateTableStmt->execute();
            
            // Commit the transaction
            $conn->commit();
            
            // Return success
            return [
                'success' => true,
                'transaction_id' => $idtransaksi,
                'order_invoice' => $order_invoice
            ];
        } catch (Exception $e) {
            // Rollback in case of error
            $conn->rollback();
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    // Get order invoice from pesanan table
    $invoiceStmt = $conn->prepare("SELECT order_invoice FROM pesanan WHERE idpesanan = ?");
    $invoiceStmt->bind_param("i", $idpesanan);
    $invoiceStmt->execute();
    $invoiceResult = $invoiceStmt->get_result();
    $orderData = $invoiceResult->fetch_assoc();
    
    // Use existing invoice from the order
    $order_invoice = $orderData && $orderData['order_invoice'] ? 
                    $orderData['order_invoice'] : 
                    "TRX-" . date('Ymd') . "-" . mt_rand(100, 999);
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Insert transaction record with initial status 'belum_dibayar' if inserted from order
        // But if directly creating a transaction with payment, set status to 'sudah_dibayar'
        $status = 'sudah_dibayar'; // Since we're processing a payment
        
        // Insert transaction record
        $stmt = $conn->prepare("INSERT INTO transaksi (idpesanan, total, bayar, order_invoice, metode_pembayaran, date, status) 
                               VALUES (?, ?, ?, ?, ?, NOW(), ?)");
        $stmt->bind_param("iidsss", $idpesanan, $total, $bayar, $order_invoice, $metode_pembayaran, $status);
        $stmt->execute();
        $transaction_id = $stmt->insert_id;
        
        // Update order status to completed
        $updateStmt = $conn->prepare("UPDATE pesanan SET status = 'completed' WHERE idpesanan = ?");
        $updateStmt->bind_param("i", $idpesanan);
        $updateStmt->execute();
        
        // Update table status back to available
        $updateTableStmt = $conn->prepare("UPDATE meja m 
                                          JOIN pesanan p ON m.idmeja = p.idmeja 
                                          SET m.status = 'tersedia' 
                                          WHERE p.idpesanan = ?");
        $updateTableStmt->bind_param("i", $idpesanan);
        $updateTableStmt->execute();
        
        // Commit the transaction
        $conn->commit();
        
        return [
            'success' => true,
            'transaction_id' => $transaction_id,
            'order_invoice' => $order_invoice
        ];
    } catch (Exception $e) {
        // Rollback in case of error
        $conn->rollback();
        
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

// Function to format currency
function formatCurrency($amount) {
    return "Rp " . number_format($amount, 0, ',', '.');
}

// AJAX handler for get_order_details
if (isset($_GET['action']) && $_GET['action'] == 'get_order_details' && isset($_GET['order_id'])) {
    header('Content-Type: application/json');
    
    try {
        $orderId = intval($_GET['order_id']);
        $orderDetails = getOrderDetails($conn, $orderId);
        
        if ($orderDetails) {
            echo json_encode([
                'success' => true,
                'order' => $orderDetails
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'Order not found'
            ]);
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => 'Server error: ' . $e->getMessage()
        ]);
    }
    exit;
}

// Process form submission for new transaction
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['process_payment'])) {
    $idpesanan = $_POST['orderSelect'];
    $total = $_POST['total'];
    $bayar = $_POST['amountPaid'];
    $metode_pembayaran = $_POST['paymentMethodSelect'];
    
    // Validate inputs
    if (empty($idpesanan) || empty($total) || empty($bayar) || empty($metode_pembayaran)) {
        $error_message = "All fields are required";
    } else {
        // Create transaction
        $result = createTransaction($conn, $idpesanan, $total, $bayar, $metode_pembayaran);
        
        if ($result['success']) {
            $kembalian = $bayar - $total;
            $_SESSION['success_message'] = "Transaction completed successfully. Invoice: " . $result['order_invoice'];
            
            if ($metode_pembayaran == 'cash' && $kembalian > 0) {
                $_SESSION['success_message'] .= ". Change: " . formatCurrency($kembalian);
            }
            
            // Redirect to prevent form resubmission
            header("Location: transaksi.php");
            exit;
        } else {
            $error_message = "Failed to process payment: " . $result['error'];
            // Additional logging for debugging
            error_log('Transaction error: ' . print_r($result, true));
        }
    }
}
function createInitialTransaction($conn, $idpesanan, $total, $order_invoice) {
    // Create transaction with belum_dibayar status
    $status = 'belum_dibayar';
    $bayar = 0; // No payment yet
    $metode_pembayaran = ''; // No payment method yet
    
    $stmt = $conn->prepare("INSERT INTO transaksi (idpesanan, total, bayar, order_invoice, metode_pembayaran, date, status) 
                           VALUES (?, ?, ?, ?, ?, NOW(), ?)");
    $stmt->bind_param("iidsss", $idpesanan, $total, $bayar, $order_invoice, $metode_pembayaran, $status);
    
    if ($stmt->execute()) {
        return true;
    } else {
        error_log("Failed to create initial transaction: " . $stmt->error);
        return false;
    }
}


// Process filter form
$dateFrom = isset($_GET['dateFrom']) ? $_GET['dateFrom'] : date('Y-m-d', strtotime('-30 days'));
$dateTo = isset($_GET['dateTo']) ? $_GET['dateTo'] : date('Y-m-d');
$paymentMethod = isset($_GET['paymentMethod']) ? $_GET['paymentMethod'] : 'all';
$status = isset($_GET['status']) ? $_GET['status'] : 'all';

// Get transactions based on filters
$transactions = getTransactions($conn, $dateFrom, $dateTo, $paymentMethod, $status);
// Get available orders for the dropdown
$availableOrders = getAvailableOrders($conn);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ravine Resto | Transaction Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg,rgb(180, 180, 180),rgb(196, 196, 196));
            --primary-color:rgb(99, 99, 99);      
            --primary-dark:rgb(107, 107, 107);        
            --primary-light: #F3EAFB;     
            --accent-color: #ffffff;
            --text-dark: #333333;           
            --text-light: #000000;
                }

            body {
                font-family: 'Poppins', sans-serif;
                background: #f4f4f9;
                color: var(--text-dark); 
            }

            .sidebar {
                min-height: 100vh;
                background: var(--primary-gradient);
                color: var(--text-light); /* Menggunakan teks hitam di sidebar untuk kontras */
                transition: all 0.3s;
            }

            .sidebar .logo-container {
                padding: 20px 15px;
                display: flex;
                flex-direction: column;
                align-items: center;
            }

            .sidebar .logo {
                width: 80px;
                height: 80px;
                margin-bottom: 15px;
                border-radius: 50%;
                object-fit: cover;
                border: 3px solid #fff;
            }

            .sidebar .nav-link {
                color: var(--text-light); /* Mengubah warna teks link menjadi hitam */
                border-radius: 8px;
                margin: 5px 10px;
                transition: background 0.3s ease;
            }

            .sidebar .nav-link:hover,
            .sidebar .nav-link.active {
                background-color: rgba(0, 0, 0, 0.1); /* Menambahkan latar belakang saat hover */
                color: #fff;
            }

            .sidebar .nav-link i {
                margin-right: 10px;
                width: 20px;
                text-align: center;
            }
        
        .card {
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,.1);
            margin-bottom: 20px;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 8px 8px 0 0 !important;
            font-weight: 600;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-dark);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
        }
        
        .badge-paid {
            background-color: #28a745;
            color: white;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 12px;
        }
        
        .badge-pending {
            background-color: #ffc107;
            color: #212529;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 12px;
        }
        
        .transaction-detail {
            cursor: pointer;
        }
        
        .transaction-detail:hover {
            background-color: rgba(0,0,0,.03);
        }
        
        .date-filter {
            width: 150px;
        }
        .logout-btn {
            display: flex;
            align-items: center;
            background-color: white;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
            border-radius: 50px;
            padding: 8px 16px;
            font-weight: bold;
            transition: all 0.3s ease;
            margin: 15px 10px;
        }

        .logout-btn:hover {
            background-color: var(--primary-color);
            color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            transform: translateY(-2px);
        }

        .logout-btn i {
            margin-right: 8px;
        }

    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="logo-container">
                    <img src="../img/ravine.png" alt="Restaurant Logo" class="logo">
                    <h5 class="text-center mb-3">Ravine Resto</h5>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="transaksi.php">
                            <i class="fas fa-exchange-alt"></i> Transaksi
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">
                            <i class="fas fa-file-alt"></i> Laporan
                        </a>
                    </li>
                    <li class="nav-item">
                        <button class="logout-btn" id="logoutBtn">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                     </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 ms-sm-auto px-md-4 py-4">
                <!-- Header -->
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Transaction Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#newTransactionModal">
                            <i class="fas fa-plus"></i> New Transaction
                        </button>
                    </div>
                </div>

                <?php if (!empty($success_message)): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo $success_message; ?>
                </div>
                <?php endif; ?>

                <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $error_message; ?>
                </div>
                <?php endif; ?>

                <!-- Filters -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-9">
                                <form class="row g-3" method="GET">
                                    <div class="col-md-3">
                                        <label for="dateFrom" class="form-label">Date From</label>
                                        <input type="date" class="form-control" id="dateFrom" name="dateFrom" value="<?php echo $dateFrom; ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="dateTo" class="form-label">Date To</label>
                                        <input type="date" class="form-control" id="dateTo" name="dateTo" value="<?php echo $dateTo; ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="paymentMethod" class="form-label">Payment Method</label>
                                        <select class="form-select" id="paymentMethod" name="paymentMethod">
                                            <option value="all" <?php echo $paymentMethod == 'all' ? 'selected' : ''; ?>>All Methods</option>
                                            <option value="cash" <?php echo $paymentMethod == 'cash' ? 'selected' : ''; ?>>Cash</option>
                                            <option value="debit" <?php echo $paymentMethod == 'debit' ? 'selected' : ''; ?>>Debit Card</option>
                                            <option value="kredit_card" <?php echo $paymentMethod == 'kredit_card' ? 'selected' : ''; ?>>Credit Card</option>
                                            <option value="qris" <?php echo $paymentMethod == 'qris' ? 'selected' : ''; ?>>QRIS</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                                <label for="status" class="form-label">Status</label>
                                            <select class="form-select" id="status" name="status">
                                            <option value="all" <?php echo isset($_GET['status']) && $_GET['status'] == 'all' ? 'selected' : ''; ?>>All Statuses</option>
                                             <option value="belum_dibayar" <?php echo isset($_GET['status']) && $_GET['status'] == 'belum_dibayar' ? 'selected' : ''; ?>>Belum Dibayar</option>
                                            <option value="sudah_dibayar" <?php echo isset($_GET['status']) && $_GET['status'] == 'sudah_dibayar' ? 'selected' : ''; ?>>Sudah Dibayar</option>
                                            </select>
                                    </div>
                                    <div class="col-md-3 d-flex align-items-end">
                                        <button type="submit" class="btn btn-primary me-2">
                                            <i class="fas fa-filter"></i> Filter
                                        </button>
                                        <a href="transaksi.php" class="btn btn-outline-secondary">
                                            <i class="fas fa-redo"></i> Reset
                                        </a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Transaction List -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>Transaction List</span>
                        <span class="badge bg-primary"><?php echo count($transactions); ?> transactions</span>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                        <table class="table table-hover mb-0">
    <thead class="table-light">
        <tr>
            <th>#</th>
            <th>Transaction ID</th>
            <th>Order ID</th>
            <th>Date</th>
            <th>Customer</th>
            <th>Total</th>
            <th>Payment Method</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($transactions)): ?>
        <tr>
            <td colspan="9" class="text-center">No transactions found</td>
        </tr>
        <?php else: ?>
        <?php foreach ($transactions as $index => $transaction): ?>
        <tr class="transaction-detail" data-bs-toggle="modal" data-bs-target="#viewTransactionModal" 
            data-id="<?php echo $transaction['idtransaksi']; ?>"
            data-order="<?php echo $transaction['idpesanan']; ?>">
            <td><?php echo $index + 1; ?></td>
            <td><?php echo $transaction['order_invoice']; ?></td>
            <td>ORD-<?php echo $transaction['idpesanan']; ?></td>
            <td><?php echo date('d/m/Y H:i', strtotime($transaction['date'])); ?></td>
            <td><?php echo getCustomerName($conn, $transaction['idpelanggan']); ?></td>
            <td><?php echo formatCurrency($transaction['total']); ?></td>
            <td><?php echo !empty($transaction['metode_pembayaran']) ? ucfirst($transaction['metode_pembayaran']) : '-'; ?></td>
            <td>
                <?php if ($transaction['status'] == 'sudah_dibayar'): ?>
                    <span class="badge bg-success">Sudah Dibayar</span>
                <?php else: ?>
                    <span class="badge bg-warning text-dark">Belum Dibayar</span>
                <?php endif; ?>
            </td>
            <td>
                <button class="btn btn-sm btn-info view-transaction" data-id="<?php echo $transaction['idtransaksi']; ?>" data-bs-toggle="tooltip" title="View Detail">
                    <i class="fas fa-eye"></i>
                </button>
                <?php if ($transaction['status'] == 'belum_dibayar'): ?>
                    <button class="btn btn-sm btn-success process-payment" data-id="<?php echo $transaction['idtransaksi']; ?>" data-order="<?php echo $transaction['idpesanan']; ?>" data-bs-toggle="tooltip" title="Process Payment">
                        <i class="fas fa-cash-register"></i>
                    </button>
                <?php else: ?>
                    <button class="btn btn-sm btn-secondary print-receipt" data-id="<?php echo $transaction['idtransaksi']; ?>" data-bs-toggle="tooltip" title="Print Receipt">
                        <i class="fas fa-print"></i>
                    </button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

    <!-- New Transaction Modal -->
    <div class="modal fade" id="newTransactionModal" tabindex="-1" aria-labelledby="newTransactionModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="newTransactionModalLabel">New Transaction</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="transactionForm" method="POST">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="orderSelect" class="form-label">Select Order</label>
                                <select class="form-select" id="orderSelect" name="orderSelect" required>
    <option value="" selected disabled>Choose order...</option>
    <?php if (empty($availableOrders)): ?>
        <option value="" disabled>No orders available</option>
    <?php else: ?>
        <?php foreach ($availableOrders as $order): ?>
        <option value="<?php echo $order['idpesanan']; ?>">
        Order #<?php echo $order['idpesanan']; ?> - <?php echo getCustomerName($conn, $order['idpelanggan']); ?>
        </option>
        <?php endforeach; ?>
    <?php endif; ?>
</select>
                            </div>
                            <div class="col-md-6">
                                <label for="transactionDate" class="form-label">Transaction Date</label>
                                <input type="datetime-local" class="form-control" id="transactionDate" name="transactionDate" value="<?php echo date('Y-m-d\TH:i'); ?>">
                            </div>
                        </div>

                        <div class="card mb-3">
                            <div class="card-header bg-light">Order Details</div>
                            <div class="card-body">
                                <div class="row mb-2">
                                    <div class="col-md-6">
                                        <p class="mb-1"><strong>Order ID:</strong> <span id="orderIdDisplay">-</span></p>
                                        <p class="mb-1"><strong>Customer ID:</strong> <span id="tableDisplay">-</span></p>
                                        <p class="mb-1"><strong>Server:</strong> <span id="serverDisplay">-</span></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-1"><strong>Date:</strong> <span id="orderDateDisplay">-</span></p>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Item</th>
                                                <th class="text-center">Qty</th>
                                                <th class="text-end">Price</th>
                                                <th class="text-end">Subtotal</th>
                                            </tr>
                                        </thead>
                                        <tbody id="orderItemsDisplay">
                                            <tr>
                                                <td colspan="4" class="text-center">Select an order to see items</td>
                                            </tr>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th colspan="3" class="text-end">Subtotal:</th>
                                                <th class="text-end" id="subtotalDisplay">Rp 0</th>
                                            </tr>
                                            <tr>
                                                <th colspan="3" class="text-end">Tax (10%):</th>
                                                <th class="text-end" id="taxDisplay">Rp 0</th>
                                            </tr>
                                            <tr>
                                                <th colspan="3" class="text-end">Total:</th>
                                                <th class="text-end" id="totalDisplay">Rp 0</th>
                                                <input type="hidden" id="total" name="total" value="0">
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="paymentMethodSelect" class="form-label">Payment Method</label>
                                <select class="form-select" id="paymentMethodSelect" name="paymentMethodSelect" required>
                                    <option value="" selected disabled>Select payment method...</option>
                                    <option value="cash">Cash</option>
                                    <option value="debit">Debit Card</option>
                                    <option value="kredit_card">Credit Card</option>
                                    <option value="qris">QRIS</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="amountPaid" class="form-label">Amount Paid</label>
                                <div class="input-group">
                                    <span class="input-group-text">Rp</span>
                                    <input type="number" class="form-control" id="amountPaid" name="amountPaid" placeholder="0" required>
                                </div>
                                <div id="changeContainer" class="mt-2" style="display: none;">
                                    <strong>Change: <span id="changeAmount">Rp 0</span></strong>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="transactionNotes" class="form-label">Notes</label>
                            <textarea class="form-control" id="transactionNotes" name="transactionNotes" rows="2"></textarea>
                        </div>
                        
                        <input type="hidden" name="process_payment" value="1">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" form="transactionForm" class="btn btn-primary">Process Payment</button>
                </div>
            </div>
        </div>
    </div>

    <!-- View Transaction Modal -->
    <div class="modal fade" id="viewTransactionModal" tabindex="-1" aria-labelledby="viewTransactionModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title" id="viewTransactionModalLabel">Transaction Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="viewTransactionBody">
                    <div class="text-center">
                        <div class="spinner-border" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-info" id="printDetailBtn">Print Receipt</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
    // Enable tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Order selection handler - MODIFIKASI URL AJAX
    // Order selection handler
// Order selection handler
document.getElementById('orderSelect').addEventListener('change', function() {
    const orderId = this.value;
    if (!orderId) return;
    
    console.log("Fetching order details for order ID:", orderId);
    
    // Add a loading indicator
    document.getElementById('orderItemsDisplay').innerHTML = '<tr><td colspan="4" class="text-center"><div class="spinner-border spinner-border-sm me-2" role="status"></div>Loading order details...</td></tr>';
    
    // Make the AJAX request - using XMLHttpRequest instead of fetch for better compatibility
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'transaksi.php?action=get_order_details&order_id=' + orderId, true);
    
    xhr.onload = function() {
        console.log("Response received. Status:", xhr.status);
        console.log("Response text:", xhr.responseText);
        
        if (xhr.status === 200) {
            try {
                const data = JSON.parse(xhr.responseText);
                console.log("Parsed data:", data);
                
                if (data.success) {
                    const order = data.order;
                    
                    // Update order info
                    document.getElementById('orderIdDisplay').textContent = 'ORD-' + order.info.idpesanan;
                    document.getElementById('tableDisplay').textContent = 'Table #' + order.info.idpelanggan;
                    document.getElementById('serverDisplay').textContent = order.info.namauser;
                    document.getElementById('orderDateDisplay').textContent = order.info.time;
                    
                    // Update order items
                    let itemsHtml = '';
                    order.items.forEach(item => {
                        itemsHtml += `
                            <tr>
                                <td>${item.namamenu}</td>
                                <td class="text-center">${item.jumlah}</td>
                                <td class="text-end">Rp ${formatNumber(item.harga)}</td>
                                <td class="text-end">Rp ${formatNumber(item.subtotal)}</td>
                            </tr>
                        `;
                    });
                    document.getElementById('orderItemsDisplay').innerHTML = itemsHtml;
                    
                    // Update totals
                    document.getElementById('subtotalDisplay').textContent = 'Rp ' + formatNumber(order.subtotal);
                    document.getElementById('taxDisplay').textContent = 'Rp ' + formatNumber(order.tax);
                    document.getElementById('totalDisplay').textContent = 'Rp ' + formatNumber(order.total);
                    document.getElementById('total').value = order.total;
                    
                    // Pre-fill the amount paid field with the total amount
                    document.getElementById('amountPaid').value = order.total;
                    calculateChange(); // Update the change display if needed
                } else {
                    console.error('Error from server:', data.error);
                    document.getElementById('orderItemsDisplay').innerHTML = '<tr><td colspan="4" class="text-center text-danger">Failed to load order details: ' + data.error + '</td></tr>';
                }
            } catch (e) {
                console.error('Error parsing JSON:', e);
                console.error('Raw response:', xhr.responseText);
                document.getElementById('orderItemsDisplay').innerHTML = '<tr><td colspan="4" class="text-center text-danger">Invalid response from server. Check console for details.</td></tr>';
            }
        } else {
            console.error('HTTP error:', xhr.status);
            document.getElementById('orderItemsDisplay').innerHTML = '<tr><td colspan="4" class="text-center text-danger">HTTP error ' + xhr.status + '</td></tr>';
        }
    };
    
    xhr.onerror = function() {
        console.error('Network error');
        document.getElementById('orderItemsDisplay').innerHTML = '<tr><td colspan="4" class="text-center text-danger">Network error. Please check your connection.</td></tr>';
    };
    
    xhr.send();
});
            
            // Calculate change for cash payments
            document.getElementById('amountPaid').addEventListener('input', calculateChange);
            document.getElementById('paymentMethodSelect').addEventListener('change', calculateChange);
            
            function calculateChange() {
                const paymentMethod = document.getElementById('paymentMethodSelect').value;
                const totalAmount = parseFloat(document.getElementById('total').value) || 0;
                const amountPaid = parseFloat(document.getElementById('amountPaid').value) || 0;
                const changeContainer = document.getElementById('changeContainer');
                if (paymentMethod === 'cash') {
                    const change = amountPaid - totalAmount;
                    document.getElementById('changeAmount').textContent = 'Rp ' + formatNumber(change);
                    changeContainer.style.display = change >= 0 ? 'block' : 'none';
                    
                    // Highlight change amount in red if insufficient
                    const changeAmountElement = document.getElementById('changeAmount');
                    if (change < 0) {
                        changeAmountElement.classList.add('text-danger');
                        changeAmountElement.textContent = 'Insufficient amount!';
                    } else {
                        changeAmountElement.classList.remove('text-danger');
                    }
                } else {
                    changeContainer.style.display = 'none';
                }
            }
            
            // View transaction details
            const viewButtons = document.querySelectorAll('.view-transaction');
            viewButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.stopPropagation(); // Prevent row click event
                    const transactionId = this.getAttribute('data-id');
                    viewTransactionDetails(transactionId);
                });
            });
            
            // Transaction row click
            const transactionRows = document.querySelectorAll('.transaction-detail');
            transactionRows.forEach(row => {
                row.addEventListener('click', function() {
                    const transactionId = this.getAttribute('data-id');
                    viewTransactionDetails(transactionId);
                });
            });
            
            function viewTransactionDetails(transactionId) {
                const viewTransactionModal = new bootstrap.Modal(document.getElementById('viewTransactionModal'));
                viewTransactionModal.show();
                
                // Get transaction details
                fetch('get_transaction_details.php?transaction_id=' + transactionId)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            displayTransactionDetails(data.transaction);
                        } else {
                            document.getElementById('viewTransactionBody').innerHTML = 
                                '<div class="alert alert-danger">Failed to load transaction details.</div>';
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching transaction details:', error);
                        document.getElementById('viewTransactionBody').innerHTML = 
                            '<div class="alert alert-danger">An error occurred while loading transaction details.</div>';
                    });
                
                // Set print button data
                document.getElementById('printDetailBtn').setAttribute('data-id', transactionId);
            }
            
            // Print receipt
            document.querySelectorAll('.print-receipt').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.stopPropagation(); // Prevent row click event
                    const transactionId = this.getAttribute('data-id');
                    printReceipt(transactionId);
                });
            });
            
            document.getElementById('printDetailBtn').addEventListener('click', function() {
                const transactionId = this.getAttribute('data-id');
                printReceipt(transactionId);
            });
            
            function printReceipt(transactionId) {
                window.open('print_receipt.php?transaction_id=' + transactionId, '_blank');
            }
            
            // Helper function to format numbers
            function formatNumber(number) {
                return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            }
            
            function displayTransactionDetails(transaction) {
                let html = `
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Transaction Information</h6>
                            <p class="mb-1"><strong>Invoice:</strong> ${transaction.order_invoice}</p>
                            <p class="mb-1"><strong>Date:</strong> ${transaction.date}</p>
                            <p class="mb-1"><strong>Payment Method:</strong> ${transaction.metode_pembayaran}</p>
                            <p class="mb-1"><strong>Amount Paid:</strong> Rp ${formatNumber(transaction.bayar)}</p>
                        </div>
                        <div class="col-md-6">
                            <h6>Order Information</h6>
                            <p class="mb-1"><strong>Order ID:</strong> ORD-${transaction.order.idpesanan}</p>
                            <p class="mb-1"><strong>Customer:</strong> Table #${transaction.order.idpelanggan}</p>
                            <p class="mb-1"><strong>Server:</strong> ${transaction.order.namauser}</p>
                        </div>
                    </div>
                    
                    <h6>Order Items</h6>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th class="text-center">Qty</th>
                                    <th class="text-end">Price</th>
                                    <th class="text-end">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                transaction.items.forEach(item => {
                    html += `
                        <tr>
                            <td>${item.namamenu}</td>
                            <td class="text-center">${item.jumlah}</td>
                            <td class="text-end">Rp ${formatNumber(item.harga)}</td>
                            <td class="text-end">Rp ${formatNumber(item.subtotal)}</td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="3" class="text-end">Subtotal:</th>
                                    <th class="text-end">Rp ${formatNumber(transaction.subtotal)}</th>
                                </tr>
                                <tr>
                                    <th colspan="3" class="text-end">Tax (10%):</th>
                                    <th class="text-end">Rp ${formatNumber(transaction.tax)}</th>
                                </tr>
                                <tr>
                                    <th colspan="3" class="text-end">Total:</th>
                                    <th class="text-end">Rp ${formatNumber(transaction.total)}</th>
                                </tr>
                `;
                
                // Show change if payment method is cash and amount paid is greater than total
                if (transaction.metode_pembayaran === 'cash' && parseFloat(transaction.bayar) > parseFloat(transaction.total)) {
                    const change = parseFloat(transaction.bayar) - parseFloat(transaction.total);
                    html += `
                        <tr>
                            <th colspan="3" class="text-end">Amount Paid:</th>
                            <th class="text-end">Rp ${formatNumber(transaction.bayar)}</th>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-end">Change:</th>
                            <th class="text-end">Rp ${formatNumber(change)}</th>
                        </tr>
                    `;
                }
                
                html += `
                            </tfoot>
                        </table>
                    </div>
                `;
                
                document.getElementById('viewTransactionBody').innerHTML = html;
            }
        });
        document.getElementById('logoutBtn').addEventListener('click', confirmLogout);
        document.getElementById('dropdownLogoutBtn').addEventListener('click', confirmLogout);
        
        function confirmLogout() {
            Swal.fire({
                title: 'Logout Confirmation',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#C41E3A',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, Logout',
                cancelButtonText: 'Cancel',
                customClass: {
                    confirmButton: 'btn btn-danger',
                    cancelButton: 'btn btn-secondary'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Logged Out!',
                        text: 'You have been successfully logged out.',
                        confirmButtonColor: '#C41E3A',
                        timer: 1500,
                        timerProgressBar: true,
                        willClose: () => {
                            window.location.href = 'logout.php';
                        }
                    });
                }
            });
        }
    </script>
</body>
</html>
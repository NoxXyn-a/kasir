<?php
// Include the configuration file
require_once "config.php";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if transaksi table exists and has data
$result = $conn->query("SELECT COUNT(*) as count FROM transaksi");
$row = $result->fetch_assoc();
$transactionCount = $row['count'];

echo "Connected successfully to database.<br>";
echo "Number of transactions in database: " . $transactionCount . "<br>";

// Show transactions for debugging
echo "<h3>Recent Transactions:</h3>";
$result = $conn->query("SELECT * FROM transaksi ORDER BY date DESC LIMIT 5");

if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Order ID</th><th>Invoice</th><th>Total</th><th>Payment Method</th><th>Date</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["idtransaksi"] . "</td>";
        echo "<td>" . $row["idpesanan"] . "</td>";
        echo "<td>" . $row["order_invoice"] . "</td>";
        echo "<td>" . $row["total"] . "</td>";
        echo "<td>" . $row["metode_pembayaran"] . "</td>";
        echo "<td>" . $row["date"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No transactions found";
}
?>
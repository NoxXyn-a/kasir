<?php
// Include the configuration file
require_once "config.php";

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if order ID is provided
if (!isset($_GET['order_id']) || empty($_GET['order_id'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Order ID is required'
    ]);
    exit;
}

$orderId = intval($_GET['order_id']);

// Check connection
if ($conn->connect_error) {
    echo json_encode([
        'success' => false,
        'error' => 'Database connection failed: ' . $conn->connect_error
    ]);
    exit;
}

try {
    // Get order information
    $stmt = $conn->prepare("SELECT p.*, pl.namapelanggan, u.namauser 
                           FROM pesanan p 
                           JOIN pelanggan pl ON p.idpelanggan = pl.idpelanggan 
                           JOIN user u ON p.iduser = u.iduser 
                           WHERE p.idpesanan = ?");

    if (!$stmt) {
        throw new Exception('Prepare failed: ' . $conn->error);
    }

    $stmt->bind_param("i", $orderId);
    
    if (!$stmt->execute()) {
        throw new Exception('Execute failed: ' . $stmt->error);
    }
    
    $result = $stmt->get_result();
    $orderInfo = $result->fetch_assoc();

    if (!$orderInfo) {
        throw new Exception('Order not found for ID: ' . $orderId);
    }

    // Format order date/time
    $orderInfo['time'] = date('d/m/Y H:i', strtotime($orderInfo['time']));

    // Get order items from jumlah table (joining with menu)
    $stmt = $conn->prepare("SELECT j.*, m.namamenu, m.harga 
                           FROM jumlah j 
                           JOIN menu m ON j.idmenu = m.idmenu 
                           WHERE j.idpesanan = ?");
    
    if (!$stmt) {
        throw new Exception('Prepare failed for items query: ' . $conn->error);
    }

    $stmt->bind_param("i", $orderId);
    
    if (!$stmt->execute()) {
        throw new Exception('Execute failed for items query: ' . $stmt->error);
    }
    
    $result = $stmt->get_result();

    $items = [];
    $subtotal = 0;

    while ($row = $result->fetch_assoc()) {
        $itemSubtotal = $row['jumlah'] * $row['harga'];
        $subtotal += $itemSubtotal;
        
        $row['subtotal'] = $itemSubtotal;
        $items[] = $row;
    }

    $tax = $subtotal * 0.1; // 10% tax
    $total = $subtotal + $tax;

    // Return the result as JSON
    echo json_encode([
        'success' => true,
        'order' => [
            'info' => $orderInfo,
            'items' => $items,
            'subtotal' => $subtotal,
            'tax' => $tax,
            'total' => $total
        ]
    ]);
    
} catch (Exception $e) {
    // Return error message
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
<?php
// Include the configuration file
require_once "config.php";

// Get order_id from GET request
$orderId = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

// Function to get order details
// Function to get order details
function getOrderDetails($conn, $orderId) {
    // Get order information
    $stmt = $conn->prepare("SELECT p.*, pl.namapelanggan, u.namauser 
                           FROM pesanan p 
                           LEFT JOIN pelanggan pl ON p.idpelanggan = pl.idpelanggan 
                           LEFT JOIN user u ON p.iduser = u.iduser 
                           WHERE p.idpesanan = ?");
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $result = $stmt->get_result();
    $orderInfo = $result->fetch_assoc();
    
    if (!$orderInfo) {
        return null;
    }
    
    // Format order date/time
    $orderInfo['time'] = date('d/m/Y H:i', strtotime($orderInfo['time']));
    
    // Get order items directly from pesanan table, joining with menu
    // Looking at your database schema, it seems the pesanan table has idmenu and jumlah columns
    $stmt = $conn->prepare("SELECT p.jumlah, p.idmenu, m.namamenu, m.harga 
                           FROM pesanan p 
                           JOIN menu m ON p.idmenu = m.idmenu 
                           WHERE p.idpesanan = ?");
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $items = [];
    $subtotal = 0;
    
    while ($row = $result->fetch_assoc()) {
        $itemSubtotal = $row['jumlah'] * $row['harga'];
        $subtotal += $itemSubtotal;
        
        $row['subtotal'] = $itemSubtotal;
        $items[] = $row;
    }
    
    $tax = $subtotal * 0.1; // 10% tax
    $total = $subtotal + $tax;
    
    return [
        'info' => $orderInfo,
        'items' => $items,
        'subtotal' => $subtotal,
        'tax' => $tax,
        'total' => $total
    ];
}

// Set headers for JSON response
header('Content-Type: application/json');

// Get order details
try {
    if ($orderId > 0) {
        $orderDetails = getOrderDetails($conn, $orderId);
        
        if ($orderDetails) {
            echo json_encode([
                'success' => true,
                'order' => $orderDetails
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'Order not found'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Invalid order ID'
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Server error: ' . $e->getMessage()
    ]);
}
?>
<?php

session_start();


$host = "localhost";
$username = "root"; 
$password = ""; 
$database = "rehan";


$conn = mysqli_connect($host, $username, $password, $database);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$customer_id = "";
$customer_name = "";
$customer_phone = "";
$customer_gender = "";
$customer_address = "";
$error = "";
$success = "";


$customers = [];
$query = "SELECT * FROM pelanggan ORDER BY namapelanggan ASC";
$result = mysqli_query($conn, $query);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $customers[] = $row;
    }
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    if (isset($_POST['add_customer'])) {
        $customer_name = $_POST['customer_name'];
        $customer_phone = $_POST['customer_phone'] ?? '';
        $customer_gender = $_POST['customer_gender'] ?? '';
        $customer_address = $_POST['customer_address'] ?? '';
        
       
        if (empty($customer_name)) {
            $error = "Customer name is required";
        } else {
           
            $insert_query = "INSERT INTO pelanggan (namapelanggan, nohp, jeniskelamin, alamat) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $insert_query);
            mysqli_stmt_bind_param($stmt, "ssss", $customer_name, $customer_phone, $customer_gender, $customer_address);
            
            if (mysqli_stmt_execute($stmt)) {
                $success = "Customer added successfully!";
           
                $customer_name = "";
                $customer_phone = "";
                $customer_gender = "";
                $customer_address = "";
                
              
                $query = "SELECT * FROM pelanggan ORDER BY namapelanggan ASC";
                $result = mysqli_query($conn, $query);
                $customers = [];
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $customers[] = $row;
                    }
                }
                
      
                header("Location: pelanggan.php?status=added");
                exit;
            } else {
                $error = "Error adding customer: " . mysqli_error($conn);
            }
        }
    }
    
  
    if (isset($_POST['edit_customer'])) {
        $customer_id = $_POST['customer_id'];
        $customer_name = $_POST['customer_name'];
        $customer_phone = $_POST['customer_phone'] ?? '';
        $customer_gender = $_POST['customer_gender'] ?? '';
        $customer_address = $_POST['customer_address'] ?? '';
        
    
        if (empty($customer_id) || empty($customer_name)) {
            $error = "Customer ID and name are required";
        } else {
      
            $update_query = "UPDATE pelanggan SET namapelanggan = ?, nohp = ?, jeniskelamin = ?, alamat = ? WHERE idpelanggan = ?";
            $stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($stmt, "ssssi", $customer_name, $customer_phone, $customer_gender, $customer_address, $customer_id);
            
            if (mysqli_stmt_execute($stmt)) {
                $success = "Customer updated successfully!";
                
          
                $query = "SELECT * FROM pelanggan ORDER BY namapelanggan ASC";
                $result = mysqli_query($conn, $query);
                $customers = [];
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $customers[] = $row;
                    }
                }
                
           
                header("Location: pelanggan.php?status=updated");
                exit;
            } else {
                $error = "Error updating customer: " . mysqli_error($conn);
            }
        }
    }
    

    if (isset($_POST['delete_customer'])) {
        $customer_id = $_POST['customer_id'];
     
        $check_orders = "SELECT COUNT(*) as order_count FROM pesanan WHERE idpelanggan = ?";
        $check_stmt = mysqli_prepare($conn, $check_orders);
        mysqli_stmt_bind_param($check_stmt, "i", $customer_id);
        mysqli_stmt_execute($check_stmt);
        $check_result = mysqli_stmt_get_result($check_stmt);
        $order_count = mysqli_fetch_assoc($check_result)['order_count'];
        
        if ($order_count > 0) {
            $error = "Cannot delete customer because they have existing orders";
        } else {
         
            $delete_query = "DELETE FROM pelanggan WHERE idpelanggan = ?";
            $stmt = mysqli_prepare($conn, $delete_query);
            mysqli_stmt_bind_param($stmt, "i", $customer_id);
            
            if (mysqli_stmt_execute($stmt)) {
                $success = "Customer deleted successfully!";
                
          
                $query = "SELECT * FROM pelanggan ORDER BY namapelanggan ASC";
                $result = mysqli_query($conn, $query);
                $customers = [];
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $customers[] = $row;
                    }
                }

                header("Location: pelanggan.php?status=deleted");
                exit;
            } else {
                $error = "Error deleting customer: " . mysqli_error($conn);
            }
        }
    }

    if (isset($_POST['get_customer_data'])) {
        $customer_id = $_POST['customer_id'];
        
        $query = "SELECT * FROM pelanggan WHERE idpelanggan = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $customer_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if ($customer_data = mysqli_fetch_assoc($result)) {
   
            header('Content-Type: application/json');
            echo json_encode($customer_data);
            exit;
        } else {
            header('HTTP/1.1 404 Not Found');
            echo json_encode(['error' => 'Customer not found']);
            exit;
        }
    }
}


if (isset($_GET['status'])) {
    switch ($_GET['status']) {
        case 'added':
            $success = "Customer added successfully!";
            break;
        case 'updated':
            $success = "Customer updated successfully!";
            break;
        case 'deleted':
            $success = "Customer deleted successfully!";
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ravine Resto | Customer Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg,rgb(180, 180, 180),rgb(196, 196, 196));
            --primary-color:rgb(99, 99, 99);      
            --primary-dark:rgb(107, 107, 107);        
            --primary-light: #F3EAFB;     
            --accent-color: #ffffff;
            --text-dark: #333333;           
            --text-light: #000000;
                }

            body {
                font-family: 'Poppins', sans-serif;
                background: #f4f4f9;
                color: var(--text-dark); 
            }

            .sidebar {
                min-height: 100vh;
                background: var(--primary-gradient);
                color: var(--text-light); /* Menggunakan teks hitam di sidebar untuk kontras */
                transition: all 0.3s;
            }

            .sidebar .logo-container {
                padding: 20px 15px;
                display: flex;
                flex-direction: column;
                align-items: center;
            }

            .sidebar .logo {
                width: 80px;
                height: 80px;
                margin-bottom: 15px;
                border-radius: 50%;
                object-fit: cover;
                border: 3px solid #fff;
            }

            .sidebar .nav-link {
                color: var(--text-light); /* Mengubah warna teks link menjadi hitam */
                border-radius: 8px;
                margin: 5px 10px;
                transition: background 0.3s ease;
            }

            .sidebar .nav-link:hover,
            .sidebar .nav-link.active {
                background-color: rgba(0, 0, 0, 0.1); /* Menambahkan latar belakang saat hover */
                color: #fff;
            }

            .sidebar .nav-link i {
                margin-right: 10px;
                width: 20px;
                text-align: center;
            }

        .content-area {
            padding: 20px;
        }

        .page-header {
            border-bottom: 1px solid #dee2e6;
            margin-bottom: 20px;
            padding-bottom: 10px;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-dark);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }

        .card {
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 8px 8px 0 0 !important;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .table th {
            background-color: #f8f9fa;
        }

        .action-buttons .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        
        .customer-form label {
            font-weight: 500;
        }
        
        .customer-form .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(196, 30, 58, 0.25);
        }
        
        /* Search input styling */
        .search-container {
            position: relative;
            max-width: 300px;
        }
        
        .search-container i {
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            color: #6c757d;
        }
        
        .search-input {
            padding-left: 30px;
            border-radius: 20px;
        }
        
        /* Status badges */
        .badge-active {
            background-color: #28a745;
            color: white;
        }
        
        .badge-inactive {
            background-color: #6c757d;
            color: white;
        }
        
        /* Table row hover effect */
        .table-hover tbody tr:hover {
            background-color: rgba(196, 30, 58, 0.05);
        }
        
        .logout-btn {
            display: flex;
            align-items: center;
            background-color: white;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
            border-radius: 50px;
            padding: 8px 16px;
            font-weight: bold;
            transition: all 0.3s ease;
            margin: 15px 10px;
        }

        .logout-btn:hover {
            background-color: var(--primary-color);
            color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            transform: translateY(-2px);
        }

        .logout-btn i {
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="logo-container">
                    <img src="../img/ravine.png" alt="Restaurant Logo" class="logo">
                    <h5 class="text-center mb-3">Ravine Resto</h5>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="fas fa-utensils"></i> Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="order.php">
                            <i class="fas fa-shopping-cart"></i> Order
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="pelanggan.php">
                            <i class="fas fa-users"></i> Customers
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">
                            <i class="fas fa-file-alt"></i> Laporan
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <button class="logout-btn" id="logoutBtn">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 content-area">
                <!-- Header -->
                <div class="page-header d-flex justify-content-between align-items-center">
                    <h2>Customer Management</h2>
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle"></i> Waiter
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Success Message -->
                <?php if (!empty($success)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <!-- Error Message -->
                <?php if (!empty($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <div class="row">
                    <!-- Add/Edit Customer Form -->
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-user-plus me-2"></i>Add New Customer</h5>
                            </div>
                            <div class="card-body">
                                <form class="customer-form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" id="customerForm">
                                    <input type="hidden" name="customer_id" id="customer_id" value="">
                                    
                                    <div class="mb-3">
                                        <label for="customer_name" class="form-label">Customer Name*</label>
                                        <input type="text" class="form-control" id="customer_name" name="customer_name" value="<?php echo $customer_name; ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="customer_phone" class="form-label">Phone Number</label>
                                        <input type="tel" class="form-control" id="customer_phone" name="customer_phone" value="<?php echo $customer_phone; ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="customer_gender" class="form-label">Gender</label>
                                        <select class="form-control" id="customer_gender" name="customer_gender">
                                            <option value="">Select gender</option>
                                            <option value="l" <?php if($customer_gender == 'l') echo 'selected'; ?>>Male</option>
                                            <option value="p" <?php if($customer_gender == 'p') echo 'selected'; ?>>Female</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="customer_address" class="form-label">Address</label>
                                        <textarea class="form-control" id="customer_address" name="customer_address" rows="3"><?php echo $customer_address; ?></textarea>
                                    </div>
                                    
                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary" id="submitBtn" name="add_customer">
                                            <i class="fas fa-save me-2"></i>Save Customer
                                        </button>
                                        <button type="button" class="btn btn-outline-secondary" id="resetBtn">
                                            <i class="fas fa-undo me-2"></i>Reset Form
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Customer List -->
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0"><i class="fas fa-users me-2"></i>Customer List</h5>
                                <span class="badge bg-primary rounded-pill"><?php echo count($customers); ?> Customers</span>
                            </div>
                            <div class="card-body">
                                <div class="mb-3 d-flex justify-content-between align-items-center">
                                    <div class="search-container">
                                        <i class="fas fa-search"></i>
                                        <input type="text" class="form-control search-input" id="customerSearch" placeholder="Search customers...">
                                    </div>
                                    <div>
                                        <button class="btn btn-sm btn-outline-success" id="exportBtn">
                                            <i class="fas fa-file-excel me-1"></i>Export
                                        </button>
                                        <button class="btn btn-sm btn-outline-primary" id="printBtn">
                                            <i class="fas fa-print me-1"></i>Print
                                        </button>
                                    </div>
                                </div>
                                
                                <div class="table-responsive">
                                    <table class="table table-hover table-striped" id="customerTable">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Phone</th>
                                                <th>Gender</th>
                                                <th>Address</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($customers)): ?>
                                            <tr>
                                                <td colspan="6" class="text-center">No customers found</td>
                                            </tr>
                                            <?php else: ?>
                                            <?php foreach ($customers as $index => $customer): ?>
                                            <tr>
                                                <td><?php echo $customer['idpelanggan']; ?></td>
                                                <td><?php echo $customer['namapelanggan']; ?></td>
                                                <td><?php echo $customer['nohp'] ?: '-'; ?></td>
                                                <td>
                                                    <?php 
                                                    if ($customer['jeniskelamin'] == 'l') {
                                                        echo 'Male';
                                                    } elseif ($customer['jeniskelamin'] == 'p') {
                                                        echo 'Female';
                                                    } else {
                                                        echo '-';
                                                    }
                                                    ?>
                                                </td>
                                                <td><?php echo $customer['alamat'] ?: '-'; ?></td>
                                                <td class="action-buttons">
                                                    <button type="button" class="btn btn-sm btn-outline-primary edit-btn" data-id="<?php echo $customer['idpelanggan']; ?>">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-outline-danger delete-btn" data-id="<?php echo $customer['idpelanggan']; ?>" data-name="<?php echo $customer['namapelanggan']; ?>">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Customer Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this customer? This action cannot be undone.</p>
                    <p><strong>Customer:</strong> <span id="deleteCustomerName"></span></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" style="display: inline;">
                        <input type="hidden" name="customer_id" id="deleteCustomerId">
                        <button type="submit" name="delete_customer" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const customerForm = document.getElementById('customerForm');
        const resetBtn = document.getElementById('resetBtn');
        const submitBtn = document.getElementById('submitBtn');
        const customerSearch = document.getElementById('customerSearch');
        const customerTable = document.getElementById('customerTable');
        const formTitle = document.querySelector('.card-header h5');
        

        const editButtons = document.querySelectorAll('.edit-btn');
        editButtons.forEach(button => {
            button.addEventListener('click', function() {
                const customerId = this.getAttribute('data-id');
           
                const xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    if (this.status === 200) {
                        const customer = JSON.parse(this.responseText);
                        
         
                        document.getElementById('customer_id').value = customer.idpelanggan;
                        document.getElementById('customer_name').value = customer.namapelanggan;
                        document.getElementById('customer_phone').value = customer.nohp;
                        document.getElementById('customer_gender').value = customer.jeniskelamin;
                        document.getElementById('customer_address').value = customer.alamat;
                        
                 
                        formTitle.innerHTML = '<i class="fas fa-user-edit me-2"></i>Edit Customer';
                        submitBtn.innerHTML = '<i class="fas fa-save me-2"></i>Update Customer';
                        submitBtn.name = 'edit_customer';
            
                        if (window.innerWidth < 992) {
                            const formCard = document.querySelector('.customer-form').closest('.card');
                            formCard.scrollIntoView({ behavior: 'smooth' });
                        }
                    }
                };
                xhr.send('get_customer_data=1&customer_id=' + customerId);
            });
        });
        

        const deleteButtons = document.querySelectorAll('.delete-btn');
        deleteButtons.forEach(button => {
            button.addEventListener('click', function() {
                const customerId = this.getAttribute('data-id');
                const customerName = this.getAttribute('data-name');
                
                document.getElementById('deleteCustomerId').value = customerId;
                document.getElementById('deleteCustomerName').textContent = customerName;
                
                const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
                deleteModal.show();
            });
        });
        
      
        resetBtn.addEventListener('click', function() {
            customerForm.reset();
            document.getElementById('customer_id').value = '';
            
        
            formTitle.innerHTML = '<i class="fas fa-user-plus me-2"></i>Add New Customer';
            submitBtn.innerHTML = '<i class="fas fa-save me-2"></i>Save Customer';
            submitBtn.name = 'add_customer';
        });

        customerSearch.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = customerTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const name = row.cells[1].textContent.toLowerCase();
                const phone = row.cells[2].textContent.toLowerCase();
                const address = row.cells[4].textContent.toLowerCase();
                
                if (name.includes(searchTerm) || phone.includes(searchTerm) || address.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
        

        document.getElementById('exportBtn').addEventListener('click', function() {
     
            Swal.fire({
                icon: 'info',
                title: 'Export Customer Data',
                text: 'This would export customer data to a CSV file in a real application.',
                confirmButtonColor: '#C41E3A',
            });
        });
        
      
        document.getElementById('printBtn').addEventListener('click', function() {
            window.print();
        });

        document.getElementById('logoutBtn').addEventListener('click', function() {
            Swal.fire({
                title: 'Logout Confirmation',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#C41E3A',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, Logout',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'logout.php';
                }
            });
        });
    });
    </script>
</body>
</html>
<?php

session_start();


$host = "localhost";
$username = "root";
$password = "";
$database = "rehan";


$conn = mysqli_connect($host, $username, $password, $database);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$order_id = "";
$order_details = [];
$order_items = [];
$customer_id = "";
$table_id = "";
$order_status = "";
$order_invoice = "";
$order_time = "";
$total_amount = 0;
$customers = [];
$all_tables = [];
$menu_items = [];


if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $order_id = $_GET['id'];
    
 
    $order_query = "SELECT p.idpesanan, p.idpelanggan, p.idmeja, p.status, p.time, p.order_invoice, 
                    pl.namapelanggan, t.total
                    FROM pesanan p
                    JOIN pelanggan pl ON p.idpelanggan = pl.idpelanggan
                    LEFT JOIN transaksi t ON p.idpesanan = t.idpesanan
                    WHERE p.idpesanan = ?";
    
    $stmt = mysqli_prepare($conn, $order_query);
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        $order_details = $row;
        $customer_id = $row['idpelanggan'];
        $table_id = $row['idmeja'];
        $order_status = $row['status'];
        $order_invoice = $row['order_invoice'];
        $order_time = $row['time'];
        $total_amount = $row['total'] ?? 0;
    } else {
        $_SESSION['error_message'] = "Order not found!";
        header("Location: order.php");
        exit();
    }
    
 
    $items_query = "SELECT dp.idmenu, dp.jumlah, dp.harga, m.namamenu, m.kategori, m.img
                    FROM detail_pesanan dp
                    JOIN menu m ON dp.idmenu = m.idmenu
                    WHERE dp.idpesanan = ?";
    
    $stmt = mysqli_prepare($conn, $items_query);
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    while ($row = mysqli_fetch_assoc($result)) {
        $order_items[] = $row;
    }
} else {
    $_SESSION['error_message'] = "Invalid order ID!";
    header("Location: order.php");
    exit();
}


$customers_query = "SELECT idpelanggan, namapelanggan FROM pelanggan";
$customers_result = mysqli_query($conn, $customers_query);
if ($customers_result) {
    while ($customer = mysqli_fetch_assoc($customers_result)) {
        $customers[] = $customer;
    }
}


$all_tables_query = "SELECT idmeja, kapasitas, status FROM meja";
$all_tables_result = mysqli_query($conn, $all_tables_query);
if ($all_tables_result) {
    while ($table = mysqli_fetch_assoc($all_tables_result)) {
        $all_tables[] = $table;
    }
}


$menu_query = "SELECT m.idmenu, m.namamenu, m.harga, m.img, m.deskripsi, m.kategori FROM menu m";
$menu_result = mysqli_query($conn, $menu_query);
if ($menu_result) {
    while ($item = mysqli_fetch_assoc($menu_result)) {
        $menu_items[] = $item;
    }
}

// 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Update order
    if (isset($_POST['update_order'])) {
        $new_customer_id = $_POST['customer_id'];
        $new_table_id = $_POST['table_id'];
        $new_status = $_POST['order_status'];
        
        mysqli_begin_transaction($conn);
        
        try {
           
            $get_current_table = "SELECT idmeja FROM pesanan WHERE idpesanan = ?";
            $current_table_stmt = mysqli_prepare($conn, $get_current_table);
            mysqli_stmt_bind_param($current_table_stmt, "i", $order_id);
            mysqli_stmt_execute($current_table_stmt);
            $result = mysqli_stmt_get_result($current_table_stmt);
            $current_order = mysqli_fetch_assoc($result);
            $old_table_id = $current_order['idmeja'];
            
    
            $update_order = "UPDATE pesanan SET idpelanggan = ?, idmeja = ?, status = ? WHERE idpesanan = ?";
            $update_stmt = mysqli_prepare($conn, $update_order);
            mysqli_stmt_bind_param($update_stmt, "iisi", $new_customer_id, $new_table_id, $new_status, $order_id);
            
            if (!mysqli_stmt_execute($update_stmt)) {
                throw new Exception("Error updating order: " . mysqli_stmt_error($update_stmt));
            }
            
         
            if ($old_table_id != $new_table_id) {
     
                $update_old_table = "UPDATE meja SET status = 'tersedia' WHERE idmeja = ?";
                $old_table_stmt = mysqli_prepare($conn, $update_old_table);
                mysqli_stmt_bind_param($old_table_stmt, "i", $old_table_id);
                
                if (!mysqli_stmt_execute($old_table_stmt)) {
                    throw new Exception("Error updating old table status: " . mysqli_stmt_error($old_table_stmt));
                }
                

                $update_new_table = "UPDATE meja SET status = 'terisi' WHERE idmeja = ?";
                $new_table_stmt = mysqli_prepare($conn, $update_new_table);
                mysqli_stmt_bind_param($new_table_stmt, "i", $new_table_id);
                
                if (!mysqli_stmt_execute($new_table_stmt)) {
                    throw new Exception("Error updating new table status: " . mysqli_stmt_error($new_table_stmt));
                }
            }
            
           
            mysqli_commit($conn);
            
      
            $_SESSION['success_message'] = "Order #$order_id updated successfully!";
            
    
            header("Location: order.php");
            exit();
            
        } catch (Exception $e) {
      
            mysqli_rollback($conn);
            
            $_SESSION['error_message'] = "Error updating order: " . $e->getMessage();
            header("Location: edit_order.php?id=$order_id");
            exit();
        }
    }
    

    if (isset($_POST['add_item'])) {
        $item_id = $_POST['item_id'];
        $quantity = $_POST['quantity'];
        
        if ($quantity > 0) {
           
            $item_query = "SELECT idmenu, namamenu, harga FROM menu WHERE idmenu = ?";
            $item_stmt = mysqli_prepare($conn, $item_query);
            mysqli_stmt_bind_param($item_stmt, "i", $item_id);
            mysqli_stmt_execute($item_stmt);
            $result = mysqli_stmt_get_result($item_stmt);
            $item = mysqli_fetch_assoc($result);
            
            if ($item) {
           
                mysqli_begin_transaction($conn);
                
                try {
                
                    $check_item = "SELECT idmenu, jumlah FROM detail_pesanan WHERE idpesanan = ? AND idmenu = ?";
                    $check_stmt = mysqli_prepare($conn, $check_item);
                    mysqli_stmt_bind_param($check_stmt, "ii", $order_id, $item_id);
                    mysqli_stmt_execute($check_stmt);
                    $result = mysqli_stmt_get_result($check_stmt);
                    
                    if ($existing_item = mysqli_fetch_assoc($result)) {
                       
                        $new_quantity = $existing_item['jumlah'] + $quantity;
                        $update_item = "UPDATE detail_pesanan SET jumlah = ? WHERE idpesanan = ? AND idmenu = ?";
                        $update_stmt = mysqli_prepare($conn, $update_item);
                        mysqli_stmt_bind_param($update_stmt, "iii", $new_quantity, $order_id, $item_id);
                        
                        if (!mysqli_stmt_execute($update_stmt)) {
                            throw new Exception("Error updating item quantity: " . mysqli_stmt_error($update_stmt));
                        }
                    } else {
      
                        $add_item = "INSERT INTO detail_pesanan (idpesanan, idmenu, jumlah, harga) VALUES (?, ?, ?, ?)";
                        $add_stmt = mysqli_prepare($conn, $add_item);
                        $price = $item['harga'];
                        mysqli_stmt_bind_param($add_stmt, "iiid", $order_id, $item_id, $quantity, $price);
                        
                        if (!mysqli_stmt_execute($add_stmt)) {
                            throw new Exception("Error adding item to order: " . mysqli_stmt_error($add_stmt));
                        }
                    }
                    
                  
                    $total_amount += ($item['harga'] * $quantity);
                    $update_total = "UPDATE transaksi SET total = ? WHERE idpesanan = ?";
                    $total_stmt = mysqli_prepare($conn, $update_total);
                    mysqli_stmt_bind_param($total_stmt, "di", $total_amount, $order_id);
                    
                    if (!mysqli_stmt_execute($total_stmt)) {
                        throw new Exception("Error updating transaction total: " . mysqli_stmt_error($total_stmt));
                    }
                    
             
                    mysqli_commit($conn);
                    
              
                    $_SESSION['success_message'] = "Item added to order successfully!";
                    
          
                    header("Location: edit_order.php?id=$order_id");
                    exit();
                    
                } catch (Exception $e) {
              
                    mysqli_rollback($conn);
                    
                    $_SESSION['error_message'] = "Error adding item to order: " . $e->getMessage();
                    header("Location: edit_order.php?id=$order_id");
                    exit();
                }
            }
        }
    }
    
  
    if (isset($_POST['remove_item'])) {
        $item_id = $_POST['item_id'];
        $item_price = $_POST['item_price'];
        $item_quantity = $_POST['item_quantity'];
        

        mysqli_begin_transaction($conn);
        
        try {
        
            $remove_item = "DELETE FROM detail_pesanan WHERE idpesanan = ? AND idmenu = ?";
            $remove_stmt = mysqli_prepare($conn, $remove_item);
            mysqli_stmt_bind_param($remove_stmt, "ii", $order_id, $item_id);
            
            if (!mysqli_stmt_execute($remove_stmt)) {
                throw new Exception("Error removing item from order: " . mysqli_stmt_error($remove_stmt));
            }
            
      
            $total_amount -= ($item_price * $item_quantity);
            $update_total = "UPDATE transaksi SET total = ? WHERE idpesanan = ?";
            $total_stmt = mysqli_prepare($conn, $update_total);
            mysqli_stmt_bind_param($total_stmt, "di", $total_amount, $order_id);
            
            if (!mysqli_stmt_execute($total_stmt)) {
                throw new Exception("Error updating transaction total: " . mysqli_stmt_error($total_stmt));
            }
            
 
            mysqli_commit($conn);
            
         
            $_SESSION['success_message'] = "Item removed from order successfully!";
            
  
            header("Location: edit_order.php?id=$order_id");
            exit();
            
        } catch (Exception $e) {
          
            mysqli_rollback($conn);
            
            $_SESSION['error_message'] = "Error removing item from order: " . $e->getMessage();
            header("Location: edit_order.php?id=$order_id");
            exit();
        }
    }
    

    if (isset($_POST['cancel_order'])) {

        mysqli_begin_transaction($conn);
        
        try {

            $update_status = "UPDATE pesanan SET status = 'cancelled' WHERE idpesanan = ?";
            $status_stmt = mysqli_prepare($conn, $update_status);
            mysqli_stmt_bind_param($status_stmt, "i", $order_id);
            
            if (!mysqli_stmt_execute($status_stmt)) {
                throw new Exception("Error cancelling order: " . mysqli_stmt_error($status_stmt));
            }
            
         
            $update_table = "UPDATE meja SET status = 'tersedia' WHERE idmeja = ?";
            $table_stmt = mysqli_prepare($conn, $update_table);
            mysqli_stmt_bind_param($table_stmt, "i", $table_id);
            
            if (!mysqli_stmt_execute($table_stmt)) {
                throw new Exception("Error updating table status: " . mysqli_stmt_error($table_stmt));
            }
            
            
            mysqli_commit($conn);
            
          
            $_SESSION['success_message'] = "Order #$order_id has been cancelled!";
            
           
            header("Location: order.php");
            exit();
            
        } catch (Exception $e) {
    
            mysqli_rollback($conn);
            
            $_SESSION['error_message'] = "Error cancelling order: " . $e->getMessage();
            header("Location: edit_order.php?id=$order_id");
            exit();
        }
    }
}


$subtotal = 0;
foreach ($order_items as $item) {
    $subtotal += $item['harga'] * $item['jumlah'];
}
$tax = $subtotal * 0.1; 
$total = $subtotal + $tax;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order #<?php echo $order_id; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #C41E3A;
            --primary-dark: #8B0000;
            --primary-light: #FF6B6B;
            --accent-color: #FFFFFF;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }
        
        .sidebar {
            min-height: 100vh;
            background-color: var(--primary-color);
            color: white;
            transition: all 0.3s;
        }
        
        .sidebar .logo-container {
            padding: 20px 15px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .sidebar .logo {
            width: 80px;
            height: 80px;
            margin-bottom: 15px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.85);
            border-radius: 5px;
            margin: 5px 10px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        .content-area {
            padding: 20px;
        }

        .page-header {
            border-bottom: 1px solid #dee2e6;
            margin-bottom: 20px;
            padding-bottom: 10px;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-dark);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }

        .card {
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 8px 8px 0 0 !important;
        }

        .table-container {
            overflow-x: auto;
        }

        .table th {
            background-color: #f8f9fa;
        }

        .menu-item {
            display: flex;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            margin-bottom: 15px;
            overflow: hidden;
            transition: transform 0.2s;
        }

        .menu-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .menu-img {
            width: 100px;
            height: 100px;
            object-fit: cover;
        }

        .menu-details {
            padding: 10px;
            flex-grow: 1;
        }

        .menu-title {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .menu-price {
            color: var(--primary-color);
            font-weight: bold;
        }

        .menu-category {
            font-size: 0.85rem;
            color: #6c757d;
        }

        .quantity-input {
            width: 60px;
            text-align: center;
        }

        .order-summary {
            position: sticky;
            top: 20px;
        }

        .badge-available {
            background-color: #28a745;
            color: white;
        }

        .badge-occupied {
            background-color: #dc3545;
            color: white;
        }

        .badge-status {
            font-size: 0.75rem;
            padding: 5px 8px;
            border-radius: 12px;
        }

        .table-order-items th, 
        .table-order-items td {
            vertical-align: middle;
        }

        .action-buttons .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        
        .order-item {
            display: flex;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            margin-bottom: 10px;
            overflow: hidden;
            background-color: white;
        }
        
        .order-item-img {
            width: 80px;
            height: 80px;
            object-fit: cover;
        }
        
        .order-item-details {
            padding: 10px;
            flex-grow: 1;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .status-badge {
            font-size: 0.8rem;
            padding: 4px 8px;
            border-radius: 12px;
        }
        
        .status-new {
            background-color: #17a2b8;
            color: white;
        }
        
        .status-processing {
            background-color: #ffc107;
            color: #212529;
        }
        
        .status-ready {
            background-color: #28a745;
            color: white;
        }
        
        .status-completed {
            background-color: #6c757d;
            color: white;
        }
        
        .status-cancelled {
            background-color: #dc3545;
            color: white;
        }
        
        .order-timeline {
            position: relative;
            padding-left: 30px;
        }
        
        .timeline-item {
            position: relative;
            padding-bottom: 20px;
        }
        
        .timeline-item:before {
            content: '';
            position: absolute;
            left: -20px;
            top: 0;
            height: 100%;
            width: 2px;
            background-color: #dee2e6;
        }
        
        .timeline-item:last-child:before {
            height: 10px;
        }
        
        .timeline-point {
            position: absolute;
            left: -26px;
            top: 0;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: var(--primary-color);
        }
        
        .timeline-content {
            background-color: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
    
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="logo-container">
                    <img src="../img/ravine.png" alt="Restaurant Logo" class="logo">
                    <h5 class="text-center mb-3">Restaurant App</h5>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="fas fa-utensils"></i> Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="order.php">
                            <i class="fas fa-shopping-cart"></i> Order
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">
                            <i class="fas fa-file-alt"></i> Laporan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transaksi.php">
                            <i class="fas fa-file-alt"></i> transaksi
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>

   
            <div class="col-md-9 col-lg-10 content-area">
                
                <div class="page-header d-flex justify-content-between align-items-center">
                    <div>
                        <h2>Edit Order #<?php echo $order_id; ?></h2>
                        <p class="text-muted">Invoice: <?php echo $order_invoice; ?> | Created: <?php echo date('d M Y H:i', strtotime($order_time)); ?></p>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="order.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Orders
                        </a>
                        <div class="dropdown">
                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-circle"></i> waiter
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="#"><i class="fas fa-user-cog"></i> Profile</a></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>


                <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['success_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['success_message']); ?>
                <?php endif; ?>

             
                <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['error_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['error_message']); ?>
                <?php endif; ?>

                <div class="row">
           
                    <div class="col-lg-8">
                     
                        <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Order Information</h5>
                                <span class="badge <?php 
                                    if ($order_status == 'new') echo 'bg-info'; 
                                    elseif ($order_status == 'processing') echo 'bg-warning text-dark';
                                    elseif ($order_status == 'ready') echo 'bg-success';
                                    elseif ($order_status == 'completed') echo 'bg-secondary';
                                    elseif ($order_status == 'cancelled') echo 'bg-danger';
                                    else echo 'bg-secondary';
                                ?>">
                                    <?php echo ucfirst($order_status); ?>
                                </span>
                            </div>
                            <div class="card-body">
                                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id=" . $order_id); ?>">
                                    <div class="row g-3 mb-3">
                                        <div class="col-md-6">
                                            <label for="customerSelect" class="form-label">Customer</label>
                                            <select class="form-select" id="customerSelect" name="customer_id" required>
                                                <?php foreach ($customers as $customer): ?>
                                                <option value="<?php echo $customer['idpelanggan']; ?>" <?php if ($customer['idpelanggan'] == $customer_id) echo 'selected'; ?>>
                                                    <?php echo $customer['namapelanggan']; ?>
                                                </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="tableSelect" class="form-label">Table</label>
                                            <select class="form-select" id="tableSelect" name="table_id" required>
                                                <?php foreach ($all_tables as $table): ?>
                                                <option value="<?php echo $table['idmeja']; ?>" 
                                                    <?php 
                                                    if ($table['idmeja'] == $table_id) {
                                                        echo 'selected';
                                                    } elseif ($table['status'] == 'terisi' && $table['idmeja'] != $table_id) {
                                                        echo 'disabled';
                                                    }
                                                    ?>>
                                                    Table <?php echo $table['idmeja']; ?> 
                                                    (<?php echo $table['kapasitas']; ?> seats) - 
                                                    <?php if ($table['status'] == 'tersedia'): ?>
                                                        <span class="text-success">Available</span>
                                                    <?php elseif ($table['idmeja'] == $table_id): ?>
                                                        <span class="text-warning">Current</span>
                                                    <?php else: ?>
                                                        <span class="text-danger">Occupied</span>
                                                    <?php endif; ?>
                                                </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="row g-3 mb-3">
                                        <div class="col-md-6">
                                            <label for="orderStatus" class="form-label">Status</label>
                                            <select class="form-select" id="orderStatus" name="order_status" required>
                                                <option value="new" <?php if ($order_status == 'new') echo 'selected'; ?>>New</option>
                                    
                                            
                                                <option value="ready" <?php if ($order_status == 'ready') echo 'selected'; ?>>Ready</option>
                                                <option value="completed" <?php if ($order_status == 'completed') echo 'selected'; ?>>Completed</option>
                                           
                                            </select>
                                        </div>
                                    </div>

                                    <div class="d-flex gap-2">
                                        <button type="submit" name="update_order" class="btn btn-primary">
                                            <i class="fas fa-save"></i> Update Order
                                        </button>
                                        <button type="submit" name="cancel_order" class="btn btn-danger" onclick="return confirm('Are you sure you want to cancel this order?');">
                                            <i class="fas fa-times"></i> Cancel Order
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <!-- Order Items -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Order Items</h5>
                            </div>
                            <div class="card-body">
                                <?php if (count($order_items) > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-hover table-order-items">
                                        <thead>
                                            <tr>
                                                <th>Item</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Subtotal</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($order_items as $item): ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($item['img']); ?>" class="menu-img">
                                                        <div>
                                                            <div class="fw-bold"><?php echo $item['namamenu']; ?></div>
                                                            <div class="text-muted small"><?php echo ucfirst($item['kategori']); ?></div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></td>
                                                <td><?php echo $item['jumlah']; ?></td>
                                                <td>Rp <?php echo number_format($item['harga'] * $item['jumlah'], 0, ',', '.'); ?></td>
                                                <td>
                                                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id=" . $order_id); ?>" class="d-inline">
                                                        <input type="hidden" name="item_id" value="<?php echo $item['idmenu']; ?>">
                                                        <input type="hidden" name="item_price" value="<?php echo $item['harga']; ?>">
                                                        <input type="hidden" name="item_quantity" value="<?php echo $item['jumlah']; ?>">
                                                        <button type="submit" name="remove_item" class="btn btn-sm btn-danger" onclick="return confirm('Remove this item from the order?');">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php else: ?>
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i> No items in this order yet. Add some items below.
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Add Items -->
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-plus me-2"></i>Add Items</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <input type="text" class="form-control" id="searchMenu" placeholder="Search menu items..." oninput="filterMenuItems()">
                                </div>
                                
                                <div class="row" id="menuItemsContainer">
                                    <?php foreach ($menu_items as $item): ?>
                                    <div class="col-md-6 menu-item-wrapper" data-name="<?php echo strtolower($item['namamenu']); ?>" data-category="<?php echo strtolower($item['kategori']); ?>">
                                        <div class="menu-item">
                                        <img src="data:image/jpeg;base64,<?php echo base64_encode($item['img']); ?>" class="menu-img">
                                            <div class="menu-details">
                                                <div class="menu-title"><?php echo $item['namamenu']; ?></div>
                                                <div class="menu-category"><?php echo ucfirst($item['kategori']); ?></div>
                                                <div class="menu-price">Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></div>
                                                <div class="mt-2">
                                                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id=" . $order_id); ?>" class="d-flex align-items-center gap-2">
                                                        <input type="hidden" name="item_id" value="<?php echo $item['idmenu']; ?>">
                                                        <div class="input-group input-group-sm" style="width: 80px;">
                                                            <button class="btn btn-outline-secondary" type="button" onclick="decrementQuantity(this)">-</button>
                                                            <input type="number" class="form-control text-center quantity-input" name="quantity" value="1" min="1" max="20">
                                                            <button class="btn btn-outline-secondary" type="button" onclick="incrementQuantity(this)">+</button>
                                                        </div>
                                                        <button type="submit" name="add_item" class="btn btn-sm btn-primary">
                                                            <i class="fas fa-plus"></i> Add
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Order Summary Section -->
                    <div class="col-lg-4">
                        <div class="card order-summary">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-receipt me-2"></i>Order Summary</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Subtotal:</span>
                                    <span>Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Tax (10%):</span>
                                    <span>Rp <?php echo number_format($tax, 0, ',', '.'); ?></span>
                                </div>
                                <hr>
                                <div class="d-flex justify-content-between fw-bold">
                                    <span>Total:</span>
                                    <span>Rp <?php echo number_format($total, 0, ',', '.'); ?></span>
                                </div>
                                
                                <div class="mt-4">
                                    <h6 class="mb-3">Customer Information</h6>
                                    <p class="mb-1"><strong>Name:</strong> <?php echo $order_details['namapelanggan']; ?></p>
                                    <p class="mb-1"><strong>Table:</strong> Table #<?php echo $table_id; ?></p>
                                </div>
                                
                                <div class="mt-4">
                                    <h6 class="mb-3">Order Timeline</h6>
                                    <div class="order-timeline">
                                        <div class="timeline-item">
                                            <div class="timeline-point"></div>
                                            <div class="timeline-content">
                                                <small class="text-muted"><?php echo date('d M Y H:i', strtotime($order_time)); ?></small>
                                                <div>Order Created</div>
                                            </div>
                                        </div>
                                        
                                        <?php if ($order_status == 'processing' || $order_status == 'ready' || $order_status == 'completed'): ?>
                                        <div class="timeline-item">
                                            <div class="timeline-point"></div>
                                            <div class="timeline-content">
                                                <small class="text-muted"><?php echo date('d M Y H:i', strtotime('+5 minutes', strtotime($order_time))); ?></small>
                                                <div>Processing</div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($order_status == 'ready' || $order_status == 'completed'): ?>
                                        <div class="timeline-item">
                                            <div class="timeline-point"></div>
                                            <div class="timeline-content">
                                                <small class="text-muted"><?php echo date('d M Y H:i', strtotime('+15 minutes', strtotime($order_time))); ?></small>
                                                <div>Ready to Serve</div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($order_status == 'completed'): ?>
                                        <div class="timeline-item">
                                            <div class="timeline-point"></div>
                                            <div class="timeline-content">
                                                <small class="text-muted"><?php echo date('d M Y H:i', strtotime('+30 minutes', strtotime($order_time))); ?></small>
                                                <div>Completed</div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($order_status == 'cancelled'): ?>
                                        <div class="timeline-item">
                                            <div class="timeline-point"></div>
                                            <div class="timeline-content">
                                                <small class="text-muted"><?php echo date('d M Y H:i', strtotime('+2 minutes', strtotime($order_time))); ?></small>
                                                <div class="text-danger">Cancelled</div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        
        function filterMenuItems() {
            const searchTerm = document.getElementById('searchMenu').value.toLowerCase();
            const menuItems = document.querySelectorAll('.menu-item-wrapper');
            
            menuItems.forEach(item => {
                const itemName = item.getAttribute('data-name');
                const itemCategory = item.getAttribute('data-category');
                
                if (itemName.includes(searchTerm) || itemCategory.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        }
        
     
        function incrementQuantity(button) {
            const input = button.parentElement.querySelector('input');
            const currentValue = parseInt(input.value);
            if (currentValue < 20) {
                input.value = currentValue + 1;
            }
        }
        

        function decrementQuantity(button) {
            const input = button.parentElement.querySelector('input');
            const currentValue = parseInt(input.value);
            if (currentValue > 1) {
                input.value = currentValue - 1;
            }
        }
        

        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }, 5000);
            });
        });
    </script>
</body>
</html>
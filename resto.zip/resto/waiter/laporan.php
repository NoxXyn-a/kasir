<?php

require_once "config.php";


session_start();


$success_message = "";
$error_message = "";

function getTransactions($conn, $dateFrom = null, $dateTo = null, $paymentMethod = null) {
    $query = "SELECT t.idtransaksi, t.idpesanan, t.total, t.bayar, t.order_invoice, 
                     t.metode_pembayaran, t.date, p.idpelanggan 
              FROM transaksi t 
              JOIN pesanan p ON t.idpesanan = p.idpesanan";
    
    $conditions = [];
    $params = [];
    
    if ($dateFrom) {
        
        $dateFrom = $dateFrom . ' 00:00:00';
        $conditions[] = "t.date >= ?";
        $params[] = $dateFrom;
    }
    
    if ($dateTo) {
    
        $dateTo = $dateTo . ' 23:59:59';
        $conditions[] = "t.date <= ?";
        $params[] = $dateTo;
    }
    
    if ($paymentMethod && $paymentMethod != 'all') {
        $conditions[] = "t.metode_pembayaran = ?";
        $params[] = $paymentMethod;
    }
    
    if (!empty($conditions)) {
        $query .= " WHERE " . implode(" AND ", $conditions);
    }
    
    $query .= " ORDER BY t.date DESC";
    
    $stmt = $conn->prepare($query);
    
    if (!empty($params)) {
        $types = str_repeat("s", count($params));
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $transactions = [];
    
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
    
    return $transactions;
}


function getCustomerName($conn, $idpelanggan) {
    $stmt = $conn->prepare("SELECT namapelanggan FROM pelanggan WHERE idpelanggan = ?");
    $stmt->bind_param("i", $idpelanggan);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return $row['namapelanggan'];
    }
    
    return "Table #" . $idpelanggan; 
}


function formatCurrency($amount) {
    return "Rp " . number_format($amount, 0, ',', '.');
}


function calculateSummary($transactions) {
    $summary = [
        'total_transactions' => count($transactions),
        'total_revenue' => 0,
        'payment_methods' => [
            'cash' => 0,
            'debit' => 0,
            'kredit_card' => 0,
            'qris' => 0
        ]
    ];
    
    foreach ($transactions as $transaction) {
        $summary['total_revenue'] += $transaction['total'];
        
     
        if (isset($summary['payment_methods'][$transaction['metode_pembayaran']])) {
            $summary['payment_methods'][$transaction['metode_pembayaran']]++;
        }
    }
    
    return $summary;
}


$dateFrom = isset($_GET['dateFrom']) ? $_GET['dateFrom'] : date('Y-m-d', strtotime('-30 days'));
$dateTo = isset($_GET['dateTo']) ? $_GET['dateTo'] : date('Y-m-d');
$paymentMethod = isset($_GET['paymentMethod']) ? $_GET['paymentMethod'] : 'all';


$transactions = getTransactions($conn, $dateFrom, $dateTo, $paymentMethod);
$summary = calculateSummary($transactions);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ravine Resto | Transactions Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg,rgb(180, 180, 180),rgb(196, 196, 196));
            --primary-color:rgb(99, 99, 99);      
            --primary-dark:rgb(107, 107, 107);        
            --primary-light: #F3EAFB;     
            --accent-color: #ffffff;
            --text-dark: #333333;           
            --text-light: #000000;
                }

            body {
                font-family: 'Poppins', sans-serif;
                background: #f4f4f9;
                color: var(--text-dark); 
            }

            .sidebar {
                min-height: 100vh;
                background: var(--primary-gradient);
                color: var(--text-light); /* Menggunakan teks hitam di sidebar untuk kontras */
                transition: all 0.3s;
            }

            .sidebar .logo-container {
                padding: 20px 15px;
                display: flex;
                flex-direction: column;
                align-items: center;
            }

            .sidebar .logo {
                width: 80px;
                height: 80px;
                margin-bottom: 15px;
                border-radius: 50%;
                object-fit: cover;
                border: 3px solid #fff;
            }

            .sidebar .nav-link {
                color: var(--text-light); /* Mengubah warna teks link menjadi hitam */
                border-radius: 8px;
                margin: 5px 10px;
                transition: background 0.3s ease;
            }

            .sidebar .nav-link:hover,
            .sidebar .nav-link.active {
                background-color: rgba(0, 0, 0, 0.1); /* Menambahkan latar belakang saat hover */
                color: #fff;
            }

            .sidebar .nav-link i {
                margin-right: 10px;
                width: 20px;
                text-align: center;
            }
        .card {
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,.1);
            margin-bottom: 20px;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 8px 8px 0 0 !important;
            font-weight: 600;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-dark);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
        }
        
        .badge-paid {
            background-color: #28a745;
            color: white;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 12px;
        }
        
        .transaction-detail:hover {
            background-color: rgba(0,0,0,.03);
        }
        
        .date-filter {
            width: 150px;
        }
     
        @media print {
            .sidebar, .no-print, .btn, .modal, .form-control, .form-select {
                display: none !important;
            }
            
            .col-md-9, .col-lg-10 {
                width: 100% !important;
                flex: 0 0 100% !important;
                max-width: 100% !important;
                margin-left: 0 !important;
            }
            
            .card {
                box-shadow: none;
                border: 1px solid #ddd;
            }
            
            .card-header {
                background-color: #f8f9fa !important;
                color: #212529 !important;
                border-bottom: 1px solid #ddd !important;
            }
            
            .table {
                width: 100% !important;
            }
            
            body {
                padding: 0 !important;
                margin: 0 !important;
            }
            
            .print-header {
                display: block !important;
                text-align: center;
                margin-bottom: 20px;
            }
        }
        
        .print-header {
            display: none;
        }
        
        .summary-card {
            border-left: 4px solid var(--primary-color);
        }
        .logout-btn {
            display: flex;
            align-items: center;
            background-color: white;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
            border-radius: 50px;
            padding: 8px 16px;
            font-weight: bold;
            transition: all 0.3s ease;
            margin: 15px 10px;
        }

        .logout-btn:hover {
            background-color: var(--primary-color);
            color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            transform: translateY(-2px);
        }

        .logout-btn i {
            margin-right: 8px;
        }

    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
     
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="logo-container">
                    <img src="../img/ravine.png" alt="Restaurant Logo" class="logo">
                    <h5 class="text-center mb-3">Ravine Resto</h5>
                </div>
                <ul class="nav flex-column">
                <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="fas fa-utensils"></i> Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="order.php">
                            <i class="fas fa-shopping-cart"></i> Order
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="pelanggan.php">
                            <i class="fas fa-users"></i> Customers
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="laporan.php">
                            <i class="fas fa-file-alt"></i> Laporan
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <button class="logout-btn" id="logoutBtn">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                    </li>
                </ul>
            </div>

          
            <div class="col-md-9 col-lg-10 ms-sm-auto px-md-4 py-4">
           
                <div class="print-header">
                    <h2>Transaction Report</h2>
                    <p>Ravine Resto</p>
                    <p>Report Period: <?php echo date('d/m/Y', strtotime($dateFrom)); ?> - <?php echo date('d/m/Y', strtotime($dateTo)); ?></p>
                </div>
                
             
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom no-print">
                    <h1 class="h2">Transaction Report</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-sm btn-primary me-2" onclick="window.print()">
                            <i class="fas fa-print"></i> Print Report
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="exportCSV">
                            <i class="fas fa-download"></i> Export CSV
                        </button>
                    </div>
                </div>

           
                <div class="card mb-4 no-print">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <form class="row g-3" method="GET">
                                    <div class="col-md-3">
                                        <label for="dateFrom" class="form-label">Date From</label>
                                        <input type="date" class="form-control" id="dateFrom" name="dateFrom" value="<?php echo $dateFrom; ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="dateTo" class="form-label">Date To</label>
                                        <input type="date" class="form-control" id="dateTo" name="dateTo" value="<?php echo $dateTo; ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="paymentMethod" class="form-label">Payment Method</label>
                                        <select class="form-select" id="paymentMethod" name="paymentMethod">
                                            <option value="all" <?php echo $paymentMethod == 'all' ? 'selected' : ''; ?>>All Methods</option>
                                            <option value="cash" <?php echo $paymentMethod == 'cash' ? 'selected' : ''; ?>>Cash</option>
                                            <option value="debit" <?php echo $paymentMethod == 'debit' ? 'selected' : ''; ?>>Debit Card</option>
                                            <option value="kredit_card" <?php echo $paymentMethod == 'kredit_card' ? 'selected' : ''; ?>>Credit Card</option>
                                            <option value="qris" <?php echo $paymentMethod == 'qris' ? 'selected' : ''; ?>>QRIS</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3 d-flex align-items-end">
                                        <button type="submit" class="btn btn-primary me-2">
                                            <i class="fas fa-filter"></i> Apply Filter
                                        </button>
                                        <a href="laporan.php" class="btn btn-outline-secondary">
                                            <i class="fas fa-redo"></i> Reset
                                        </a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

           
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card summary-card">
                            <div class="card-body">
                                <h6 class="card-title text-muted">Total Transactions</h6>
                                <h3 class="fw-bold"><?php echo $summary['total_transactions']; ?></h3>
                                <p class="text-muted mb-0">From <?php echo date('d M Y', strtotime($dateFrom)); ?> to <?php echo date('d M Y', strtotime($dateTo)); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card summary-card">
                            <div class="card-body">
                                <h6 class="card-title text-muted">Total Revenue</h6>
                                <h3 class="fw-bold"><?php echo formatCurrency($summary['total_revenue']); ?></h3>
                                <p class="text-muted mb-0">All payment methods</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card summary-card">
                            <div class="card-body">
                                <h6 class="card-title text-muted">Cash Payments</h6>
                                <h3 class="fw-bold"><?php echo $summary['payment_methods']['cash']; ?></h3>
                                <p class="text-muted mb-0"><?php echo round(($summary['payment_methods']['cash'] / max(1, $summary['total_transactions'])) * 100); ?>% of total</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card summary-card">
                            <div class="card-body">
                                <h6 class="card-title text-muted">Digital Payments</h6>
                                <h3 class="fw-bold"><?php echo $summary['payment_methods']['debit'] + $summary['payment_methods']['kredit_card'] + $summary['payment_methods']['qris']; ?></h3>
                                <p class="text-muted mb-0">Debit, Credit & QRIS</p>
                            </div>
                        </div>
                    </div>
                </div>

              
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>Transaction Report</span>
                        <span class="badge bg-primary"><?php echo count($transactions); ?> transactions</span>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0" id="transactionTable">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Transaction ID</th>
                                        <th>Date</th>
                                        <th>Customer</th>
                                        <th>Total</th>
                                        <th>Payment Method</th>
                                        <th class="no-print">Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($transactions)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No transactions found for this period</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($transactions as $index => $transaction): ?>
                                    <tr class="transaction-detail">
                                        <td><?php echo $index + 1; ?></td>
                                        <td><?php echo $transaction['order_invoice']; ?></td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($transaction['date'])); ?></td>
                                        <td><?php echo getCustomerName($conn, $transaction['idpelanggan']); ?></td>
                                        <td><?php echo formatCurrency($transaction['total']); ?></td>
                                        <td><?php echo ucfirst($transaction['metode_pembayaran']); ?></td>
                                        <td class="no-print">
                                            <button class="btn btn-sm btn-info view-transaction" data-id="<?php echo $transaction['idtransaksi']; ?>" data-bs-toggle="modal" data-bs-target="#viewTransactionModal">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-sm btn-secondary print-receipt" data-id="<?php echo $transaction['idtransaksi']; ?>">
                                                <i class="fas fa-print"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="row">
                            <div class="col-md-6">
                                <p class="mb-0">Report generated on: <?php echo date('d/m/Y H:i'); ?></p>
                            </div>
                            <div class="col-md-6 text-end">
                                <p class="mb-0">Total Revenue: <?php echo formatCurrency($summary['total_revenue']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                
               
                <div class="card mt-4">
                    <div class="card-header">
                        <span>Payment Method Breakdown</span>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <h6>Cash</h6>
                                    <p class="mb-0"><?php echo $summary['payment_methods']['cash']; ?> transactions</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <h6>Debit Card</h6>
                                    <p class="mb-0"><?php echo $summary['payment_methods']['debit']; ?> transactions</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <h6>Credit Card</h6>
                                    <p class="mb-0"><?php echo $summary['payment_methods']['kredit_card']; ?> transactions</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <h6>QRIS</h6>
                                    <p class="mb-0"><?php echo $summary['payment_methods']['qris']; ?> transactions</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="viewTransactionModal" tabindex="-1" aria-labelledby="viewTransactionModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title" id="viewTransactionModalLabel">Transaction Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="viewTransactionBody">
                    <div class="text-center">
                        <div class="spinner-border" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-info" id="printDetailBtn">Print Receipt</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
          
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            });
            
          
            const viewButtons = document.querySelectorAll('.view-transaction');
            viewButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const transactionId = this.getAttribute('data-id');
                    viewTransactionDetails(transactionId);
                });
            });
            
            function viewTransactionDetails(transactionId) {
           
                fetch('get_transaction_details.php?transaction_id=' + transactionId)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            displayTransactionDetails(data.transaction);
                        } else {
                            document.getElementById('viewTransactionBody').innerHTML = 
                                '<div class="alert alert-danger">Failed to load transaction details.</div>';
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching transaction details:', error);
                        document.getElementById('viewTransactionBody').innerHTML = 
                            '<div class="alert alert-danger">An error occurred while loading transaction details.</div>';
                    });
                
              
                document.getElementById('printDetailBtn').setAttribute('data-id', transactionId);
            }
           
            document.querySelectorAll('.print-receipt').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.stopPropagation(); 
                    const transactionId = this.getAttribute('data-id');
                    printReceipt(transactionId);
                });
            });
            
            document.getElementById('printDetailBtn').addEventListener('click', function() {
                const transactionId = this.getAttribute('data-id');
                printReceipt(transactionId);
            });
            
            function printReceipt(transactionId) {
                window.open('print_receipt.php?transaction_id=' + transactionId, '_blank');
            }
            

            document.getElementById('exportCSV').addEventListener('click', function() {
                exportTableToCSV('transaction_report.csv');
            });
            
            function exportTableToCSV(filename) {
                const table = document.getElementById('transactionTable');
                let csv = [];
                const rows = table.querySelectorAll('tr');
                
                for (let i = 0; i < rows.length; i++) {
                    const row = [];
                    const cols = rows[i].querySelectorAll('td, th');
                    
                    for (let j = 0; j < cols.length - 1; j++) { 
                        row.push('"' + cols[j].innerText.replace(/"/g, '""') + '"');
                    }
                    
                    csv.push(row.join(','));
                }
                
                // Download CSV file
                downloadCSV(csv.join('\n'), filename);
            }
            
            function downloadCSV(csv, filename) {
                let csvFile = new Blob([csv], {type: "text/csv"});
                let downloadLink = document.createElement("a");
                
                downloadLink.download = filename;
                downloadLink.href = window.URL.createObjectURL(csvFile);
                downloadLink.style.display = "none";
                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);
            }
            
      
            function formatNumber(number) {
                return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            }
            
            function displayTransactionDetails(transaction) {
                let html = `
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Transaction Information</h6>
                            <p class="mb-1"><strong>Invoice:</strong> ${transaction.order_invoice}</p>
                            <p class="mb-1"><strong>Date:</strong> ${transaction.date}</p>
                            <p class="mb-1"><strong>Payment Method:</strong> ${transaction.metode_pembayaran}</p>
                            <p class="mb-1"><strong>Amount Paid:</strong> Rp ${formatNumber(transaction.bayar)}</p>
                        </div>
                        <div class="col-md-6">
                            <h6>Order Information</h6>
                            <p class="mb-1"><strong>Order ID:</strong> ORD-${transaction.order.idpesanan}</p>
                            <p class="mb-1"><strong>Customer:</strong> Table #${transaction.order.idpelanggan}</p>
                            <p class="mb-1"><strong>Server:</strong> ${transaction.order.namauser}</p>
                        </div>
                    </div>
                    
                    <h6>Order Items</h6>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th class="text-center">Qty</th>
                                    <th class="text-end">Price</th>
                                    <th class="text-end">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                transaction.items.forEach(item => {
                    html += `
                        <tr>
                            <td>${item.namamenu}</td>
                            <td class="text-center">${item.jumlah}</td>
                            <td class="text-end">Rp ${formatNumber(item.harga)}</td>
                            <td class="text-end">Rp ${formatNumber(item.subtotal)}</td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="3" class="text-end">Subtotal:</th>
                                    <th class="text-end">Rp ${formatNumber(transaction.subtotal)}</th>
                                </tr>
                                <tr>
                                    <th colspan="3" class="text-end">Tax (10%):</th>
                                    <th class="text-end">Rp ${formatNumber(transaction.tax)}</th>
                                </tr>
                                <tr>
                                    <th colspan="3" class="text-end">Total:</th>
                                    <th class="text-end">Rp ${formatNumber(transaction.total)}</th>
                                </tr>
                `;
                
                
                if (transaction.metode_pembayaran === 'cash' && parseFloat(transaction.bayar) > parseFloat(transaction.total)) {
                    const change = parseFloat(transaction.bayar) - parseFloat(transaction.total);
                    html += `
                        <tr>
                            <th colspan="3" class="text-end">Amount Paid:</th>
                            <th class="text-end">Rp ${formatNumber(transaction.bayar)}</th>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-end">Change:</th>
                            <th class="text-end">Rp ${formatNumber(change)}</th>
                        </tr>
                    `;
                }
                
                html += `
                            </tfoot>
                        </table>
                    </div>
                `;
                
                document.getElementById('viewTransactionBody').innerHTML = html;
            }
        });
        document.getElementById('logoutBtn').addEventListener('click', confirmLogout);
document.getElementById('dropdownLogoutBtn').addEventListener('click', confirmLogout);
function confirmLogout() {
            Swal.fire({
                title: 'Logout Confirmation',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#C41E3A',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, Logout',
                cancelButtonText: 'Cancel',
                customClass: {
                    confirmButton: 'btn btn-danger',
                    cancelButton: 'btn btn-secondary'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Logged Out!',
                        text: 'You have been successfully logged out.',
                        confirmButtonColor: '#C41E3A',
                        timer: 1500,
                        timerProgressBar: true,
                        willClose: () => {
                            window.location.href = 'logout.php';
                        }
                    });
                }
            });
        }
    </script>
</body>
</html>
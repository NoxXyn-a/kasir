<?php
session_start();
$host = "localhost";
$username = "root"; 
$password = ""; 
$database = "rehan";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (!isset($_SESSION['order_items'])) {
    $_SESSION['order_items'] = [];
}

$customer_name = "";
$table_number = "";
$menu_items = [];
$available_tables = [];
$customers = [];

$tables_query = "SELECT idmeja, kapasitas FROM meja WHERE status = 'tersedia'";
$tables_result = mysqli_query($conn, $tables_query);
if ($tables_result) {
    while ($table = mysqli_fetch_assoc($tables_result)) {
        $available_tables[] = $table;
    }
}


$all_tables_query = "SELECT idmeja, kapasitas, status FROM meja";
$all_tables_result = mysqli_query($conn, $all_tables_query);
$all_tables = [];
if ($all_tables_result) {
    while ($table = mysqli_fetch_assoc($all_tables_result)) {
        $all_tables[] = $table;
    }
}


$menu_query = "SELECT m.idmenu, m.namamenu, m.harga, m.img, m.deskripsi, m.kategori FROM menu m";
$menu_result = mysqli_query($conn, $menu_query);
if ($menu_result) {
    while ($item = mysqli_fetch_assoc($menu_result)) {
        $menu_items[] = $item;
    }
}


$customers_query = "SELECT idpelanggan, namapelanggan FROM pelanggan";
$customers_result = mysqli_query($conn, $customers_query);
if ($customers_result) {
    while ($customer = mysqli_fetch_assoc($customers_result)) {
        $customers[] = $customer;
    }
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['add_item'])) {
        $item_id = $_POST['item_id'];
        $quantity = $_POST['quantity'];
        
        if ($quantity > 0) {
         
            $item_query = "SELECT idmenu, namamenu, harga FROM menu WHERE idmenu = $item_id";
            $item_result = mysqli_query($conn, $item_query);
            $item = mysqli_fetch_assoc($item_result);
            
            if ($item) {
        
                $found = false;
                foreach ($_SESSION['order_items'] as &$order_item) {
                    if ($order_item['id'] == $item_id) {
                        $order_item['quantity'] += $quantity;
                        $found = true;
                        break;
                    }
                }
                
           
                if (!$found) {
                    $_SESSION['order_items'][] = [
                        'id' => $item_id,
                        'name' => $item['namamenu'],
                        'price' => $item['harga'],
                        'quantity' => $quantity
                    ];
                }
                
             
                $_SESSION['success_message'] = "Item added to order!";
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            }
        }
    }
    

    if (isset($_POST['remove_item'])) {
        $item_id = $_POST['item_id'];
        
        foreach ($_SESSION['order_items'] as $key => $item) {
            if ($item['id'] == $item_id) {
                unset($_SESSION['order_items'][$key]);
                break;
            }
        }
        
   
        $_SESSION['order_items'] = array_values($_SESSION['order_items']);
        
  
        $_SESSION['success_message'] = "Item removed from order!";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
    
  
    if (isset($_POST['save_order'])) {
   
        if (isset($_POST['customer_id'])) {
            $idpelanggan = $_POST['customer_id'];
        } else {

            $customer_name = $_POST['customer_name'] ?? '';
            if (!empty($customer_name)) {
                $query = "SELECT idpelanggan FROM pelanggan WHERE namapelanggan = ?";
                $stmt = mysqli_prepare($conn, $query);
                mysqli_stmt_bind_param($stmt, "s", $customer_name);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                if ($row = mysqli_fetch_assoc($result)) {
                    $idpelanggan = $row['idpelanggan'];
                }
            }
        }
        
        $table_id = $_POST['table_number'] ?? '';
        
  
        if (empty($idpelanggan)) {
            $_SESSION['error_message'] = "Customer ID is missing. Please select a customer.";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        }
        
        if (empty($table_id)) {
            $_SESSION['error_message'] = "Table number is missing. Please select a table.";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        }
        
        if (empty($_SESSION['order_items'])) {
            $_SESSION['error_message'] = "No items in order. Please add at least one item.";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        }
        $iduser = $_SESSION['user_id'] ?? 1; 
        
        $subtotal = 0;
        foreach ($_SESSION['order_items'] as $item) {
            $subtotal += $item['price'] * $item['quantity'];
        }
        
       
        $time = date('Y-m-d H:i:s');
        

        $invoice_prefix = "INV";
        $date_code = date('Ymd');
        $random_suffix = mt_rand(1000, 9999);
        $order_invoice = $invoice_prefix . '-' . $date_code . '-' . $random_suffix;
        
     
        mysqli_begin_transaction($conn);
        
        try {
      
            $order_insert_query = "INSERT INTO pesanan (idpelanggan, iduser, idmeja, time, status, order_invoice) 
                                  VALUES (?, ?, ?, ?, 'ready', ?)";
            
            $stmt = mysqli_prepare($conn, $order_insert_query);
            mysqli_stmt_bind_param($stmt, "iiiss", $idpelanggan, $iduser, $table_id, $time, $order_invoice);
            
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception("Error creating order: " . mysqli_stmt_error($stmt));
            }
            
    
            $idpesanan = mysqli_insert_id($conn);
            
            if (!$idpesanan) {
                throw new Exception("Failed to get pesanan ID");
            }
            
         
            $detail_insert_query = "INSERT INTO detail_pesanan (idpesanan, idmenu, jumlah, harga) VALUES (?, ?, ?, ?)";
            $detail_stmt = mysqli_prepare($conn, $detail_insert_query);
            
            foreach ($_SESSION['order_items'] as $item) {
                $idmenu = $item['id'];
                $jumlah = $item['quantity'];
                $harga = $item['price'];
                
                mysqli_stmt_bind_param($detail_stmt, "iiid", $idpesanan, $idmenu, $jumlah, $harga);
                
                if (!mysqli_stmt_execute($detail_stmt)) {
                    throw new Exception("Error inserting order detail: " . mysqli_stmt_error($detail_stmt));
                }
            }
            
            $transaction_status = 'belum_dibayar'; 
            $transaksi_query = "INSERT INTO transaksi (idpesanan, total, order_invoice, status) VALUES (?, ?, ?, ?)";
            $transaksi_stmt = mysqli_prepare($conn, $transaksi_query);
            mysqli_stmt_bind_param($transaksi_stmt, "idss", $idpesanan, $subtotal, $order_invoice, $transaction_status);
            
            if (!mysqli_stmt_execute($transaksi_stmt)) {
                throw new Exception("Error creating transaction: " . mysqli_stmt_error($transaksi_stmt));
            }
            

            $update_table = "UPDATE meja SET status = 'terisi' WHERE idmeja = ?";
            $table_stmt = mysqli_prepare($conn, $update_table);
            mysqli_stmt_bind_param($table_stmt, "i", $table_id);
            
            if (!mysqli_stmt_execute($table_stmt)) {
                throw new Exception("Error updating table status: " . mysqli_stmt_error($table_stmt));
            }
            
   
            mysqli_commit($conn);
            
         
            $_SESSION['order_items'] = [];
            
         
            $_SESSION['success_message'] = "Order #$order_invoice saved successfully!";
            
        
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
            
        } catch (Exception $e) {
       
            mysqli_rollback($conn);
            
            $_SESSION['error_message'] = "Error creating order: " . $e->getMessage();
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        }
    }
    
  
    if (isset($_POST['update_order'])) {
        $order_id = $_POST['edit_order_id'];
        $idpelanggan = $_POST['edit_customer_id'];
        $new_table_id = $_POST['edit_table_number'];
        $order_status = $_POST['edit_order_status'];
        
        if (!empty($order_id) && !empty($idpelanggan) && !empty($new_table_id)) {

            mysqli_begin_transaction($conn);
            
            try {
      
                $get_current_table = "SELECT idmeja FROM pesanan WHERE idpesanan = ?";
                $current_table_stmt = mysqli_prepare($conn, $get_current_table);
                mysqli_stmt_bind_param($current_table_stmt, "i", $order_id);
                mysqli_stmt_execute($current_table_stmt);
                $result = mysqli_stmt_get_result($current_table_stmt);
                $current_order = mysqli_fetch_assoc($result);
                $old_table_id = $current_order['idmeja'];
                
             
                $update_order = "UPDATE pesanan SET idpelanggan = ?, idmeja = ?, status = ? WHERE idpesanan = ?";
                $update_stmt = mysqli_prepare($conn, $update_order);
                mysqli_stmt_bind_param($update_stmt, "iisi", $idpelanggan, $new_table_id, $order_status, $order_id);
                
                if (!mysqli_stmt_execute($update_stmt)) {
                    throw new Exception("Error updating order: " . mysqli_stmt_error($update_stmt));
                }
                
           
                if ($old_table_id != $new_table_id) {
             
                    $update_old_table = "UPDATE meja SET status = 'tersedia' WHERE idmeja = ?";
                    $old_table_stmt = mysqli_prepare($conn, $update_old_table);
                    mysqli_stmt_bind_param($old_table_stmt, "i", $old_table_id);
                    
                    if (!mysqli_stmt_execute($old_table_stmt)) {
                        throw new Exception("Error updating old table status: " . mysqli_stmt_error($old_table_stmt));
                    }

                    $update_new_table = "UPDATE meja SET status = 'terisi' WHERE idmeja = ?";
                    $new_table_stmt = mysqli_prepare($conn, $update_new_table);
                    mysqli_stmt_bind_param($new_table_stmt, "i", $new_table_id);
                    
                    if (!mysqli_stmt_execute($new_table_stmt)) {
                        throw new Exception("Error updating new table status: " . mysqli_stmt_error($new_table_stmt));
                    }
                }
                
       
                mysqli_commit($conn);
                
              
                $_SESSION['success_message'] = "Order #$order_id updated successfully!";
             
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
                
            } catch (Exception $e) {
          
                mysqli_rollback($conn);
                
                $_SESSION['error_message'] = "Error updating order: " . $e->getMessage();
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            }
        } else {
            $_SESSION['error_message'] = "Please fill all required fields for order update.";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        }
    }
}


$subtotal = 0;
foreach ($_SESSION['order_items'] as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
$tax = $subtotal * 0.1; 
$total = $subtotal + $tax;


$active_orders = [];
$orders_query = "SELECT p.idpesanan, pl.namapelanggan, pl.idpelanggan, m.idmeja, 
                COUNT(dp.idmenu) as item_count,
                SUM(dp.harga * dp.jumlah) as total, 
                p.status,
                p.time,
                p.order_invoice
                FROM pesanan p 
                JOIN pelanggan pl ON p.idpelanggan = pl.idpelanggan
                JOIN meja m ON p.idmeja = m.idmeja
                JOIN detail_pesanan dp ON p.idpesanan = dp.idpesanan
                GROUP BY p.idpesanan
                ORDER BY p.time DESC
                LIMIT 5";
$orders_result = mysqli_query($conn, $orders_query);
if ($orders_result) {
    while ($order = mysqli_fetch_assoc($orders_result)) {
        $active_orders[] = $order;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ravine Resto | Order Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css">
     <style>
           :root {
            --primary-gradient: linear-gradient(135deg,rgb(180, 180, 180),rgb(196, 196, 196));
            --primary-color:rgb(99, 99, 99);      
            --primary-dark:rgb(107, 107, 107);        
            --primary-light: #F3EAFB;     
            --accent-color: #ffffff;
            --text-dark: #333333;           
            --text-light: #000000;
                }

            body {
                font-family: 'Poppins', sans-serif;
                background: #f4f4f9;
                color: var(--text-dark); 
            }

            .sidebar {
                min-height: 100vh;
                background: var(--primary-gradient);
                color: var(--text-light); /* Menggunakan teks hitam di sidebar untuk kontras */
                transition: all 0.3s;
            }

            .sidebar .logo-container {
                padding: 20px 15px;
                display: flex;
                flex-direction: column;
                align-items: center;
            }

            .sidebar .logo {
                width: 80px;
                height: 80px;
                margin-bottom: 15px;
                border-radius: 50%;
                object-fit: cover;
                border: 3px solid #fff;
            }

            .sidebar .nav-link {
                color: var(--text-light); /* Mengubah warna teks link menjadi hitam */
                border-radius: 8px;
                margin: 5px 10px;
                transition: background 0.3s ease;
            }

            .sidebar .nav-link:hover,
            .sidebar .nav-link.active {
                background-color: rgba(0, 0, 0, 0.1); /* Menambahkan latar belakang saat hover */
                color: #fff;
            }

            .sidebar .nav-link i {
                margin-right: 10px;
                width: 20px;
                text-align: center;
            }

        .content-area {
            padding: 20px;
        }

        .page-header {
            border-bottom: 1px solid #dee2e6;
            margin-bottom: 20px;
            padding-bottom: 10px;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-dark);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }

        .card {
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 8px 8px 0 0 !important;
        }

        .table-container {
            overflow-x: auto;
        }

        .table th {
            background-color: #f8f9fa;
        }

        .menu-item {
            display: flex;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            margin-bottom: 15px;
            overflow: hidden;
            transition: transform 0.2s;
        }

        .menu-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .menu-img {
            width: 100px;
            height: 100px;
            object-fit: cover;
        }

        .menu-details {
            padding: 10px;
            flex-grow: 1;
        }

        .menu-title {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .menu-price {
            color: var(--primary-color);
            font-weight: bold;
        }

        .menu-category {
            font-size: 0.85rem;
            color: #6c757d;
        }

        .quantity-input {
            width: 60px;
            text-align: center;
        }

        .order-summary {
            position: sticky;
            top: 20px;
        }

        .badge-available {
            background-color: #28a745;
            color: white;
        }

        .badge-low {
            background-color: #ffc107;
            color: #212529;
        }

        .badge-status {
            font-size: 0.75rem;
            padding: 5px 8px;
            border-radius: 12px;
        }

        .table-order-items th, 
        .table-order-items td {
            vertical-align: middle;
        }

        .action-buttons .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        .logout-btn {
            display: flex;
            align-items: center;
            background-color: white;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
            border-radius: 50px;
            padding: 8px 16px;
            font-weight: bold;
            transition: all 0.3s ease;
            margin: 15px 10px;
        }

        .logout-btn:hover {
            background-color: var(--primary-color);
            color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            transform: translateY(-2px);
        }

        .logout-btn i {
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="logo-container">
                    <img src="../img/ravine.png" alt="Restaurant Logo" class="logo">
                    <h5 class="text-center mb-3">Ravine Resto</h5>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="fas fa-utensils"></i> Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="order.php">
                            <i class="fas fa-shopping-cart"></i> Order
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="pelanggan.php">
                            <i class="fas fa-users"></i> Customers
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">
                            <i class="fas fa-file-alt"></i> Laporan
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <button class="logout-btn" id="logoutBtn">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                    </li>
                
                </ul>
            </div>

            <div class="col-md-9 col-lg-10 content-area">
              
                <div class="page-header d-flex justify-content-between align-items-center">
                    <h2>Order Management</h2>
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle"></i> Waiter
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>

      
                <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['success_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['success_message']); ?>
                <?php endif; ?>

             
                <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['error_message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['error_message']); ?>
                <?php endif; ?>

               
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Create New Order</h5>
                                <button class="btn btn-sm btn-light" data-bs-toggle="collapse" data-bs-target="#orderForm">
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                            </div>
                            <div class="card-body collapse show" id="orderForm">
                                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                    <div class="row g-3 mb-3">
                                        <div class="col-md-6">
                                            <label for="customerSelect" class="form-label">Customer</label>
                                            <select class="form-control" id="customerSelect" name="customer_id" required>
                                                <option value="">Select customer</option>
                                                <?php foreach ($customers as $customer): ?>
                                                <option value="<?php echo $customer['idpelanggan']; ?>"><?php echo $customer['namapelanggan']; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="tableNumber" class="form-label">Table Number</label>
                                            <select class="form-control" id="tableNumber" name="table_number" required>
                                                <option value="">Select table</option>
                                                <?php foreach ($available_tables as $table): ?>
                                                <option value="<?php echo $table['idmeja']; ?>">Table <?php echo $table['idmeja']; ?> (Capacity: <?php echo $table['kapasitas']; ?>)</option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Menu Items</label>
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" placeholder="Search menu items..." id="menuSearch">
                                            <button class="btn btn-outline-secondary" type="button" id="searchBtn">
                                                <i class="fas fa-search"></i>
                                            </button>
                                        </div>

                                        <div class="menu-items-container">
                                            <?php foreach ($menu_items as $item): ?>
                                            <div class="menu-item" data-category="<?php echo $item['kategori']; ?>" data-name="<?php echo $item['namamenu']; ?>">
                                            <img src="data:image/jpeg;base64,<?php echo base64_encode($item['img']); ?>" class="menu-img" alt="<?php echo $item['namamenu']; ?>">
                                                <div class="menu-details d-flex flex-grow-1 justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="menu-title"><?php echo $item['namamenu']; ?></h6>
                                                        <div class="menu-category"><?php echo $item['kategori']; ?></div>
                                                        <div class="menu-price">Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></div>
                                                        <span class="badge badge-status badge-available">Available</span>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="d-flex align-items-center">
                                                            <input type="hidden" name="item_id" value="<?php echo $item['idmenu']; ?>">
                                                            <div class="input-group input-group-sm me-2">
                                                                <button class="btn btn-outline-secondary qty-btn" type="button" data-action="decrease"><i class="fas fa-minus"></i></button>
                                                                <input type="number" name="quantity" class="form-control quantity-input" value="1" min="1" style="width: 60px;">
                                                                <button class="btn btn-outline-secondary qty-btn" type="button" data-action="increase"><i class="fas fa-plus"></i></button>
                                                            </div>
                                                            <button type="submit" name="add_item" class="btn btn-sm btn-primary">Add</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="card order-summary">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-receipt me-2"></i>Order Summary</h5>
                            </div>
                            <div class="card-body">
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" name="save_order_form">
                        <div class="mb-3">
                             <p><strong>Customer:</strong> <span id="summaryCustomer">-</span></p>
                              <p><strong>Table:</strong> <span id="summaryTable">-</span></p>
                             <p><strong>Date:</strong> <span id="summaryDate"><?php echo date('d/m/Y'); ?></span></p>
                               </div>
                                   <hr>
                                    <div class="table-container mb-3">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Item</th>
                                                    <th>Qty</th>
                                                    <th>Price</th>
                                                    <th>Total</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="orderItems">
                                                <?php if (empty($_SESSION['order_items'])): ?>
                                                <tr>
                                                    <td colspan="5" class="text-center">No items added yet</td>
                                                </tr>
                                                <?php else: ?>
                                                <?php foreach ($_SESSION['order_items'] as $item): ?>
                                                <tr>
                                                    <td><?php echo $item['name']; ?></td>
                                                    <td><?php echo $item['quantity']; ?></td>
                                                    <td>Rp <?php echo number_format($item['price'], 0, ',', '.'); ?></td>
                                                    <td>Rp <?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?></td>
                                                    <td>
                                                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" style="display:inline;">
                                                            <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                                                            <button type="submit" name="remove_item" class="btn btn-sm btn-danger">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                                <?php endif; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th colspan="3">Subtotal</th>
                                                    <th>Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></th>
                                                    <th></th>
                                                </tr>
                                                <tr>
                                                    <th colspan="3">Tax (10%)</th>
                                                    <th>Rp <?php echo number_format($tax, 0, ',', '.'); ?></th>
                                                    <th></th>
                                                </tr>
                                                <tr class="table-active">
                                                    <th colspan="3">Total</th>
                                                    <th>Rp <?php echo number_format($total, 0, ',', '.'); ?></th>
                                                    <th></th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    <div class="d-grid gap-2">
        <textarea class="form-control mb-3" name="order_notes" rows="2" placeholder="Order notes (optional)"></textarea>
        <input type="hidden" name="customer_id" id="hiddenCustomerName">
        <input type="hidden" name="table_number" id="hiddenTableNumber">
        <button type="submit" name="save_order" class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Order</button>
        <button type="button" class="btn btn-outline-secondary" id="printBtn"><i class="fas fa-print me-2"></i>Print Receipt</button>
    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-list me-2"></i>Order List</h5>
                        <span class="badge bg-primary rounded-pill"><?php echo count($active_orders); ?> Active Orders</span>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <div class="row g-3">
                                <div class="col-md-4">
                                  
                                </div>
                                <div class="col-md-3">
                                    
                                </div>
                                <div class="col-md-3">
                                    
                                </div>
                                <div class="col-md-2">
                                    <input type hidden class="btn btn-primary w-100" id="filterBtn"></button>
                                </div>
                            </div>
                        </div>

                        <div class="table-container">
                            <table class="table table-hover table-order-items">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Customer</th>
                                        <th>Table</th>
                                        <th>Items</th>
                                        <th>Total</th>
                                        <th>Status</th>
                                        <th>Time</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($active_orders as $order): ?>
                                    <tr>
                                        <td><?php echo $order['idpesanan']; ?></td>
                                        <td><?php echo $order['namapelanggan']; ?></td>
                                        <td>Table <?php echo $order['idmeja']; ?></td>
                                        <td><?php echo $order['item_count']; ?> items</td>
                                        <td>Rp <?php echo number_format($order['total'], 0, ',', '.'); ?></td>
                                        <td>
                                            <?php
                                            $badge_class = 'bg-info text-dark';
                                            if ($order['status'] == 'In Progress') {
                                                $badge_class = 'bg-warning text-dark';
                                            } else if ($order['status'] == 'Completed') {
                                                $badge_class = 'bg-secondary';
                                            } else if ($order['status'] == 'Ready') {
                                                $badge_class = 'bg-success';
                                            }
                                            ?>
                                            <span class="badge <?php echo $badge_class; ?>"><?php echo $order['status']; ?></span>
                                        </td>
                                        <td><?php echo date('H:i A', strtotime($order['time'])); ?></td>
                                        <td class="action-buttons">
                                            <a href="edit_order.php?id=<?php echo $order['idpesanan']; ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                                            
                                            <?php if ($order['status'] != 'Completed'): ?>
                                           
                                            <?php else: ?>
                                            <button class="btn btn-sm btn-outline-secondary print-btn" data-id="<?php echo $order['idpesanan']; ?>"><i class="fas fa-print"></i></button>
                                            <a href="view_order.php?id=<?php echo $order['idpesanan']; ?>" class="btn btn-sm btn-outline-info"><i class="fas fa-eye"></i></a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    
                                    <?php if(empty($active_orders)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">No active orders found</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                       
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>
    <script>

   document.addEventListener('DOMContentLoaded', function() {

    const customerSelect = document.getElementById('customerSelect');
    const tableNumberSelect = document.getElementById('tableNumber');
    const summaryCustomer = document.getElementById('summaryCustomer');
    const summaryTable = document.getElementById('summaryTable');
    const hiddenCustomerName = document.getElementById('hiddenCustomerName');
    const hiddenTableNumber = document.getElementById('hiddenTableNumber');

    customerSelect.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        summaryCustomer.textContent = selectedOption.text || '-';
        hiddenCustomerName.value = this.value;
    });

    tableNumberSelect.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const selectedText = selectedOption.text || '-';
        summaryTable.textContent = selectedText;
        hiddenTableNumber.value = this.value;
    });

    
    const qtyButtons = document.querySelectorAll('.qty-btn');
    qtyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const action = this.getAttribute('data-action');
            const inputField = this.closest('.input-group').querySelector('.quantity-input');
            let currentValue = parseInt(inputField.value);
            
            if (action === 'increase') {
                inputField.value = currentValue + 1;
            } else if (action === 'decrease' && currentValue > 1) {
                inputField.value = currentValue - 1;
            }
        });
    });

    const menuSearch = document.getElementById('menuSearch');
    const searchBtn = document.getElementById('searchBtn');
    const menuItems = document.querySelectorAll('.menu-item');
    
    function performSearch() {
        const searchTerm = menuSearch.value.toLowerCase();
        
        menuItems.forEach(item => {
            const itemName = item.getAttribute('data-name').toLowerCase();
            const itemCategory = item.getAttribute('data-category').toLowerCase();
            
            if (itemName.includes(searchTerm) || itemCategory.includes(searchTerm)) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    menuSearch.addEventListener('keyup', performSearch);
    searchBtn.addEventListener('click', performSearch);

   
    const orderSearch = document.getElementById('orderSearch');
    const statusFilter = document.getElementById('statusFilter');
    const dateFilter = document.getElementById('dateFilter');
    const filterBtn = document.getElementById('filterBtn');
    const orderRows = document.querySelectorAll('.table-order-items tbody tr');
    
    filterBtn.addEventListener('click', function() {
        const searchTerm = orderSearch.value.toLowerCase();
        const statusValue = statusFilter.value === 'All Statuses' ? '' : statusFilter.value.toLowerCase();
        const dateValue = dateFilter.value;
        
        orderRows.forEach(row => {
            const customerName = row.cells[1].textContent.toLowerCase();
            const orderStatus = row.querySelector('.badge').textContent.toLowerCase();
            const orderDate = row.cells[6].textContent; // Assuming time column has date info
            
            const matchesSearch = customerName.includes(searchTerm);
            const matchesStatus = statusValue === '' || orderStatus === statusValue;
            // For simplicity, we're just checking if the date filter is empty or not
            // In a real application, you'd want to convert and compare actual dates
            const matchesDate = dateValue === '' || orderDate.includes(dateValue);
            
            if (matchesSearch && matchesStatus && matchesDate) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });

    // Print receipt functionality
    const printBtn = document.getElementById('printBtn');
    
    printBtn.addEventListener('click', function() {
        if (summaryCustomer.textContent === '-' || summaryTable.textContent === '-') {
            alert('Please select a customer and table before printing receipt.');
            return;
        }
        
        const orderItems = document.getElementById('orderItems');
        if (orderItems.children.length === 0 || 
            (orderItems.children.length === 1 && 
             orderItems.children[0].cells.length === 1 && 
             orderItems.children[0].cells[0].textContent === 'No items added yet')) {
            alert('Please add items to the order before printing receipt.');
            return;
        }
        
        // Create printable content
        const printWindow = window.open('', '_blank');
        
        printWindow.document.write(`
            <html>
            <head>
                <title>Order Receipt</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    .header { text-align: center; margin-bottom: 20px; }
                    .receipt-details { margin-bottom: 20px; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
                    .total-row { font-weight: bold; }
                    .footer { margin-top: 30px; text-align: center; font-size: 14px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h2>Restaurant Order Receipt</h2>
                    <p>${new Date().toLocaleString()}</p>
                </div>
                
                <div class="receipt-details">
                    <p><strong>Customer:</strong> ${summaryCustomer.textContent}</p>
                    <p><strong>Table:</strong> ${summaryTable.textContent}</p>
                    <p><strong>Date:</strong> ${document.getElementById('summaryDate').textContent}</p>
                </div>
                
                <table>
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
        `);
        
        // Get items from the order summary table
        const itemRows = orderItems.rows;
        let subtotal = 0;
        
        if (itemRows.length > 0 && itemRows[0].cells.length > 1) {
            for (let i = 0; i < itemRows.length; i++) {
                const row = itemRows[i];
                const name = row.cells[0].textContent;
                const qty = row.cells[1].textContent;
                const price = row.cells[2].textContent;
                const total = row.cells[3].textContent;
                
                // Add to subtotal (remove currency symbol and format)
                subtotal += parseFloat(total.replace('Rp ', '').replace('.', '').replace(',', '.'));
                
                printWindow.document.write(`
                    <tr>
                        <td>${name}</td>
                        <td>${qty}</td>
                        <td>${price}</td>
                        <td>${total}</td>
                    </tr>
                `);
            }
        }
        
        const tax = subtotal * 0.1;
        const totalAmount = subtotal + tax;
        
        printWindow.document.write(`
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3">Subtotal</td>
                            <td>Rp ${subtotal.toLocaleString('id-ID')}</td>
                        </tr>
                        <tr>
                            <td colspan="3">Tax (10%)</td>
                            <td>Rp ${tax.toLocaleString('id-ID')}</td>
                        </tr>
                        <tr class="total-row">
                            <td colspan="3">Total</td>
                            <td>Rp ${totalAmount.toLocaleString('id-ID')}</td>
                        </tr>
                    </tfoot>
                </table>
                
                <div class="footer">
                    <p>Thank you for dining with us!</p>
                    <p>Please keep this receipt for your records.</p>
                </div>
            </body>
            </html>
        `);
        
        printWindow.document.close();
        printWindow.focus();
        
        // Print after a small delay to ensure content is fully loaded
        setTimeout(() => {
            printWindow.print();
        }, 500);
    });

    // Print buttons for completed orders
    const printOrderBtns = document.querySelectorAll('.print-btn');
    printOrderBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const orderId = this.getAttribute('data-id');
            
            // In a real application, you would fetch order details from the server
            // For this example, we'll just show a message
            alert(`Printing receipt for order #${orderId}...`);
            
            // You could use AJAX to get order details and then print them
            // Example:
            /*
            fetch(`get_order_details.php?id=${orderId}`)
                .then(response => response.json())
                .then(data => {
                    // Create and print receipt with data
                })
                .catch(error => console.error('Error fetching order details:', error));
            */
        });
    });

    // Form submission validation
    const saveOrderForm = document.querySelector('form[name="save_order_form"]');
    if (saveOrderForm) {
        saveOrderForm.addEventListener('submit', function(event) {
            if (!hiddenCustomerName.value || !hiddenTableNumber.value) {
                event.preventDefault();
                alert('Please select a customer and table before saving the order.');
                return false;
            }
            
            const orderItems = document.getElementById('orderItems');
            if (orderItems.children.length === 0 || 
                (orderItems.children.length === 1 && 
                 orderItems.children[0].cells.length === 1 && 
                 orderItems.children[0].cells[0].textContent === 'No items added yet')) {
                event.preventDefault();
                alert('Please add at least one item to the order.');
                return false;
            }
            
            return true;
        });
    }

    // Add category filter for menu items (enhancement)
    const categories = new Set();
    menuItems.forEach(item => {
        categories.add(item.getAttribute('data-category'));
    });
    
    // Create category filter UI if there are multiple categories
    if (categories.size > 1) {
        const categoryContainer = document.createElement('div');
        categoryContainer.className = 'category-filter d-flex flex-wrap mb-3';
        
        // Add "All" option
        const allBtn = document.createElement('button');
        allBtn.className = 'btn btn-sm btn-outline-primary me-2 mb-2 active';
        allBtn.textContent = 'All';
        allBtn.addEventListener('click', function() {
            // Remove active class from all buttons
            categoryContainer.querySelectorAll('.btn').forEach(btn => {
                btn.classList.remove('active');
            });
            // Add active class to this button
            this.classList.add('active');
            
            // Show all menu items
            menuItems.forEach(item => {
                item.style.display = 'flex';
            });
        });
        categoryContainer.appendChild(allBtn);
        
        // Add category buttons
        categories.forEach(category => {
            const btn = document.createElement('button');
            btn.className = 'btn btn-sm btn-outline-secondary me-2 mb-2';
            btn.textContent = category;
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                categoryContainer.querySelectorAll('.btn').forEach(btn => {
                    btn.classList.remove('active');
                });
                // Add active class to this button
                this.classList.add('active');
                
                // Filter menu items
                menuItems.forEach(item => {
                    if (item.getAttribute('data-category') === category) {
                        item.style.display = 'flex';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
            categoryContainer.appendChild(btn);
        });
        
        // Insert category filter before menu items container
        const menuItemsContainer = document.querySelector('.menu-items-container');
        menuItemsContainer.parentNode.insertBefore(categoryContainer, menuItemsContainer);
    }
});
document.getElementById('logoutBtn').addEventListener('click', confirmLogout);
document.getElementById('dropdownLogoutBtn').addEventListener('click', confirmLogout);
function confirmLogout() {
            Swal.fire({
                title: 'Logout Confirmation',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#C41E3A',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, Logout',
                cancelButtonText: 'Cancel',
                customClass: {
                    confirmButton: 'btn btn-danger',
                    cancelButton: 'btn btn-secondary'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Logged Out!',
                        text: 'You have been successfully logged out.',
                        confirmButtonColor: '#C41E3A',
                        timer: 1500,
                        timerProgressBar: true,
                        willClose: () => {
                            window.location.href = 'logout.php';
                        }
                    });
                }
            });
        }
</script>
</body> 
</html> 
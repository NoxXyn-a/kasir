<?php

session_start();

// Include database configuration
$host = "localhost";
$username = "root"; // Change as needed
$password = ""; // Change as needed
$database = "rehan";

// Create connection
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get order ID from URL
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($order_id <= 0) {
    $_SESSION['error_message'] = "Invalid order ID";
    header("Location: order.php");
    exit();
}

// Fetch order details
$order = null;
$order_query = "SELECT p.*, pl.namapelanggan, m.idmeja 
                FROM pesanan p 
                JOIN pelanggan pl ON p.idpelanggan = pl.idpelanggan
                JOIN meja m ON p.idmeja = m.idmeja
                WHERE p.idpesanan = ?";

$stmt = mysqli_prepare($conn, $order_query);
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    $order = $row;
} else {
    $_SESSION['error_message'] = "Order not found";
    header("Location: order.php");
    exit();
}

// Fetch order items
$items = [];
$items_query = "SELECT dp.*, m.namamenu 
                FROM detail_pesanan dp
                JOIN menu m ON dp.idmenu = m.idmenu
                WHERE dp.idpesanan = ?";

$stmt = mysqli_prepare($conn, $items_query);
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

while ($row = mysqli_fetch_assoc($result)) {
    $items[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Add your CSS styles here */
        /* Can copy from your original file */
        :root {
            --primary-color: #C41E3A;
            --primary-dark: #8B0000;
            --primary-light: #FF6B6B;
            --accent-color: #FFFFFF;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }
        
        .sidebar {
            min-height: 100vh;
            background-color: var(--primary-color);
            color: white;
            transition: all 0.3s;
        }
        
        /* Add the rest of your CSS here */
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="logo-container">
                    <img src="../img/ravine.png" alt="Restaurant Logo" class="logo">
                    <h5 class="text-center mb-3">Restaurant App</h5>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="fas fa-utensils"></i> Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="order.php">
                            <i class="fas fa-shopping-cart"></i> Order
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">
                            <i class="fas fa-file-alt"></i> Laporan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transaksi.php">
                            <i class="fas fa-file-alt"></i> transaksi
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 content-area">
                <!-- Header -->
                <div class="page-header d-flex justify-content-between align-items-center">
                    <h2>Order Details #<?php echo $order['order_invoice']; ?></h2>
                    <div>
                        <a href="order.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Orders
                        </a>
                        <button class="btn btn-primary" id="printBtn">
                            <i class="fas fa-print"></i> Print Receipt
                        </button>
                    </div>
                </div>

                <!-- Order Details -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Order Information</h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <th width="35%">Order Number:</th>
                                            <td><?php echo $order['order_invoice']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Customer:</th>
                                            <td><?php echo $order['namapelanggan']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Table:</th>
                                            <td>Table <?php echo $order['idmeja']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Date & Time:</th>
                                            <td><?php echo date('d M Y H:i:s', strtotime($order['time'])); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Status:</th>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    switch($order['status']) {
                                                        case 'ready': echo 'info'; break;
                                                        case 'processed': echo 'primary'; break;
                                                        case 'completed': echo 'success'; break;
                                                        case 'cancelled': echo 'danger'; break;
                                                        default: echo 'secondary';
                                                    }
                                                ?>">
                                                    <?php echo ucfirst($order['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Notes:</th>
                                            <td><?php echo $order['notes'] ? $order['notes'] : 'No notes'; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Payment Information</h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <th width="35%">Subtotal:</th>
                                            <td>Rp <?php echo number_format($order['subtotal'], 0, ',', '.'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Tax (10%):</th>
                                            <td>Rp <?php echo number_format($order['tax'], 0, ',', '.'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Total:</th>
                                            <td class="fw-bold">Rp <?php echo number_format($order['total'], 0, ',', '.'); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Order Items -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Order Items</h5>
                        <span class="badge bg-primary rounded-pill"><?php echo count($items); ?> Items</span>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Item</th>
                                        <th class="text-center">Price</th>
                                        <th class="text-center">Quantity</th>
                                        <th class="text-end">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $counter = 1; ?>
                                    <?php foreach ($items as $item): ?>
                                    <tr>
                                        <td><?php echo $counter++; ?></td>
                                        <td><?php echo $item['namamenu']; ?></td>
                                        <td class="text-center">Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></td>
                                        <td class="text-center"><?php echo $item['jumlah']; ?></td>
                                        <td class="text-end">Rp <?php echo number_format($item['harga'] * $item['jumlah'], 0, ',', '.'); ?></td>
                                    </tr>
                                    <?php endforeach; ?>

                                    <?php if (empty($items)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No items found for this order</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="4" class="text-end">Subtotal:</th>
                                        <th class="text-end">Rp <?php echo number_format($order['subtotal'], 0, ',', '.'); ?></th>
                                    </tr>
                                    <tr>
                                        <th colspan="4" class="text-end">Tax (10%):</th>
                                        <th class="text-end">Rp <?php echo number_format($order['tax'], 0, ',', '.'); ?></th>
                                    </tr>
                                    <tr>
                                        <th colspan="4" class="text-end">Total:</th>
                                        <th class="text-end">Rp <?php echo number_format($order['total'], 0, ',', '.'); ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Action buttons -->
                <div class="d-flex justify-content-end mt-4">
                    <?php if ($order['status'] != 'completed' && $order['status'] != 'cancelled'): ?>
                    <form method="post" action="complete_order.php" style="margin-right: 10px;">
                        <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-check"></i> Mark as Completed
                        </button>
                    </form>
                    <form method="post" action="cancel_order.php">
                        <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-times"></i> Cancel Order
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Print receipt functionality
        const printBtn = document.getElementById('printBtn');
        
        printBtn.addEventListener('click', function() {
            // Create printable content
            const printWindow = window.open('', '_blank');
            
            printWindow.document.write(`
                <html>
                <head>
                    <title>Order Receipt</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        .header { text-align: center; margin-bottom: 20px; }
                        .receipt-details { margin-bottom: 20px; }
                        table { width: 100%; border-collapse: collapse; }
                        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
                        .total-row { font-weight: bold; }
                        .footer { margin-top: 30px; text-align: center; font-size: 14px; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h2>Restaurant Order Receipt</h2>
                        <p>${new Date().toLocaleString()}</p>
                        <h3>Invoice: ${<?php echo json_encode($order['order_invoice']); ?>}</h3>
                    </div>
                    
                    <div class="receipt-details">
                        <p><strong>Customer:</strong> ${<?php echo json_encode($order['namapelanggan']); ?>}</p>
                        <p><strong>Table:</strong> Table ${<?php echo json_encode($order['idmeja']); ?>}</p>
                        <p><strong>Date:</strong> ${<?php echo json_encode(date('d M Y H:i:s', strtotime($order['time']))); ?>}</p>
                    </div>
                    
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Item</th>
                                <th>Price</th>
                                <th>Qty</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
            `);
            
            // Add items
            <?php $counter = 1; ?>
            <?php foreach ($items as $item): ?>
            printWindow.document.write(`
                <tr>
                    <td>${<?php echo json_encode($counter++); ?>}</td>
                    <td>${<?php echo json_encode($item['namamenu']); ?>}</td>
                    <td>Rp ${<?php echo json_encode(number_format($item['harga'], 0, ',', '.')); ?>}</td>
                    <td>${<?php echo json_encode($item['jumlah']); ?>}</td>
                    <td>Rp ${<?php echo json_encode(number_format($item['harga'] * $item['jumlah'], 0, ',', '.')); ?>}</td>
                </tr>
            `);
            <?php endforeach; ?>
            
            printWindow.document.write(`
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" style="text-align: right;">Subtotal:</td>
                                <td>Rp ${<?php echo json_encode(number_format($order['subtotal'], 0, ',', '.')); ?>}</td>
                            </tr>
                            <tr>
                                <td colspan="4" style="text-align: right;">Tax (10%):</td>
                                <td>Rp ${<?php echo json_encode(number_format($order['tax'], 0, ',', '.')); ?>}</td>
                            </tr>
                            <tr class="total-row">
                                <td colspan="4" style="text-align: right;">Total:</td>
                                <td>Rp ${<?php echo json_encode(number_format($order['total'], 0, ',', '.')); ?>}</td>
                            </tr>
                        </tfoot>
                    </table>
                    
                    <div class="footer">
                        <p>Thank you for dining with us!</p>
                        <p>Please keep this receipt for your records.</p>
                    </div>
                </body>
                </html>
            `);
            
            printWindow.document.close();
            printWindow.focus();
            
            // Print after a small delay to ensure content is fully loaded
            setTimeout(() => {
                printWindow.print();
            }, 500);
        });
    });
    </script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Ravine Resto | Menu </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg,rgb(180, 180, 180),rgb(196, 196, 196));
            --primary-color:rgb(99, 99, 99);      
            --primary-dark:rgb(107, 107, 107);        
            --primary-light: #F3EAFB;     
            --accent-color: #ffffff;
            --text-dark: #333333;           
            --text-light: #000000;
                }

            body {
                font-family: 'Poppins', sans-serif;
                background: #f4f4f9;
                color: var(--text-dark); 
            }

            .sidebar {
                min-height: 100vh;
                background: var(--primary-gradient);
                color: var(--text-light); /* Menggunakan teks hitam di sidebar untuk kontras */
                transition: all 0.3s;
            }

            .sidebar .logo-container {
                padding: 20px 15px;
                display: flex;
                flex-direction: column;
                align-items: center;
            }

            .sidebar .logo {
                width: 80px;
                height: 80px;
                margin-bottom: 15px;
                border-radius: 50%;
                object-fit: cover;
                border: 3px solid #fff;
            }

            .sidebar .nav-link {
                color: var(--text-light); /* Mengubah warna teks link menjadi hitam */
                border-radius: 8px;
                margin: 5px 10px;
                transition: background 0.3s ease;
            }

            .sidebar .nav-link:hover,
            .sidebar .nav-link.active {
                background-color: rgba(0, 0, 0, 0.1); /* Menambahkan latar belakang saat hover */
                color: #fff;
            }

            .sidebar .nav-link i {
                margin-right: 10px;
                width: 20px;
                text-align: center;
            }
        .main-content {
            transition: all 0.3s;
        }
        
        .navbar {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .navbar .navbar-brand {
            color: var(--primary-color);
            font-weight: bold;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        
        .table > :not(caption) > * > * {
            padding: 12px 15px;
        }
        
        .table thead th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
        }
        
        .table tbody tr:hover {
            background-color: rgba(0, 0, 0, 0.02);
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
        }
        
        .menu-img-preview {
            width: 60px;
            height: 60px;
            border-radius: 5px;
            object-fit: cover;
        }
        
        .action-buttons .btn {
            padding: 4px 8px;
            font-size: 14px;
        }
        
        .filter-row {
            background-color: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
        }
        
        /* Modal Styling */
        .modal-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0;
        }
        
        .modal-content {
            border-radius: 10px;
            border: none;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .form-label {
            font-weight: 500;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(196, 30, 58, 0.25);
        }
        
        .img-upload-preview {
            width: 100%;
            height: 180px;
            border-radius: 10px;
            object-fit: cover;
            margin-top: 10px;
            border: 2px dashed #dee2e6;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
        }
        
        .pagination {
            margin-top: 20px;
        }
        
        .page-item.active .page-link {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .page-link {
            color: var(--primary-color);
        }
        
        .page-link:hover {
            color: var(--primary-dark);
        }
        .logout-btn {
            display: flex;
            align-items: center;
            background-color: white;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
            border-radius: 50px;
            padding: 8px 16px;
            font-weight: bold;
            transition: all 0.3s ease;
            margin: 15px 10px;
        }

        .logout-btn:hover {
            background-color: var(--primary-color);
            color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            transform: translateY(-2px);
        }

        .logout-btn i {
            margin-right: 8px;
        }
    </style>
       <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="logo-container">
                    <img src="../img/ravine.png" alt="Restaurant Logo" class="logo">
                    <h5 class="text-center mb-3">Ravine Resto </h5>
                </div>
                <ul class="nav flex-column">
                   
                    <li class="nav-item">
                        <a class="nav-link active " href="menu.php">
                            <i class="fas fa-utensils"></i> Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="order.php">
                            <i class="fas fa-shopping-cart"></i> Order
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="pelanggan.php">
                            <i class="fas fa-users"></i> Customers
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">
                            <i class="fas fa-file-alt"></i> Laporan
                        </a>
                    </li>
                   
                  
                    <li class="nav-item">
                        <button class="logout-btn" id="logoutBtn">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                    </li>
                </ul>
            </div>
            
    
            <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
               
                <nav class="navbar navbar-light bg-white px-3 mb-4">
                    <div class="container-fluid">
                        <button class="navbar-toggler d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target=".sidebar">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <span class="navbar-brand mb-0 h1">Menu Management</span>
                        <div class="d-flex">
                            <div class="dropdown">
                                <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user-circle me-1"></i> Waiter
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                 
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>
                
               
                <div class="container-fluid">
                    <div class="row mb-4">
                        <div class="col-12 d-flex justify-content-between align-items-center">
                            <h2>Menu Management</h2>
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMenuModal">
                                <i class="fas fa-plus-circle me-2"></i> Add New Menu
                            </button>
                        </div>
                    </div>
                    
            
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="filter-row">
                                <div class="row">
                                    <div class="col-md-4 mb-3 mb-md-0">
                                        <input type="text" class="form-control" placeholder="Search menu items...">
                                    </div>
                                    <div class="col-md-3 mb-3 mb-md-0">
                                        <select class="form-select" id="filterCategory">
                                            <option selected>All Categories</option>
                                            <option value="main course">Main Course</option>
                                            <option value="appetizer">Appetizer</option>
                                            <option value="dessert">Dessert</option>
                                            <option value="beverage">Beverage</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <button class="btn btn-primary w-100" id="filterButton">Filter</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">Menu Items</h5>
                                    <span class="badge bg-primary" id="menuCount">0 Items</span>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover align-middle">
                                            <thead>
                                                <tr>
                                                    <th scope="col" width="5%">#</th>
                                                    <th scope="col" width="10%">Image</th>
                                                    <th scope="col" width="20%">Item Name</th>
                                                    <th scope="col" width="15%">Category</th>
                                                    <th scope="col" width="12%">Price</th>
                                                    <th scope="col" width="15%">Description</th>
                                                    <th scope="col" width="13%">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody id="menuTableBody">
                                            <?php
                                            $conn = mysqli_connect('localhost', 'root', '', 'rehan');

                                            if (!$conn) {
                                                die("Koneksi gagal: " . mysqli_connect_error());
                                            }

                                            $sql = "SELECT * FROM menu";
                                            $result = mysqli_query($conn, $sql);

                                            if (!$result) {
                                                echo "Error: " . mysqli_error($conn);
                                            } else {
                                                if (mysqli_num_rows($result) > 0) {
                                                    $i = 1;
                                                    while ($row = mysqli_fetch_assoc($result)) {
                                                        echo "<tr>";
                                                        echo "<td>" . $i . "</td>";
                                                        echo "<td><img src='get_image.php?id=" . $row['idmenu'] . "' class='menu-img-preview' alt='" . $row['namamenu'] . "'></td>";
                                                        echo "<td>" . $row['namamenu'] . "</td>";
                                                        echo "<td>" . $row['kategori'] . "</td>";
                                                        echo "<td>Rp " . number_format($row['harga'], 0, ',', '.') . "</td>";
                                                        echo "<td>" . $row['deskripsi'] . "</td>";
                                                        echo "<td class='action-buttons'>
                                                                <button class='btn btn-sm btn-outline-primary' onclick='editMenu(" . $row['idmenu'] . ")'><i class='fas fa-edit'></i></button>
                                                                <button class='btn btn-sm btn-outline-danger' onclick='deleteMenu(" . $row['idmenu'] . ")'><i class='fas fa-trash'></i></button>
                                                            </td>";
                                                        echo "</tr>";
                                                        $i++;
                                                    }
                                                } else {
                                                    echo "<tr><td colspan='7' class='text-center'>No menu items found</td></tr>";
                                                }
                                            }
                                            mysqli_close($conn);
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                
                    <div class="row">
                        <div class="col-12">
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center" id="pagination">
                              
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <div class="modal fade" id="addMenuModal" tabindex="-1" aria-labelledby="addMenuModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addMenuModalLabel">Add New Menu Item</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addMenuForm" action="add_menu.php" method="post" enctype="multipart/form-data">
                        <div class="row mb-3">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label for="namamenu" class="form-label">Menu Name</label>
                                    <input type="text" class="form-control" id="namamenu" name="namamenu" placeholder="Enter menu name" required maxlength="100">
                                </div>
                                <div class="mb-3">
                                    <label for="deskripsi" class="form-label">Description</label>
                                    <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" placeholder="Enter menu description" maxlength="250"></textarea>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="kategori" class="form-label">Category</label>
                                        <select class="form-select" id="kategori" name="kategori" required>
                                            <option value="" selected disabled>Select category</option>
                                            <option value="main course">Main Course</option>
                                            <option value="appetizer">Appetizer</option>
                                            <option value="dessert">Dessert</option>
                                            <option value="beverage">Beverage</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="harga" class="form-label">Price (Rp)</label>
                                        <input type="number" class="form-control" id="harga" name="harga" placeholder="Enter price" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Menu Image</label>
                                <div class="img-upload-preview d-flex flex-column align-items-center justify-content-center">
                                    <i class="fas fa-cloud-upload-alt fa-3x mb-2"></i>
                                    <p class="mb-1">Click to upload image</p>
                                    <small class="text-muted">JPG, PNG or GIF (Max. 2MB)</small>
                                </div>
                                <input type="file" class="form-control mt-3" id="img" name="img" accept="image/*">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Save Menu Item</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
 
    <div class="modal fade" id="editMenuModal" tabindex="-1" aria-labelledby="editMenuModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editMenuModalLabel">Edit Menu Item</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editMenuForm" action="update_menu.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" id="editIdmenu" name="idmenu">
                        <div class="row mb-3">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label for="editNamamenu" class="form-label">Menu Name</label>
                                    <input type="text" class="form-control" id="editNamamenu" name="namamenu" required maxlength="100">
                                </div>
                                <div class="mb-3">
                                    <label for="editDeskripsi" class="form-label">Description</label>
                                    <textarea class="form-control" id="editDeskripsi" name="deskripsi" rows="3" maxlength="250"></textarea>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="editKategori" class="form-label">Category</label>
                                        <select class="form-select" id="editKategori" name="kategori" required>
                                            <option value="main course">Main Course</option>
                                            <option value="appetizer">Appetizer</option>
                                            <option value="dessert">Dessert</option>
                                            <option value="beverage">Beverage</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="editHarga" class="form-label">Price (Rp)</label>
                                        <input type="number" class="form-control" id="editHarga" name="harga" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Menu Image</label>
                                <div class="img-upload-preview">
                                    <img id="currentMenuImage" src="/api/placeholder/400/180" class="img-fluid rounded" alt="Menu Preview">
                                </div>
                                <input type="file" class="form-control mt-3" id="editImg" name="img" accept="image/*">
                                <input type="hidden" id="existingImg" name="existing_img">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update Menu Item</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>
    <script>
    
document.addEventListener('DOMContentLoaded', function() {
 
    updateMenuCount();
    

    document.getElementById('filterButton').addEventListener('click', function() {
        filterMenuItems();
    });
    

    const searchInput = document.querySelector('.filter-row input[type="text"]');
    searchInput.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            filterMenuItems();
        }
    });
    

    document.getElementById('img').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const imgPreview = document.querySelector('.img-upload-preview');
                imgPreview.innerHTML = `<img src="${e.target.result}" class="img-fluid rounded" alt="Menu Preview">`;
            }
            reader.readAsDataURL(file);
        }
    });
    
    document.getElementById('editImg').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('currentMenuImage').src = e.target.result;
            }
            reader.readAsDataURL(file);
        }
    });
    

    document.getElementById('editMenuForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        fetch('update_menu.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {

            const editMenuModal = bootstrap.Modal.getInstance(document.getElementById('editMenuModal'));
            editMenuModal.hide();
            
    
            location.reload();
        })
        .catch(error => {
            console.error("Error:", error);
      
            location.reload();
        });
    });

 
    if (document.getElementById('logoutBtn')) {
        document.getElementById('logoutBtn').addEventListener('click', confirmLogout);
    }
    if (document.getElementById('dropdownLogoutBtn')) {
        document.getElementById('dropdownLogoutBtn').addEventListener('click', confirmLogout);
    }
});


function updateMenuCount() {
    const tableRows = document.querySelectorAll('#menuTableBody tr');
    const rowCount = tableRows.length;

    const itemCount = tableRows.length === 1 && tableRows[0].querySelector('td[colspan]') ? 0 : rowCount;
    document.getElementById('menuCount').textContent = itemCount + ' Items';
}

function filterMenuItems() {
    const searchTerm = document.querySelector('.filter-row input[type="text"]').value.toLowerCase();
    const category = document.getElementById('filterCategory').value;
    
    const rows = document.querySelectorAll('#menuTableBody tr');
    let visibleCount = 0;
    
    rows.forEach(row => {

        if (row.querySelector('td[colspan]')) {
            row.style.display = 'none';
            return;
        }
        
        const itemName = row.cells[2].textContent.toLowerCase();
        const itemCategory = row.cells[3].textContent.toLowerCase();
        
  
        const matchesSearch = searchTerm === '' || itemName.includes(searchTerm);
        const matchesCategory = category === 'All Categories' || itemCategory === category.toLowerCase();
        
    
        if (matchesSearch && matchesCategory) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });
    
  
    document.getElementById('menuCount').textContent = visibleCount + ' Items';
    
   
    if (visibleCount === 0) {
        const tableBody = document.getElementById('menuTableBody');
        if (!tableBody.querySelector('tr.no-results')) {
            const noResultsRow = document.createElement('tr');
            noResultsRow.className = 'no-results';
            noResultsRow.innerHTML = '<td colspan="7" class="text-center">No menu items found</td>';
            tableBody.appendChild(noResultsRow);
        } else {
            tableBody.querySelector('tr.no-results').style.display = '';
        }
    } else {
        const noResultsRow = document.getElementById('menuTableBody').querySelector('tr.no-results');
        if (noResultsRow) {
            noResultsRow.style.display = 'none';
        }
    }
}

function updatePagination(currentPage, totalPages) {
    const pagination = document.getElementById('pagination');
    pagination.innerHTML = '';
    
    if (totalPages === 0) {
        return; 
    }

    const prevLi = document.createElement('li');
    prevLi.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
    const prevLink = document.createElement('a');
    prevLink.className = 'page-link';
    prevLink.href = '#';
    prevLink.textContent = 'Previous';
    if (currentPage > 1) {
        prevLink.addEventListener('click', function(e) {
            e.preventDefault();
            filterMenuItems(currentPage - 1);
        });
    }
    prevLi.appendChild(prevLink);
    pagination.appendChild(prevLi);
    
 
    for (let i = 1; i <= totalPages; i++) {
        const pageLi = document.createElement('li');
        pageLi.className = `page-item ${i === currentPage ? 'active' : ''}`;
        const pageLink = document.createElement('a');
        pageLink.className = 'page-link';
        pageLink.href = '#';
        pageLink.textContent = i;
        pageLink.addEventListener('click', function(e) {
            e.preventDefault();
            filterMenuItems(i);
        });
        pageLi.appendChild(pageLink);
        pagination.appendChild(pageLi);
    }
    
  
    const nextLi = document.createElement('li');
    nextLi.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`;
    const nextLink = document.createElement('a');
    nextLink.className = 'page-link';
    nextLink.href = '#';
    nextLink.textContent = 'Next';
    if (currentPage < totalPages) {
        nextLink.addEventListener('click', function(e) {
            e.preventDefault();
            filterMenuItems(currentPage + 1);
        });
    }
    nextLi.appendChild(nextLink);
    pagination.appendChild(nextLi);
}


function editMenu(idmenu) {
  
    fetch(`get_menu_item.php?idmenu=${idmenu}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                const menuItem = data.item;
           
                document.getElementById('editIdmenu').value = menuItem.idmenu;
                document.getElementById('editNamamenu').value = menuItem.namamenu;
                document.getElementById('editHarga').value = menuItem.harga;
                document.getElementById('editDeskripsi').value = menuItem.deskripsi || '';
                document.getElementById('editKategori').value = menuItem.kategori;
                document.getElementById('existingImg').value = menuItem.img || '';
                
             
                document.getElementById('currentMenuImage').src = `get_image.php?id=${menuItem.idmenu}`;
                
             
                const editMenuModal = new bootstrap.Modal(document.getElementById('editMenuModal'));
                editMenuModal.show();
            } else {
                console.error(`Error: ${data.message}`);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Failed to load menu item data'
                });
            }
        })
        .catch(error => {
            console.error("Error:", error);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Failed to connect to server'
            });
        });
}


function deleteMenu(idmenu) {
    if (!idmenu) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Invalid menu ID'
        });
        return;
    }
    
    
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#C41E3A',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
          
            const formData = new FormData();
            formData.append('idmenu', idmenu);
            
            fetch('delete_menu.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === "success") {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deleted!',
                        text: 'Menu item has been deleted.',
                        confirmButtonColor: '#C41E3A'
                    }).then(() => {
                    
                        const currentPage = document.querySelector('.pagination .active') ? 
                            parseInt(document.querySelector('.pagination .active').textContent) : 1;
                        filterMenuItems(currentPage);
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message,
                        confirmButtonColor: '#C41E3A'
                    });
                }
            })
            .catch(error => {
                console.error("Error:", error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Failed to delete menu item. Please try again.',
                    confirmButtonColor: '#C41E3A'
                });
            });
        }
    });
}

function confirmLogout() {
    Swal.fire({
        title: 'Logout Confirmation',
        text: 'Are you sure you want to logout?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#C41E3A',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, Logout',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                icon: 'success',
                title: 'Logged Out!',
                text: 'You have been successfully logged out.',
                confirmButtonColor: '#C41E3A',
                timer: 1500,
                timerProgressBar: true,
                willClose: () => {
                    window.location.href = 'logout.php';
                }
            });
        }
    });
}
    </script>
</body>
</html>
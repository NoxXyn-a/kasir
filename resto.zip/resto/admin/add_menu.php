<?php
require_once 'config.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $namamenu = htmlspecialchars(trim($_POST['namamenu']));
    $deskripsi = htmlspecialchars(trim($_POST['deskripsi']));
    $kategori = htmlspecialchars(trim($_POST['kategori']));
    $harga = filter_var($_POST['harga'], FILTER_VALIDATE_INT); 
    if (empty($namamenu) || empty($kategori) || $harga === false) {
        $_SESSION['error'] = "All required fields must be filled correctly";
        header("Location: menu.php");
        exit();
    }

    
    $img_data = null;
    $img_type = null;
    

    if (isset($_FILES['img']) && $_FILES['img']['error'] == 0) {
       
        $file_size = $_FILES['img']['size'];
        $file_tmp = $_FILES['img']['tmp_name'];
        $file_type = $_FILES['img']['type'];
        
   
        $tmp = explode('.', $_FILES['img']['name']);
        $file_ext = strtolower(end($tmp));
        
    
        $allowed_extensions = array("jpeg", "jpg", "png", "gif");
        
        if (in_array($file_ext, $allowed_extensions) && $file_size <= 2097152) {
     
            $img_data = file_get_contents($file_tmp);
            $img_type = $file_type;
            
            if ($img_data === false) {
                $_SESSION['error'] = "Failed to read image file";
                header("Location: menu.php");
                exit();
            }
        } else {
            $_SESSION['error'] = "Invalid file. Please upload JPG, PNG or GIF files ";
            header("Location: menu.php");
            exit();
        }
    }
    

    $stmt = $conn->prepare("INSERT INTO menu (namamenu, deskripsi, kategori, harga, img, img_type) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssdss", $namamenu, $deskripsi, $kategori, $harga, $img_data, $img_type);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Menu item added successfully!";
    } else {
        $_SESSION['error'] = "Error: " . $conn->error;
    }
    
    
    $stmt->close();
    
    
    header("Location: menu.php");
    exit();
} else {
   
    $_SESSION['error'] = "Invalid request";
    header("Location: menu.php");
    exit();
}
?>
<?php

require_once 'config.php';


$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$search = isset($_GET['search']) ? $_GET['search'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 8; 
$offset = ($page - 1) * $perPage;

if (isset($_POST['addTable'])) {
    $nomormeja = $_POST['tableNumber'];
    $kapasitas = $_POST['tableCapacity'];
    $status = $_POST['tableStatus'];
    $lokasi = $_POST['tableLocation'];
    

    $query = "INSERT INTO meja (nomormeja, kapasitas, status, lokasi) VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("isss", $nomormeja, $kapasitas, $status, $lokasi);
    
    if ($stmt->execute()) {

        header("Location: meja.php?success=1");
        exit();
    } else {
        $error = "Error: " . $stmt->error;
    }
}


if (isset($_POST['updateStatus'])) {
    $id = $_POST['tableId'];
    $status = $_POST['newStatus'];
    
    $query = "UPDATE meja SET status = ? WHERE idmeja = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $status, $id);
    
    if ($stmt->execute()) {
        header("Location: meja.php?updated=1");
        exit();
    } else {
        $error = "Error updating status: " . $stmt->error;
    }
}


if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    $query = "DELETE FROM meja WHERE idmeja = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        header("Location: meja.php?deleted=1");
        exit();
    } else {
        $error = "Error deleting table: " . $stmt->error;
    }
}

// Handle Edit Table
if (isset($_POST['editTable'])) {
    $id = $_POST['tableId'];
    $nomormeja = $_POST['editTableNumber'];
    $kapasitas = $_POST['editTableCapacity'];
    $status = $_POST['editTableStatus'];
    $lokasi = $_POST['editTableLocation'];
    
    $query = "UPDATE meja SET nomormeja = ?, kapasitas = ?, status = ?, lokasi = ? WHERE idmeja = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isssi", $nomormeja, $kapasitas, $status, $lokasi, $id);
    
    if ($stmt->execute()) {
        header("Location: meja.php?updated=1");
        exit();
    } else {
        $error = "Error updating table: " . $stmt->error;
    }
}


$whereClause = "";
$params = [];
$paramTypes = "";

if (!empty($search)) {
    $whereClause = " WHERE nomormeja LIKE ? ";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $paramTypes .= "s";
}

if ($filter != 'all') {
    if (empty($whereClause)) {
        $whereClause = " WHERE status = ? ";
    } else {
        $whereClause .= " AND status = ? ";
    }
    $params[] = $filter;
    $paramTypes .= "s";
}


$countQuery = "SELECT COUNT(*) as total FROM meja" . $whereClause;
$stmt = $conn->prepare($countQuery);

if (!empty($params)) {
    $stmt->bind_param($paramTypes, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$totalTables = $row['total'];
$totalPages = ceil($totalTables / $perPage);

$query = "SELECT * FROM meja" . $whereClause . " ORDER BY nomormeja LIMIT ? OFFSET ?";
$limitParamTypes = $paramTypes . "ii";
$limitParams = array_merge($params, [$perPage, $offset]);

$stmt = $conn->prepare($query);
if (!empty($limitParams)) {
    $stmt->bind_param($limitParamTypes, ...$limitParams);
}

$stmt->execute();
$tables = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ravine Resto | Entry Meja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css">
    <style>
        :root {
    --primary-gradient: linear-gradient(135deg,rgb(180, 180, 180),rgb(196, 196, 196));
    --primary-color:rgb(99, 99, 99);       /* Lavender */
    --primary-dark:rgb(107, 107, 107);    /* abu-abu gelap */
    --primary-light: #D3D3D3; /* abu-abu terang */
    --accent-color: #FFFFFF;
    --text-dark: #2E2E2E;
}

body {
    font-family: 'Poppins', sans-serif;
    background-color: #f8f9fa;
}

.sidebar {
    min-height: 100vh;
    background: var(--primary-gradient);
    color: var(--text-light); /* Menggunakan teks hitam di sidebar untuk kontras */
    transition: all 0.3s;
}


.sidebar .logo-container {
    padding: 20px 15px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.sidebar .logo {
    width: 80px;
    height: 80px;
    margin-bottom: 15px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #fff;
}

.sidebar .nav-link {
    color: var(--text-light); /* Mengubah warna teks link menjadi hitam */
    border-radius: 8px;
    margin: 5px 10px;
    transition: background 0.3s ease;
}

.sidebar .nav-link:hover,
.sidebar .nav-link.active {
    background-color: rgba(0, 0, 0, 0.1); /* Menambahkan latar belakang saat hover */
    color: #fff;
}

.sidebar .nav-link i {
    margin-right: 10px;
    width: 20px;
    text-align: center;
}

.main-content {
    transition: all 0.3s;
}

.navbar {
    background-color: white;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.navbar .navbar-brand {
    color: var(--primary-dark);
    font-weight: bold;
}

.card {
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    border: none;
}

.card-header {
    background-color: var(--primary-color);
    color: white;
    border-radius: 10px 10px 0 0 !important;
}

.btn-primary {
    background-color: var(--primary-color);
    border-color: var(--primary-color);
}

.btn-primary:hover {
    background-color: var(--primary-dark);
    border-color: var(--primary-dark);
}

.table > :not(caption) > * > * {
    padding: 12px 15px;
}

.table thead th {
    background-color: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
}

.table tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.02);
}

.status-badge {
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
}

.menu-img-preview {
    width: 60px;
    height: 60px;
    border-radius: 5px;
    object-fit: cover;
}

.action-buttons .btn {
    padding: 4px 8px;
    font-size: 14px;
}

.filter-row {
    background-color: white;
    padding: 15px;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    margin-bottom: 20px;
}

.modal-header {
    background-color: var(--primary-color);
    color: white;
    border-radius: 10px 10px 0 0;
}

.modal-content {
    border-radius: 10px;
    border: none;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.form-label {
    font-weight: 500;
}

.form-control:focus, .form-select:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 0.25rem rgba(169, 169, 169, 0.25);
}

.img-upload-preview {
    width: 100%;
    height: 180px;
    border-radius: 10px;
    object-fit: cover;
    margin-top: 10px;
    border: 2px dashed #dee2e6;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
}

.pagination {
    margin-top: 20px;
}

.page-item.active .page-link {
    background-color: var(--primary-color);
    border-color: var(--primary-color);
}

.page-link {
    color: var(--primary-color);
}

.page-link:hover {
    color: var(--primary-dark);
}

.logout-btn {
    display: flex;
    align-items: center;
    background-color: white;
    color: var(--primary-color);
    border: 2px solid var(--primary-color);
    border-radius: 50px;
    padding: 8px 16px;
    font-weight: bold;
    transition: all 0.3s ease;
    margin: 15px 10px;
}

.logout-btn:hover {
    background-color: var(--primary-color);
    color: white;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
    transform: translateY(-2px);
}

.logout-btn i {
    margin-right: 8px;
}

.table-card {
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.07);
    transition: all 0.3s ease;
    cursor: pointer;
    height: 100%;
    background-color: white;
    border: none;
}

.table-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
}

.table-card .card-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #dee2e6;
    font-weight: 600;
    padding: 18px 20px;
    font-size: 16px;
    color: var(--text-dark);
}

.table-card .card-body {
    padding: 25px 20px;
    text-align: center;
}

.table-number {
    font-size: 18px;
    font-weight: 700;
    color: #212529;
}

.table-icon {
    font-size: 52px;
    margin: 20px 0;
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    opacity: 0.9;
}

.capacity-tag {
    display: inline-block;
    padding: 8px 15px;
    background-color: #f8f9fa;
    border-radius: 50px;
    font-size: 14px;
    margin-bottom: 15px;
    font-weight: 500;
}

.table-status {
    font-size: 14px;
    padding: 8px 18px;
    border-radius: 50px;
    display: inline-block;
    font-weight: 600;
    letter-spacing: 0.5px;
}

.badge-available {
    background-color: rgba(40, 167, 69, 0.15);
    color: #28a745;
}

.badge-occupied {
    background-color: rgba(220, 53, 69, 0.15);
    color: #dc3545;
}

.badge-reserved {
    background-color: rgba(253, 126, 20, 0.15);
    color: #fd7e14;
}

.action-btn {
    width: 100%;
    text-align: left;
    margin-top: 15px;
    border-radius: 8px;
    padding: 10px 15px;
    transition: all 0.3s;
    font-weight: 500;
}

.action-btn:hover {
    background-color: var(--primary-light);
    color: white;
    border-color: var(--primary-light);
}

.filter-bar {
    background-color: white;
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
}

.search-input {
    border-radius: 50px;
    padding: 12px 20px 12px 45px;
    border: 1px solid #e9ecef;
    font-size: 15px;
    transition: all 0.3s;
}

.search-input:focus {
    box-shadow: 0 0 0 3px rgba(169, 169, 169, 0.2);
    border-color: var(--primary-color);
}

.search-icon {
    position: absolute;
    left: 25px;
    top: 13px;
    color: #adb5bd;
}

.btn-custom-primary {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
    border: none;
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    font-weight: 500;
    transition: all 0.3s;
    box-shadow: 0 4px 10px rgba(169, 169, 169, 0.2);
}

.btn-custom-primary:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 15px rgba(169, 169, 169, 0.3);
    background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-color) 100%);
}

    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="logo-container">
                    <img src="../img/ravine.png" alt="Restaurant Logo" class="logo">
                    <h5 class="text-center mb-3">Ravine Resto</h5>
                </div>
                <ul class="nav flex-column">
                  
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="fas fa-utensils"></i> Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="meja.php">
                            <i class="fas fa-chair"></i> Entry Meja
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user.php">
                            <i class="fas fa-users"></i> User Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <button class="logout-btn" id="logoutBtn">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                    </li>
                </ul>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                <!-- Navbar -->
                <nav class="navbar navbar-light bg-white px-3 mb-4">
                    <div class="container-fluid">
                        <button class="navbar-toggler d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target=".sidebar">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <span class="navbar-brand mb-0 h1">Entry Meja</span>
                        <div class="d-flex">
                            <div class="dropdown">
                                <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user-circle me-1"></i> Admin
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                    <li><hr class="dropdown-divider"></li>
                                    <li class="nav-item">
                        <button class="logout-btn" id="logoutBtn">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>
        
        <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i> Meja berhasil ditambahkan!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['updated'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i> Status meja berhasil diubah!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <i class="fas fa-trash me-2"></i> Meja berhasil dihapus!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i> <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
      
        <div class="filter-bar">
            <form method="GET" action="meja.php">
                <div class="row align-items-center">
                    <div class="col-md-4 col-lg-4 position-relative mb-3 mb-md-0">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" name="search" class="form-control search-input" placeholder="Cari meja..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-5 col-lg-6 mb-3 mb-md-0">
                    <div class="btn-group" role="group">
                        <button type="submit" name="filter" value="all" class="btn btn-outline-secondary <?php echo $filter == 'all' ? 'active' : ''; ?>">Semua</button>
                        <button type="submit" name="filter" value="tersedia" class="btn btn-outline-success <?php echo $filter == 'tersedia' ? 'active' : ''; ?>">Tersedia</button>
                        <button type="submit" name="filter" value="terisi" class="btn btn-outline-danger <?php echo $filter == 'terisi' ? 'active' : ''; ?>">Terisi</button>
                        <button type="submit" name="filter" value="dipesan" class="btn btn-outline-warning <?php echo $filter == 'dipesan' ? 'active' : ''; ?>">Dipesan</button>
                    </div>
                    </div>
                    <div class="col-md-3 col-lg-2 text-md-end">
                        <button type="button" class="btn btn-custom-primary w-100" data-bs-toggle="modal" data-bs-target="#addTableModal">
                            <i class="fas fa-plus me-1"></i> Tambah Meja
                        </button>
                    </div>
                </div>
            </form>
        </div>
        
  
        <div class="row g-4">
            <?php if ($tables->num_rows > 0): ?>
                <?php while ($table = $tables->fetch_assoc()): ?>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="table-card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span class="table-number">Meja <?php echo sprintf('%02d', $table['nomormeja']); ?></span>
                                <div class="dropdown">
                                    <button class="btn btn-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#editTableModal<?php echo $table['idmeja']; ?>"><i class="fas fa-edit me-2"></i>Edit</a></li>
                                        <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#deleteTableModal<?php echo $table['idmeja']; ?>"><i class="fas fa-trash me-2"></i>Delete</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-body">
                                <i class="fas fa-chair table-icon"></i>
                                <div class="capacity-tag">
                                    <i class="fas fa-users me-1"></i> <?php echo $table['kapasitas']; ?> orang
                                </div>
                                <div class="table-status badge-<?php 
                                    if ($table['status'] == 'tersedia') echo 'available';
                                    elseif ($table['status'] == 'terisi') echo 'occupied';
                                    elseif ($table['status'] == 'dipesan') echo 'reserved';
                                ?>">
                                    <i class="fas <?php 
                                        if ($table['status'] == 'tersedia') echo 'fa-check-circle';
                                        elseif ($table['status'] == 'terisi') echo 'fa-times-circle';
                                        elseif ($table['status'] == 'dipesan') echo 'fa-bookmark';
                                    ?> me-1"></i>
                                    <?php 
                                        echo ucfirst($table['status']);
                                    ?>
                                </div>
                                <div class="mt-3">
                                    <button class="btn btn-sm btn-outline-primary action-btn" data-bs-toggle="modal" data-bs-target="#changeStatusModal<?php echo $table['idmeja']; ?>">
                                        <i class="fas fa-edit me-1"></i> Ubah Status
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="modal fade" id="changeStatusModal<?php echo $table['idmeja']; ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Ubah Status Meja <?php echo sprintf('%02d', $table['nomormeja']); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form method="POST" action="meja.php">
                                    <div class="modal-body">
                                        <input type="hidden" name="tableId" value="<?php echo $table['idmeja']; ?>">
                                        <div class="mb-3">
                                            <label for="newStatus" class="form-label">Status Baru</label>
                                            <select class="form-select" name="newStatus" id="newStatus">
                                                <option value="tersedia" <?php echo $table['status'] == 'tersedia' ? 'selected' : ''; ?>>Tersedia</option>
                                                <option value="terisi" <?php echo $table['status'] == 'terisi' ? 'selected' : ''; ?>>Terisi</option>
                                                <option value="dipesan" <?php echo $table['status'] == 'dipesan' ? 'selected' : ''; ?>>Dipesan</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" name="updateStatus" class="btn btn-custom-primary">Simpan Perubahan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                
<div class="modal fade" id="editTableModal<?php echo $table['idmeja']; ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Meja <?php echo sprintf('%02d', $table['nomormeja']); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="meja.php">
                <div class="modal-body">
                    <input type="hidden" name="tableId" value="<?php echo $table['idmeja']; ?>">
                    <div class="mb-3">
                        <label for="editTableNumber" class="form-label">Nomor Meja</label>
                        <input type="number" class="form-control" name="editTableNumber" value="<?php echo $table['nomormeja']; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="editTableCapacity" class="form-label">Kapasitas</label>
                        <select class="form-select" name="editTableCapacity">
                            <option value="2" <?php echo $table['kapasitas'] == '2' ? 'selected' : ''; ?>>2 orang</option>
                            <option value="4" <?php echo $table['kapasitas'] == '4' ? 'selected' : ''; ?>>4 orang</option>
                            <option value="6" <?php echo $table['kapasitas'] == '6' ? 'selected' : ''; ?>>6 orang</option>
                            <option value="8" <?php echo $table['kapasitas'] == '8' ? 'selected' : ''; ?>>8 orang</option>
                            <option value="10" <?php echo $table['kapasitas'] == '10' ? 'selected' : ''; ?>>10 orang</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="editTableStatus" class="form-label">Status</label>
                        <select class="form-select" name="editTableStatus">
                            <option value="tersedia" <?php echo $table['status'] == 'tersedia' ? 'selected' : ''; ?>>Tersedia</option>
                            <option value="terisi" <?php echo $table['status'] == 'terisi' ? 'selected' : ''; ?>>Terisi</option>
                            <option value="dipesan" <?php echo $table['status'] == 'dipesan' ? 'selected' : ''; ?>>Dipesan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="editTableLocation" class="form-label">Lokasi</label>
                        <select class="form-select" name="editTableLocation">
                            <option value="indoor" <?php echo $table['lokasi'] == 'indoor' ? 'selected' : ''; ?>>Indoor</option>
                            <option value="outdoor" <?php echo $table['lokasi'] == 'outdoor' ? 'selected' : ''; ?>>Outdoor</option>
                            <option value="balcony" <?php echo $table['lokasi'] == 'balcony' ? 'selected' : ''; ?>>Balcony</option>
                            <option value="privateroom" <?php echo $table['lokasi'] == 'privateroom' ? 'selected' : ''; ?>>Private Room</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="editTable" class="btn btn-custom-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Table Modal -->
<div class="modal fade" id="deleteTableModal<?php echo $table['idmeja']; ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Hapus Meja</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Anda yakin ingin menghapus Meja <?php echo sprintf('%02d', $table['nomormeja']); ?>?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <a href="meja.php?delete=<?php echo $table['idmeja']; ?>" class="btn btn-danger">Hapus</a>
            </div>
        </div>
    </div>
</div>
<?php endwhile; ?>
<?php else: ?>
    <div class="col-12">
        <div class="alert alert-info text-center">
            <i class="fas fa-info-circle me-2"></i> Tidak ada data meja yang ditemukan.
        </div>
    </div>
<?php endif; ?>
</div>

<!-- Pagination -->
<?php if ($totalPages > 1): ?>
<nav aria-label="Page navigation">
    <ul class="pagination">
        <?php if ($page > 1): ?>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo $page-1; ?>&filter=<?php echo $filter; ?>&search=<?php echo urlencode($search); ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
        <?php endif; ?>
        
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>&filter=<?php echo $filter; ?>&search=<?php echo urlencode($search); ?>">
                    <?php echo $i; ?>
                </a>
            </li>
        <?php endfor; ?>
        
        <?php if ($page < $totalPages): ?>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo $page+1; ?>&filter=<?php echo $filter; ?>&search=<?php echo urlencode($search); ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        <?php endif; ?>
    </ul>
</nav>
<?php endif; ?>

</div>


<div class="modal fade" id="addTableModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Meja Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="meja.php">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="tableNumber" class="form-label">Nomor Meja</label>
                        <input type="number" class="form-control" name="tableNumber" id="tableNumber" required>
                    </div>
                    <div class="mb-3">
                        <label for="tableCapacity" class="form-label">Kapasitas</label>
                        <select class="form-select" name="tableCapacity" id="tableCapacity" required>
                            <option value="">Pilih Kapasitas</option>
                            <option value="2">2 orang</option>
                            <option value="4">4 orang</option>
                            <option value="6">6 orang</option>
                            <option value="8">8 orang</option>
                            <option value="10">10 orang</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tableStatus" class="form-label">Status</label>
                        <select class="form-select" name="tableStatus" id="tableStatus" required>
                            <option value="tersedia">Tersedia</option>
                            <option value="terisi">Terisi</option>
                            <option value="dipesan">Dipesan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tableLocation" class="form-label">Lokasi</label>
                        <select class="form-select" name="tableLocation" id="tableLocation" required>
                            <option value="">Pilih Lokasi</option>
                            <option value="indoor">Indoor</option>
                            <option value="outdoor">Outdoor</option>
                            <option value="balcony">Balcony</option>
                            <option value="privateroom">Private Room</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="addTable" class="btn btn-custom-primary">Tambah Meja</button>
                </div>
            </form>
        </div>
    </div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>
<script>
 
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            var alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                var bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    });

document.addEventListener('DOMContentLoaded', function() {

    const logoutButtons = document.querySelectorAll('#logoutBtn');
    
 
    logoutButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            confirmLogout();
        });
    });
});
    function confirmLogout() {
            Swal.fire({
                title: 'Logout Confirmation',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#C41E3A',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, Logout',
                cancelButtonText: 'Cancel',
                customClass: {
                    confirmButton: 'btn btn-danger',
                    cancelButton: 'btn btn-secondary'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Logged Out!',
                        text: 'You have been successfully logged out.',
                        confirmButtonColor: '#C41E3A',
                        timer: 1500,
                        timerProgressBar: true,
                        willClose: () => {
                            window.location.href = 'logout.php';
                        }
                    });
                }
            });
        }
</script>
</body>
</html>
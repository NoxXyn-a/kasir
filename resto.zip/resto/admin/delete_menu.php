<?php

require_once 'config.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $idmenu = filter_var($_POST['idmenu'], FILTER_VALIDATE_INT);
    
 
    if (!$idmenu) {
    
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Invalid menu ID']);
        exit();
    }
    

    $stmt = $conn->prepare("DELETE FROM menu WHERE idmenu = ?");
    $stmt->bind_param("i", $idmenu);
    

    if ($stmt->execute()) {
       
        header('Content-Type: application/json');
        echo json_encode(['status' => 'success', 'message' => 'Menu item deleted successfully!']);
    } else {
   
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Error: ' . $conn->error]);
    }
    
  
    $stmt->close();
} else {

    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit();
}
?>
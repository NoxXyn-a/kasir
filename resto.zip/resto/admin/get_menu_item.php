<?php

header('Content-Type: application/json');


error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    
    $conn = mysqli_connect('localhost', 'root', '', 'rehan');

    
    if (!$conn) {
        throw new Exception("Connection failed: " . mysqli_connect_error());
    }

    if (!isset($_GET['idmenu']) || empty($_GET['idmenu'])) {
        throw new Exception("Menu ID is required");
    }


    $idmenu = mysqli_real_escape_string($conn, $_GET['idmenu']);

    $sql = "SELECT idmenu, namamenu, deskripsi, kategori, harga, img_type FROM menu WHERE idmenu = ?";
    

    $stmt = mysqli_prepare($conn, $sql);
    
    if (!$stmt) {
        throw new Exception("Prepare failed: " . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($stmt, "i", $idmenu);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if (!$result) {
        throw new Exception("Query failed: " . mysqli_error($conn));
    }
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        
        $response = array(
            "status" => "success",
            "item" => array(
                "idmenu" => $row['idmenu'],
                "namamenu" => $row['namamenu'],
                "deskripsi" => $row['deskripsi'],
                "kategori" => $row['kategori'],
                "harga" => $row['harga'],
                "img_type" => $row['img_type']
            )
        );
        echo json_encode($response);
    } else {
        throw new Exception("Menu item not found");
    }

} catch (Exception $e) {
    $response = array(
        "status" => "error",
        "message" => $e->getMessage()
    );
    echo json_encode($response);
} finally {
   
    if (isset($conn) && $conn) {
        mysqli_close($conn);
    }
}
?>
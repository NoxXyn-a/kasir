<?php
$koneksi = new mysqli("localhost", "root", "", "rehan");

if (isset($_POST['add_user'])) {
    $iduser = $_POST['iduser'];
    $nama = $_POST['namauser'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $role = $_POST['role'];


    $koneksi->query("INSERT INTO user (iduser,namauser, email, password, role) VALUES ('$iduser','$nama', '$email', '$password', '$role')");
    header("Location: user.php");
}

if (isset($_POST['edit_user'])) {
    $id = $_POST['iduser'];
    $nama = $_POST['namauser'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    $koneksi->query("UPDATE user SET namauser='$nama', email='$email', role='$role' WHERE iduser=$id");
    header("Location: user.php");
}

if (isset($_POST['delete_user'])) {
    $id = $_POST['iduser'];
    $koneksi->query("DELETE FROM user WHERE iduser=$id");
    header("Location: user.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ravine Resto | User Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg,rgb(180, 180, 180),rgb(196, 196, 196)); /* Gradient mutiara */
            --primary-color:rgb(99, 99, 99);       /* Lavender */
            --primary-dark:rgb(107, 107, 107);        /* Lavender tua */
            --primary-light: #F3EAFB;       /* Sangat lembut */
            --accent-color: #ffffff;
            --text-dark: #333333;           /* Teks gelap untuk kontras */
            --text-light: #000000;          /* Teks hitam untuk kontras yang lebih kuat */

        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: #f4f4f9;
            color: var(--text-dark);
        }
        
        .sidebar {
        min-height: 100vh;
        background: var(--primary-gradient);
        color: var(--text-light); /* Menggunakan teks hitam di sidebar untuk kontras */
        transition: all 0.3s;
        }

        .sidebar .logo-container {
            padding: 20px 15px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .sidebar .logo {
            width: 80px;
            height: 80px;
            margin-bottom: 15px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #fff;
        }

        .sidebar .nav-link {
            color: var(--text-light); /* Mengubah warna teks link menjadi hitam */
            border-radius: 8px;
            margin: 5px 10px;
            transition: background 0.3s ease;
        }

        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: rgba(0, 0, 0, 0.1); /* Menambahkan latar belakang saat hover */
            color: #fff;
        }

        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        .main-content {
            transition: all 0.3s;
        }
        
        .navbar {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .navbar .navbar-brand {
            color: var(--primary-color);
            font-weight: bold;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        
        .table > :not(caption) > * > * {
            padding: 12px 15px;
        }
        
        .table thead th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
        }
        
        .table tbody tr:hover {
            background-color: rgba(0, 0, 0, 0.02);
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
        }
        
        .action-buttons .btn {
            padding: 4px 8px;
            font-size: 14px;
        }
        
        .filter-row {
            background-color: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
        }
        
        /* Modal Styling */
        .modal-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0;
        }
        
        .modal-content {
            border-radius: 10px;
            border: none;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .form-label {
            font-weight: 500;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(196, 30, 58, 0.25);
        }
        
        .pagination {
            margin-top: 20px;
        }
        
        .page-item.active .page-link {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .page-link {
            color: var(--primary-color);
        }
        
        .page-link:hover {
            color: var(--primary-dark);
        }
        
        .logout-btn {
        display: flex;
        align-items: center;
        background-color: white;
        color: var(--primary-color);
        border: 2px solid var(--primary-color);
        border-radius: 50px;
        padding: 8px 16px;
        font-weight: bold;
        transition: all 0.3s ease;
        margin: 15px 10px;
    }

    .logout-btn:hover {
        background-color: var(--primary-color);
        color: white;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        transform: translateY(-2px);
    }

    .logout-btn i {
        margin-right: 8px;
    }
        
        .role-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .role-admin {
            background-color: #007bff;
            color: white;
        }
        
        .role-waiter {
            background-color: #6c757d;
            color: white;
        }
        
        .role-kasir {
            background-color: #28a745;
            color: white;
        }
        
        .role-owner {
            background-color: #ffc107;
            color: #212529;
        }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="logo-container">
                    <img src="../img/ravine.png" alt="Restaurant Logo" class="logo">
                    <h5 class="text-center mb-3">Ravine Resto </h5>
                </div>
                <ul class="nav flex-column">
                
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="fas fa-utensils"></i> Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="meja.php">
                            <i class="fas fa-chair"></i> Entry Meja
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="user.php">
                            <i class="fas fa-users"></i> User Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <button class="logout-btn" id="logoutBtn">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                    </li>
                </ul>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                <!-- Navbar -->
                <nav class="navbar navbar-light bg-white px-3 mb-4">
                    <div class="container-fluid">
                        <button class="navbar-toggler d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target=".sidebar">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <span class="navbar-brand mb-0 h1">User Management</span>
                        <div class="d-flex">
                            <div class="dropdown">
                                <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user-circle me-1"></i> Admin
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>
                
                <!-- Content -->
                <div class="container-fluid">
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">User List</h5>
                                    <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addUserModal">
                                        <i class="fas fa-plus me-1"></i> Add New User
                                    </button>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Role</th>
                                                    <th class="text-center">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $users = $koneksi->query("SELECT * FROM user");
                                                $no = 1;
                                                while ($row = $users->fetch_assoc()) {
                                                    // Define role badge class
                                                    $roleBadgeClass = "";
                                                    switch ($row['role']) {
                                                        case 'admin':
                                                            $roleBadgeClass = "role-admin";
                                                            break;
                                                        case 'waiter':
                                                            $roleBadgeClass = "role-waiter";
                                                            break;
                                                        case 'kasir':
                                                            $roleBadgeClass = "role-kasir";
                                                            break;
                                                        case 'owner':
                                                            $roleBadgeClass = "role-owner";
                                                            break;
                                                    }
                                                    
                                                    echo "<tr>
                                                        <td>{$no}</td>
                                                        <td>{$row['namauser']}</td>
                                                        <td>{$row['email']}</td>
                                                        <td><span class='role-badge {$roleBadgeClass}'>{$row['role']}</span></td>
                                                        <td class='text-center'>
                                                            <button class='btn btn-sm btn-warning me-1' data-bs-toggle='modal' data-bs-target='#editUserModal{$row['iduser']}'>
                                                                <i class='fas fa-edit'></i>
                                                            </button>
                                                            <button class='btn btn-sm btn-danger' data-bs-toggle='modal' data-bs-target='#deleteUserModal{$row['iduser']}'>
                                                                <i class='fas fa-trash'></i>
                                                            </button>
                                                        </td>
                                                    </tr>";

                                                    // Modal Edit
                                                    echo "<div class='modal fade' id='editUserModal{$row['iduser']}' tabindex='-1'>
                                                        <div class='modal-dialog'>
                                                            <div class='modal-content'>
                                                                <form method='post'>
                                                                    <div class='modal-header'>
                                                                        <h5 class='modal-title'>Edit User</h5>
                                                                        <button type='button' class='btn-close' data-bs-dismiss='modal'></button>
                                                                    </div>
                                                                    <div class='modal-body'>
                                                                        <input type='hidden' name='iduser' value='{$row['iduser']}'>
                                                                        <div class='mb-3'>
                                                                            <label class='form-label'>Name</label>
                                                                            <input type='text' name='namauser' class='form-control' value='{$row['namauser']}' required>
                                                                        </div>
                                                                        <div class='mb-3'>
                                                                            <label class='form-label'>Email</label>
                                                                            <input type='email' name='email' class='form-control' value='{$row['email']}' required>
                                                                        </div>
                                                                        <div class='mb-3'>
                                                                            <label class='form-label'>Role</label>
                                                                            <select name='role' class='form-select'>
                                                                                <option value='admin' ".($row['role']=="admin"?"selected":"").">Admin</option>
                                                                                <option value='waiter' ".($row['role']=="waiter"?"selected":"").">Waiter</option>
                                                                                <option value='kasir' ".($row['role']=="kasir"?"selected":"").">Kasir</option>
                                                                                <option value='owner' ".($row['role']=="owner"?"selected":"").">Owner</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class='modal-footer'>
                                                                        <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Cancel</button>
                                                                        <button type='submit' name='edit_user' class='btn btn-primary'>Save Changes</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>";

                                                    // Modal Delete
                                                    echo "<div class='modal fade' id='deleteUserModal{$row['iduser']}' tabindex='-1'>
                                                        <div class='modal-dialog'>
                                                            <div class='modal-content'>
                                                                <form method='post'>
                                                                    <div class='modal-header'>
                                                                        <h5 class='modal-title'>Confirm Delete</h5>
                                                                        <button type='button' class='btn-close' data-bs-dismiss='modal'></button>
                                                                    </div>
                                                                    <div class='modal-body'>
                                                                        <p>Are you sure you want to delete user <strong>{$row['namauser']}</strong>?</p>
                                                                        <p class='text-danger'><i class='fas fa-exclamation-triangle me-2'></i>This action cannot be undone.</p>
                                                                        <input type='hidden' name='iduser' value='{$row['iduser']}'>
                                                                    </div>
                                                                    <div class='modal-footer'>
                                                                        <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Cancel</button>
                                                                        <button type='submit' name='delete_user' class='btn btn-danger'>
                                                                            <i class='fas fa-trash me-1'></i> Delete User
                                                                        </button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>";
                                                    
                                                    $no++;
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Add User -->
    <div class="modal fade" id="addUserModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post">
                    <div class="modal-header">
                        <h5 class="modal-title">Add New User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">ID</label>
                            <input type="number" name="iduser" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" name="namauser" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select name="role" class="form-select" required>
                                <option value="admin">Admin</option>
                                <option value="waiter">Waiter</option>
                                <option value="kasir">Kasir</option>
                                <option value="owner">Owner</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_user" class="btn btn-primary">
                            <i class="fas fa-plus me-1"></i> Add User
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>
    <script>
        // Logout button functionality
        document.getElementById('logoutBtn').addEventListener('click', function() {
            Swal.fire({
                title: 'Logout',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#C41E3A',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, logout'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'logout.php';
                }
            });
        });
    </script>
</body>
</html>
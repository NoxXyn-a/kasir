<?php

require_once 'config.php';


if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);
    
    
    $stmt = $conn->prepare("SELECT img, img_type FROM menu WHERE idmenu = ?");
    $stmt->bind_param("i", $id);
    
 
    $stmt->execute();
    
  
    $stmt->bind_result($img_data, $img_type);
    
 
    if ($stmt->fetch() && $img_data) {
       
        $stmt->close();
        
     
        header("Content-Type: " . ($img_type ?: 'image/jpeg'));
        
       
        echo $img_data;
    } else {
     
        $stmt->close();
        
       
        header("Location: /api/placeholder/400/320");
    }
} else {

    header("Location: /api/placeholder/400/320");
}
?>
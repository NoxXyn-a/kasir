<?php

ob_start();

require_once 'config.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


function isAjaxRequest() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
    
        $idmenu = filter_var($_POST['idmenu'] ?? 0, FILTER_VALIDATE_INT);
        
        
        if (!$idmenu) {
            throw new Exception("Invalid menu ID");
        }
        

        $namamenu = htmlspecialchars(trim($_POST['namamenu'] ?? ''));
        $deskripsi = htmlspecialchars(trim($_POST['deskripsi'] ?? ''));
        $kategori = htmlspecialchars(trim($_POST['kategori'] ?? ''));
        $harga = filter_var($_POST['harga'] ?? 0, FILTER_VALIDATE_INT);
        
    
        if (empty($namamenu) || empty($kategori) || $harga === false) {
            throw new Exception("All required fields must be filled correctly");
        }
        
    
        if (!isset($conn) || $conn->connect_error) {
            throw new Exception("Database connection failed: " . ($conn->connect_error ?? 'Unknown error'));
        }

        if (isset($_FILES['img']) && $_FILES['img']['error'] == 0 && $_FILES['img']['size'] > 0) {
         
            $file_size = $_FILES['img']['size'];
            $file_tmp = $_FILES['img']['tmp_name'];
            $file_type = $_FILES['img']['type'];
           
            $tmp = explode('.', $_FILES['img']['name']);
            $file_ext = strtolower(end($tmp));
          
            $allowed_extensions = array("jpeg", "jpg", "png", "gif");
            
            if (in_array($file_ext, $allowed_extensions) && $file_size <= 2097152) { 
           
                $img_data = file_get_contents($file_tmp);
                
                if ($img_data === false) {
                    throw new Exception("Failed to read image file");
                }

                $query = "UPDATE menu SET namamenu = ?, deskripsi = ?, kategori = ?, harga = ?, img = ?, img_type = ? WHERE idmenu = ?";
                $stmt = $conn->prepare($query);
                
                if (!$stmt) {
                    throw new Exception("Prepare failed: " . $conn->error);
                }
                

                $stmt->bind_param("sssissi", $namamenu, $deskripsi, $kategori, $harga, $img_data, $file_type, $idmenu);
            } else {
                throw new Exception("Invalid file. Please upload JPG, PNG or GIF files (max 2MB)");
            }
        } else {
       
            $query = "UPDATE menu SET namamenu = ?, deskripsi = ?, kategori = ?, harga = ? WHERE idmenu = ?";
            $stmt = $conn->prepare($query);
            
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $conn->error);
            }
            
            $stmt->bind_param("sssii", $namamenu, $deskripsi, $kategori, $harga, $idmenu);
        }
        
     
        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }
       
        if (isset($_SESSION['error'])) {
            unset($_SESSION['error']);
        }
        
        
        $_SESSION['success'] = "Menu item updated successfully!";
        
   
        $stmt->close();
        
     
        header("Location: menu.php");
        exit();
        
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
        header("Location: menu.php");
        exit();
    }
} else {
 
    $_SESSION['error'] = "Invalid request";
    header("Location: menu.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Ravine Resto | Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      background: linear-gradient(135deg, #ffffff, #f4f4f4); /* gradient mutiara */
    }
  </style>
</head>
<body class="flex items-center justify-center min-h-screen font-sans">

  <div class="w-full max-w-md bg-white p-10 rounded-3xl shadow-2xl transition-transform duration-500 hover:scale-105">
    <div class="flex justify-center mb-6">
      <img src="../img/ravine.png" alt="Logo Restoran" class="h-24 w-24 rounded-full shadow-lg border-4 border-gray-200">
    </div>

    <h2 class="text-3xl font-extrabold text-center text-gray-700 mb-8">Selamat Datang di Ravine Resto</h2>

    <form action="koneksi.php" method="POST" class="space-y-5">
      <div>
        <label for="email" class="block text-gray-700 font-medium mb-1">Email</label>
        <input
          type="email"
          id="email"
          name="email"
          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-400"
          placeholder="Masukkan email"
          required
        />
      </div>

      <div>
        <label for="password" class="block text-gray-700 font-medium mb-1">Kata Sandi</label>
        <input
          type="password"
          id="password"
          name="password"
          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-400"
          placeholder="Masukkan kata sandi"
          required
        />
      </div>

      <button
        type="submit"
        class="w-full bg-gradient-to-r from-gray-400 to-gray-500 hover:from-gray-500 hover:to-gray-600 text-white font-bold py-3 rounded-lg shadow-md transition duration-300"
      >
        Masuk
      </button>
    </form>
  </div>

</body>
</html>

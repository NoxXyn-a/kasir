<?php
session_start();


$conn = new mysqli("localhost", "root", "", "rehan");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}


$email = $_POST['email'];
$password = $_POST['password'];


$sql = "SELECT * FROM user WHERE email='$email' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    $_SESSION['user'] = $user;

   
    switch ($user['role']) {
        case 'admin':
            header("Location: ../admin/menu.php");
            break;
        case 'waiter':
            header("Location: ../waiter/menu.php");
            break;
        case 'kasir':
            header("Location: ../kasir/transaksi.php");
            break;
        case 'owner':
            header("Location: ../owner/laporan.php");
            break;
        default:
            echo "Role tidak dikenali.";
    }
} else {
    echo "<script>alert('Email atau password salah'); window.location.href='login.php';</script>";
}

$conn->close();
?>
